package com.vclient;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.animation.AnimationTimer;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.control.Slider;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.shape.Circle;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.awt.Desktop;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

public final class LauncherApp extends Application {
    private enum Page {
        HOME, BROWSER, SERVERS, LIBRARY, MODS, PACKS, BOOST, FPS_TEST, PERFORMANCE, WARDROBE, COSMETICS, PROFILE, RECORDINGS,
        SCREENSHOTS, FRIENDS, NEWS, ASSISTANT, LOGS, CONSOLE, SETTINGS, DISCORD
    }

    private record ServerEntry(String name, String host, int port) {}

    // VSMP's address: change it here when it moves (JOIN OUR SMP and the Servers page both use it).
    private static final String VSMP_HOST = "vsmp.meowlix.sh";
    private static final int VSMP_PORT = 19754;
    private static final List<ServerEntry> SERVER_LIST = List.of(
            new ServerEntry("VSMP", VSMP_HOST, VSMP_PORT),
            new ServerEntry("LifeAMC", "play.lifeamc.fun", 25565),
            new ServerEntry("WSMP", "play.wsmp.fun", 25565));

    private record VersionChoice(String id, String label, String status,
                                 MinecraftLauncher.AvailableVersion available,
                                 MinecraftLauncher.InstalledVersion installed,
                                 boolean preferredEntry) {
        @Override
        public String toString() {
            return label + "   ·   " + status;
        }
    }

    private static String BACKGROUND = "#071321";
    private static final String MUTED = "#a9d2e8";
    private static String ACCENT = "#00CFFF";
    private static final HttpClient IMAGE_HTTP = PlatformTls.httpClientBuilder(Duration.ofSeconds(12))
            .followRedirects(HttpClient.Redirect.NORMAL).build();
    private final ExecutorService executor = Executors.newCachedThreadPool(runnable -> {
        Thread thread = new Thread(runnable, "vclient-worker");
        thread.setDaemon(true);
        return thread;
    });
    private final JavaRuntimeManager javaRuntimeManager = new JavaRuntimeManager();
    private final ModrinthModService modrinthModService = new ModrinthModService();
    private MinecraftLauncher gameLauncher;
    private final MicrosoftAuthService authService = new MicrosoftAuthService();
    private final ElyByAuthService elyByAuthService = new ElyByAuthService();
    private final AccountStore accountStore = new AccountStore();
    private final LocalFriendsStore friendsStore = new LocalFriendsStore();
    private final List<PlayerAccount> accounts = new ArrayList<>();
    private final List<String> localFriends = new ArrayList<>();
    private final List<String> logLines = new ArrayList<>();
    private final Map<Page, Button> navigationButtons = new EnumMap<>(Page.class);
    private Page hoveredPage;
    private List<MinecraftLauncher.InstalledVersion> installedVersions = List.of();
    private MinecraftLauncher.VersionCatalog versionCatalog;
    private final java.util.Set<String> versionsDownloading = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final java.util.Set<String> modsDownloading = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private String selectedVersionId = "";
    private LauncherSettings settings;
    private PlayerStats stats;
    private RecordingLibrary recordingLibrary;
    private ReplayBuffer replayBuffer;
    private FeatureHost featureHost;
    private ActivityLog activityLog;

    static void setThemeColors(String accent, String background) {
        ACCENT = accent;
        BACKGROUND = background;
    }
    private volatile String replayStatus = "";
    private PlayerAccount account;
    private Stage stage;
    private ComboBox<VersionChoice> versionPicker;
    private ComboBox<PlayerAccount> accountPicker;
    private Label status;
    private Label accountLabel;
    private Button playButton;
    private Button singleplayerButton;
    private Button installVersionButton;
    private Button refreshVersionsButton;
    private Label versionStatusLabel;
    private Button connectionTestButton;
    private Label connectionResultLabel;
    private VBox checklistBox;
    private Region readyDot;
    private Label readyLabel;
    private VBox problemBox;
    private javafx.scene.control.ProgressBar installProgress;
    private Label installProgressLabel;
    private Label gameFolderLabel;
    private Label smpPlayersLabel;
    private boolean startupChecklistRan;
    /** Result of the last connection checklist; drives the "Launcher ready" light. */
    private enum Connection { UNKNOWN, CHECKING, OK, WAKING, DEGRADED, FAILED, OFFLINE }
    private volatile Connection connection = Connection.UNKNOWN;
    private volatile String lastProblem = "";
    private volatile String smpButtonText = "JOIN OUR SMP";
    private boolean moreNavigationExpanded;
    private ImageView avatar;
    private Label headerAccountLabel;
    private TextArea log;
    private TextArea consoleLog;
    private boolean settingsPage;
    private Page activePage = Page.HOME;
    private boolean accountPersistenceInProgress;
    private boolean protectedAccountSavePending;
    private AnimationTimer backgroundAnimation;
    private final List<Snowflake> snowflakes = createSnowflakes();
    private long lastBackgroundFrame;

    @Override
    public void start(Stage stage) throws Exception {
        this.stage = stage;
        settings = LauncherSettings.load();
        gameLauncher = new MinecraftLauncher((requiredMajor, onOutput, allowDownloads) -> {
            int selectedMajor = settings.javaMajorOverride() != 0
                    ? settings.javaMajorOverride() : requiredMajor;
            return javaRuntimeManager.resolve(selectedMajor, onOutput, allowDownloads);
        });
        gameLauncher.setExtraJvmArguments(() -> JvmArgs.parse(settings.jvmArguments()));
        BackendClient.setWakingListener(message -> Platform.runLater(() -> {
            if (!message.isEmpty()) connection = Connection.WAKING;
            else if (connection == Connection.WAKING) connection = Connection.UNKNOWN;
            updateReadiness();
        }));
        startFeatureServices();
        executor.execute(() -> Platform.runLater(this::collectBenchmark));
        gameLauncher.setAdminPermission(settings::isAdmin);
        // Read the hardware once in the background so the first launch does not wait for it.
        executor.execute(PcAnalysis::cached);
        gameLauncher.setBoostTuning(() -> settings.boostEnabled()
                ? settings.boostProfile().tuning(PcAnalysis.cached()) : null);
        gameLauncher.setBenchmarkRequest(this::nextBenchmarkRequest);
        BackendClient.setRequestLog(line -> Platform.runLater(() -> appendLog(line)), settings.debugMode());
        gameLauncher.setBackendUrl(() -> BackendClient.resolveUrl(settings.backendUrl()));
        accounts.addAll(accountStore.load());
        localFriends.addAll(friendsStore.load());
        account = accounts.stream().filter(saved -> saved.id().equals(settings.lastAccountId()))
                .findFirst().orElse(accounts.isEmpty() ? null : accounts.getFirst());
        stage.setTitle("VSMP Client");
        stage.getIcons().add(createIcon());
        stage.setMinWidth(760);
        stage.setMinHeight(640);
        stage.setWidth(960);
        stage.setHeight(760);
        if (account == null) showLogin();
        else showHome();
        FrostSplash.play(stage::show);
        String startPage = System.getProperty("vclient.startPage", "");
        if (!startPage.isBlank() && account != null) {
            // Debugging aid: -Dvclient.startPage=MODS opens that page straight away.
            try {
                navigate(Page.valueOf(startPage.strip().toUpperCase(java.util.Locale.ROOT)));
            } catch (IllegalArgumentException e) {
                appendLog("Unknown vclient.startPage value: " + startPage);
            }
        }
        if (Boolean.getBoolean("vclient.autoLaunch") && account != null) {
            // Debugging aid: -Dvclient.autoLaunch=true starts the game a few seconds after the launcher opens,
            // once the version list has loaded.
            javafx.animation.PauseTransition wait = new javafx.animation.PauseTransition(javafx.util.Duration.seconds(5));
            wait.setOnFinished(event -> {
                if (versionPicker != null && versionPicker.getValue() != null && playButton != null && !playButton.isDisabled()) {
                    appendLog("Auto launch: starting the game.");
                    launchGame(null);
                } else {
                    appendLog("Auto launch skipped: the launcher was not ready (no version selected yet).");
                }
            });
            wait.play();
        }
        startBackendTasks();
        // Dark combo-box popups, titled panes and progress bars for every scene.
        stage.sceneProperty().addListener((observable, was, scene) -> attachStylesheet(scene));
        attachStylesheet(stage.getScene());
        if (!settings.onboardingDone()) Platform.runLater(this::maybeShowOnboarding);
    }

    /** Writes the shared stylesheet next to the settings and adds it to {@code scene}. */
    private void attachStylesheet(Scene scene) {
        if (scene == null) return;
        try {
            Path sheet = Path.of(System.getenv().getOrDefault("APPDATA", System.getProperty("user.home")),
                    "V-Client", "cache", "launcher-dark.css");
            Files.createDirectories(sheet.getParent());
            Files.writeString(sheet, LAUNCHER_CSS, java.nio.charset.StandardCharsets.UTF_8);
            String uri = sheet.toUri().toString();
            if (!scene.getStylesheets().contains(uri)) scene.getStylesheets().add(uri);
        } catch (IOException e) {
            appendLog("Could not apply the dark control theme: " + e.getMessage());
        }
    }

    private static final String LAUNCHER_CSS = """
            .combo-box-popup > .list-view { -fx-background-color: #0c2036; -fx-border-color: #2a4d6e; -fx-border-radius: 8; -fx-background-radius: 8; }
            .combo-box-popup > .list-view .list-cell { -fx-background-color: #0c2036; -fx-text-fill: #eaf9ff; -fx-padding: 8 10 8 10; -fx-font-size: 14px; }
            .combo-box-popup > .list-view .list-cell:filled:hover { -fx-background-color: #11263D; }
            .combo-box-popup > .list-view .list-cell:filled:selected { -fx-background-color: #1e4260; -fx-text-fill: #ffffff; }
            .combo-box .list-cell { -fx-text-fill: #eaf9ff; -fx-background-color: transparent; }
            .combo-box .arrow-button { -fx-background-color: transparent; }
            .combo-box .arrow-button .arrow { -fx-background-color: #c4e6f5; }
            .combo-box:focused { -fx-background-color: #0c2036; -fx-border-color: #7cebff; }
            .titled-pane > .title { -fx-background-color: rgba(255, 255, 255, 0.07); -fx-background-radius: 8; }
            .titled-pane > .title > .text { -fx-fill: #d4f3ff; }
            .titled-pane > .title > .arrow-button .arrow { -fx-background-color: #c4e6f5; }
            .titled-pane > .content { -fx-background-color: transparent; -fx-border-color: transparent; }
            .progress-bar > .track { -fx-background-color: #11263D; -fx-background-radius: 6; }
            .progress-bar > .bar { -fx-background-radius: 6; }
            .scroll-bar { -fx-background-color: transparent; }
            """;

    /** Playtime, the recordings importer and the replay buffer all follow the game process. */
    private void startFeatureServices() {
        stats = PlayerStats.load(PlayerStats.defaultFile());
        stats.markSeen(java.time.LocalDate.now());
        stats.save();
        activityLog = new ActivityLog(ActivityLog.defaultFile());
        Theme.apply(settings.themeId(), settings.customAccent());
        recordingLibrary = new RecordingLibrary(RecordingLibrary.defaultFolder());
        replayBuffer = new ReplayBuffer(recordingLibrary.folder(), settings::clipHotkey,
                settings::replayBufferEnabled, settings::clipMicrophone, message -> replayStatus = message,
                file -> activityLog.add("Saved clip " + file.getFileName()),
                () -> settings.minecraftDirectory().resolve("vclient").resolve("recording.state"));
        GameSession.addListener(replayBuffer);
        GameSession.addListener(new RecordingWatcher(recordingLibrary, settings::minecraftDirectory,
                file -> {
                    appendLogLater("Imported recording " + file.getFileName());
                    activityLog.add("Imported recording " + file.getFileName());
                }));
        GameSession.addListener(new GameSession.Listener() {
            @Override
            public void started(String versionId, long startedAtMillis) {
                stats.recordLaunch(versionId);
                activityLog.add("Launched Minecraft " + versionId);
                stats.save();
                Platform.runLater(() -> LauncherApp.this.updateReadiness());
            }

            @Override
            public void ended(String versionId, long startedAtMillis, long endedAtMillis) {
                stats.addPlaytime((endedAtMillis - startedAtMillis) / 1000);
                activityLog.add("Played " + UiKit.playtime((endedAtMillis - startedAtMillis) / 1000) + " of " + versionId);
                Platform.runLater(() -> {
                    LauncherApp.this.collectBenchmark();
                    LauncherApp.this.updateReadiness();
                });
                Platform.runLater(() -> LauncherApp.this.updateReadiness());
            }
        });
    }

    private void showHome() {
        activePage = Page.HOME;
        settingsPage = false;
        updateNavigationState();
        StackPane root = baseLayout();
        VBox content = new VBox(22);
        content.setPadding(new Insets(38, 54, 32, 54));
        Label eyebrow = label("YOUR GAME, YOUR WAY", 11, ACCENT);
        eyebrow.setStyle(eyebrow.getStyle() + "-fx-font-weight: bold; -fx-letter-spacing: 2;");
        Label title = label("Ready to play?", 34, "#f3f6fc");
        Label subtitle = label("Choose a profile and jump back into your world.", 14, MUTED);
        VBox heading = new VBox(8, eyebrow, title, subtitle);
        Region homeStatusDot = dot("#64728a");
        Label homeStatus = label("", 12, "#c9d3e6");
        HBox homeStatusRow = new HBox(8, homeStatusDot, homeStatus);
        homeStatusRow.setAlignment(Pos.CENTER_LEFT);
        loadServerStatus(homeStatus, homeStatusDot);
        VBox homeAnnouncements = announcementBox();

        // A short, friendly problem message (details and "Copy logs" are folded away) instead of raw stack traces.
        problemBox = new VBox(8);
        renderProblem();

        VBox versionCard = card();
        Label versionTitle = label("GAME VERSION", 11, MUTED);
        versionPicker = new ComboBox<>();
        versionPicker.setMaxWidth(Double.MAX_VALUE);
        versionPicker.setPrefHeight(48);
        versionPicker.setStyle("-fx-background-color: #0c2036; -fx-text-fill: #eaf9ff; -fx-font-size: 15px; -fx-border-color: #2a4d6e; -fx-border-radius: 8; -fx-background-radius: 8;");
        versionPicker.setPromptText("Scanning installed versions...");
        versionPicker.setCellFactory(list -> versionChoiceCell());
        versionPicker.setButtonCell(versionChoiceCell());
        versionPicker.valueProperty().addListener((observable, oldVersion, newVersion) -> {
            if (newVersion != null) {
                selectedVersionId = newVersion.id();
                versionStatusLabel.setText("Selected " + newVersion.id() + " · " + newVersion.status());
                if (newVersion.available() != null && newVersion.installed() == null) {
                    downloadSelectedVersion(newVersion);
                }
            }
            updateInstallButton();
            updateReadiness();
        });
        // While the version list loads, a pulsing placeholder sits under the picker instead of an empty box.
        Region versionSkeleton = Widgets.skeleton(0, 12);
        versionSkeleton.visibleProperty().bind(versionPicker.disabledProperty());
        versionSkeleton.managedProperty().bind(versionSkeleton.visibleProperty());
        versionCard.getChildren().addAll(versionTitle, versionPicker, versionSkeleton);
        javafx.scene.layout.FlowPane versionActions = new javafx.scene.layout.FlowPane(10, 10);
        versionActions.setAlignment(Pos.CENTER_LEFT);
        // INSTALL only while the chosen version is missing; once it is installed this becomes a small REPAIR action.
        installVersionButton = button("INSTALL", ACCENT, 12);
        installVersionButton.setOnAction(event -> {
            VersionChoice chosen = versionPicker.getValue();
            if (chosen != null && chosen.installed() != null) repairSelectedVersion();
            else installSelectedVersion();
        });
        refreshVersionsButton = button("REFRESH VERSIONS", "#11263D", 11);
        refreshVersionsButton.setOnAction(event -> refreshVersions(selectedVersionId));
        versionActions.getChildren().addAll(installVersionButton, refreshVersionsButton);
        versionStatusLabel = label("Fetching the Mojang version catalog...", 12, MUTED);
        versionStatusLabel.setWrapText(true);
        installProgress = new javafx.scene.control.ProgressBar(0);
        installProgress.setMaxWidth(Double.MAX_VALUE);
        installProgress.setStyle("-fx-accent: " + ACCENT + ";");
        installProgressLabel = label("", 12, "#d4f3ff");
        VBox progressBox = new VBox(6, installProgress, installProgressLabel);
        progressBox.setVisible(false);
        progressBox.managedProperty().bind(progressBox.visibleProperty());
        installProgress.setUserData(progressBox);
        HBox offlineRow = Widgets.switchRow("Offline mode",
                "Nothing is contacted and nothing is downloaded while this is on.", settings.offlineMode(), ACCENT, offline -> {
                    settings.setOfflineMode(offline);
                    saveSettings();
                    appendLog(offline
                            ? "Offline mode on: V-Client will not contact Mojang, Modrinth, skin servers, or download anything."
                            : "Offline mode off: V-Client can download versions, libraries, assets, and Java again.");
                    updateInstallButton();
                    updateReadiness();
                    refreshVersions(selectedVersionId);
                    if (!offline) runConnectionTest();
                    else renderChecklist(List.of(), true);
                });
        versionCard.getChildren().addAll(versionActions, progressBox, versionStatusLabel, offlineRow);

        // Short folder label with an Open folder button, plus quick access to crash reports.
        gameFolderLabel = label("Game folder: " + Widgets.shortPath(settings.minecraftDirectory()), 13, "#d4f3ff");
        gameFolderLabel.setTooltip(new javafx.scene.control.Tooltip(settings.minecraftDirectory().toString()));
        Button openFolder = button("OPEN FOLDER", "#11263D", 11);
        openFolder.setOnAction(event -> {
            if (!Widgets.openFolder(settings.minecraftDirectory())) {
                versionStatusLabel.setText("Could not open " + settings.minecraftDirectory());
            }
        });
        Button crashButton = button("CRASH REPORTS", "#11263D", 11);
        crashButton.setOnAction(event -> showCrashReports(null));
        Region folderSpacer = new Region();
        HBox.setHgrow(folderSpacer, Priority.ALWAYS);
        HBox folderRow = new HBox(10, gameFolderLabel, folderSpacer, openFolder, crashButton);
        folderRow.setAlignment(Pos.CENTER_LEFT);
        versionCard.getChildren().add(folderRow);

        // Connection checklist (DNS, TLS, Mojang, Backend), run automatically at startup.
        connectionTestButton = button("TEST AGAIN", "#11263D", 11);
        connectionTestButton.setOnAction(event -> runConnectionTest());
        connectionResultLabel = label("Connection check", 12, MUTED);
        Label checklistTitle = label("CONNECTION CHECK", 11, MUTED);
        Region checklistSpacer = new Region();
        HBox.setHgrow(checklistSpacer, Priority.ALWAYS);
        HBox checklistHeader = new HBox(12, checklistTitle, connectionResultLabel, checklistSpacer, connectionTestButton);
        checklistHeader.setAlignment(Pos.CENTER_LEFT);
        checklistBox = new VBox(8);
        versionCard.getChildren().addAll(checklistHeader, checklistBox);

        HBox launchRow = new HBox(14);
        launchRow.setAlignment(Pos.CENTER_LEFT);
        playButton = button("▶    LAUNCH", ACCENT, 17);
        playButton.setPrefHeight(54);
        HBox.setHgrow(playButton, Priority.ALWAYS);
        playButton.setMaxWidth(Double.MAX_VALUE);
        playButton.setOnAction(event -> launchGame(null));
        singleplayerButton = button(smpButtonText, "#11263D", 14);
        singleplayerButton.setPrefHeight(54);
        singleplayerButton.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(singleplayerButton, Priority.ALWAYS);
        singleplayerButton.setOnAction(event -> launchGame(SERVER_LIST.getFirst()));
        Button settingsButton = button("SETTINGS", "#11263D", 12);
        settingsButton.setPrefHeight(54);
        settingsButton.setOnAction(event -> showSettings());
        launchRow.getChildren().addAll(playButton, singleplayerButton, settingsButton);

        // "Launcher ready" reflects the real state: green ready, yellow working / degraded, red blocked.
        readyDot = dot(Widgets.YELLOW);
        readyLabel = label("CHECKING…", 12, "#d4f3ff");
        HBox statusRow = new HBox(8, readyDot, readyLabel);
        statusRow.setAlignment(Pos.CENTER_LEFT);

        log = new TextArea();
        log.setEditable(false);
        log.setWrapText(true);
        log.setPrefRowCount(10);
        log.setStyle("-fx-control-inner-background: rgba(7, 19, 33, 0.82); -fx-text-fill: #d4f3ff; -fx-font-family: 'Consolas'; -fx-font-size: 12px; -fx-background-color: rgba(7, 19, 33, 0.82); -fx-border-color: #1e4260; -fx-border-radius: 8; -fx-background-radius: 8;");
        log.setText(String.join(System.lineSeparator(), logLines));
        Button copyLogs = button("COPY LOGS", "#11263D", 11);
        copyLogs.setOnAction(event -> {
            copyLogsToClipboard();
            copyLogs.setText("COPIED");
        });
        VBox detailsBody = new VBox(10, log, copyLogs);
        javafx.scene.control.TitledPane launchDetails = Widgets.details("Details — launch output", detailsBody);
        // Lunar-style home: a big art banner with a centred LAUNCH button, then Latest News beside Friends.
        versionCard.getChildren().removeAll(versionTitle, versionPicker, versionSkeleton);
        playButton.setText("▶    LAUNCH");
        playButton.setPrefHeight(54);
        playButton.setMinWidth(260);
        playButton.setMaxWidth(260);
        HBox.setHgrow(playButton, Priority.NEVER);
        playButton.setStyle(playButton.getStyle() + " -fx-font-size: 17px; -fx-background-radius: 14;"
                + " -fx-effect: dropshadow(gaussian, rgba(0,207,255,0.65), 26, 0.2, 0, 0);");
        singleplayerButton.setPrefHeight(34);
        singleplayerButton.setMaxWidth(Double.MAX_VALUE);
        versionPicker.setPrefHeight(40);
        versionPicker.setMaxWidth(260);
        versionPicker.setMinWidth(260);
        Canvas heroArt = new Canvas(900, 300);
        StackPane hero = new StackPane(heroArt);
        hero.setMinHeight(300);
        hero.setPrefHeight(300);
        // The artwork follows the banner's size and takes no part in layout: a Canvas cannot shrink, so sizing the
        // banner from it made the centred LAUNCH button drift sideways and out of view.
        heroArt.setManaged(false);
        heroArt.widthProperty().bind(hero.widthProperty());
        heroArt.heightProperty().bind(hero.heightProperty());
        heroArt.widthProperty().addListener(observable -> drawHeroArt(heroArt));
        heroArt.heightProperty().addListener(observable -> drawHeroArt(heroArt));
        hero.setMinWidth(0);
        javafx.scene.shape.Rectangle heroClip = new javafx.scene.shape.Rectangle();
        heroClip.setArcWidth(40);
        heroClip.setArcHeight(40);
        heroClip.widthProperty().bind(hero.widthProperty());
        heroClip.heightProperty().bind(hero.heightProperty());
        hero.setClip(heroClip);
        VBox launchBox = new VBox(10, playButton, versionPicker, statusRow);
        launchBox.setAlignment(Pos.CENTER);
        launchBox.setMaxWidth(280);
        launchBox.setMaxHeight(Region.USE_PREF_SIZE);
        statusRow.setAlignment(Pos.CENTER);
        hero.getChildren().add(launchBox);
        StackPane.setAlignment(launchBox, Pos.CENTER);
        hero.setStyle("-fx-background-color: rgba(11, 28, 48, 0.9); -fx-background-radius: 20; -fx-border-color: rgba(124,235,255,0.35);"
                + " -fx-border-radius: 20; -fx-effect: dropshadow(gaussian, rgba(0,207,255,0.20), 28, 0.1, 0, 0);");

        // Latest news (left) and friends (right).
        Label newsTitle = label("LATEST NEWS", 12, "#eaf9ff");
        newsTitle.setStyle(newsTitle.getStyle() + "-fx-font-weight: bold; -fx-letter-spacing: 1.5;");
        Button allNews = button("View all news", "#11263D", 10);
        allNews.setOnAction(event -> navigate(Page.NEWS));
        Region newsSpacer = new Region();
        HBox.setHgrow(newsSpacer, Priority.ALWAYS);
        HBox newsHeader = new HBox(10, newsTitle, newsSpacer, allNews);
        newsHeader.setAlignment(Pos.CENTER_LEFT);
        VBox newsColumn = new VBox(12, newsHeader, launchEventBanner(), homeAnnouncements);
        HBox.setHgrow(newsColumn, Priority.ALWAYS);

        Label friendsTitle = label("FRIENDS", 12, "#eaf9ff");
        friendsTitle.setStyle(friendsTitle.getStyle() + "-fx-font-weight: bold; -fx-letter-spacing: 1.5;");
        Button allFriends = button("View friends list", "#11263D", 10);
        allFriends.setOnAction(event -> navigate(Page.FRIENDS));
        Region friendsSpacer = new Region();
        HBox.setHgrow(friendsSpacer, Priority.ALWAYS);
        HBox friendsHeader = new HBox(10, friendsTitle, friendsSpacer, allFriends);
        friendsHeader.setAlignment(Pos.CENTER_LEFT);
        VBox friendsBody = new VBox(8);
        if (localFriends.isEmpty()) {
            Label none = label("No friends added yet. Open the friends list to add some.", 12, MUTED);
            none.setWrapText(true);
            friendsBody.getChildren().add(none);
        } else {
            for (String friend : localFriends.stream().limit(6).toList()) {
                Label friendName = label(friend, 13, "#eaf9ff");
                HBox friendRow = new HBox(10, dot("#4a6a85"), friendName);
                friendRow.setAlignment(Pos.CENTER_LEFT);
                friendRow.setPadding(new Insets(8, 12, 8, 12));
                friendRow.setStyle("-fx-background-color: rgba(17, 38, 61, 0.75); -fx-background-radius: 10;"
                        + " -fx-border-color: rgba(124,235,255,0.18); -fx-border-radius: 10;");
                friendsBody.getChildren().add(friendRow);
            }
        }
        VBox friendsColumn = new VBox(12, friendsHeader, friendsBody);
        friendsColumn.setMinWidth(280);
        friendsColumn.setPrefWidth(300);
        friendsColumn.setMaxWidth(320);
        HBox lowerRow = new HBox(22, newsColumn, friendsColumn);
        lowerRow.setAlignment(Pos.TOP_LEFT);

        javafx.scene.control.TitledPane setup = Widgets.details("Game setup, connection check and folder", versionCard);
        content.getChildren().addAll(hero, lowerRow, homeStatusRow, problemBox, setup, singleplayerButton, launchDetails);
        setPageContent(root, content);
        stage.setScene(new Scene(root, stage.getWidth(), stage.getHeight()));
        updateInstallButton();
        updateReadiness();
        refreshVersions(selectedVersionId);
        if (settings.offlineMode()) {
            connection = Connection.OFFLINE;
            renderChecklist(List.of(), true);
        } else if (!startupChecklistRan) {
            startupChecklistRan = true;
            runConnectionTest();
        } else {
            runConnectionTest();
        }
    }

    // ---- Readiness light, install/repair button, problem banner ----

    /** Recomputes the "Launcher ready" light from what is really going on. Safe to call from any FX-thread code. */
    private void updateReadiness() {
        if (readyDot == null || readyLabel == null) return;
        VersionChoice choice = versionPicker == null ? null : versionPicker.getValue();
        String color = Widgets.GREEN;
        String text = "LAUNCHER READY";
        if (account == null) {
            color = Widgets.RED;
            text = "NO ACCOUNT — SIGN IN FIRST";
        } else if (GameSession.running()) {
            text = "GAME RUNNING";
        } else if (!versionsDownloading.isEmpty()) {
            color = Widgets.YELLOW;
            text = "INSTALLING " + versionsDownloading.iterator().next().toUpperCase(java.util.Locale.ROOT) + "…";
        } else if (connection == Connection.CHECKING) {
            color = Widgets.YELLOW;
            text = "CHECKING CONNECTION…";
        } else if (!lastProblem.isEmpty()) {
            color = Widgets.RED;
            text = "LAST LAUNCH FAILED — SEE DETAILS";
        } else if (connection == Connection.FAILED && !settings.offlineMode()) {
            color = Widgets.RED;
            text = "CONNECTION PROBLEM — SEE THE CHECKLIST";
        } else if (versionPicker != null && choice == null) {
            color = Widgets.YELLOW;
            text = versionPicker.isDisable() ? "LOADING VERSIONS…" : "NO VERSION SELECTED";
        } else if (choice != null && choice.installed() == null) {
            color = Widgets.YELLOW;
            text = "VERSION NOT INSTALLED";
        } else if (connection == Connection.WAKING) {
            color = Widgets.YELLOW;
            text = "SERVER WAKING UP…";
        } else if (connection == Connection.DEGRADED) {
            text = "LAUNCHER READY · USING SAVED SERVER INFO";
        } else if (settings.offlineMode()) {
            text = "LAUNCHER READY · OFFLINE MODE";
        }
        readyDot.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 50%;");
        readyLabel.setText(text);
    }

    /** INSTALL (prominent) while the chosen version is missing, otherwise a small REPAIR action. */
    private void updateInstallButton() {
        if (installVersionButton == null) return;
        VersionChoice choice = versionPicker == null ? null : versionPicker.getValue();
        boolean installed = choice != null && choice.installed() != null;
        boolean busy = choice != null && versionsDownloading.contains(choice.id());
        boolean visible = choice != null && (choice.available() != null || installed);
        installVersionButton.setVisible(visible);
        installVersionButton.managedProperty().bind(installVersionButton.visibleProperty());
        if (installed) {
            installVersionButton.setText("REPAIR");
            installVersionButton.setStyle("-fx-background-color: transparent; -fx-text-fill: #c4e6f5; -fx-font-size: 11px;"
                    + " -fx-border-color: #2a4d6e; -fx-border-radius: 7; -fx-background-radius: 7; -fx-padding: 6 12 6 12; -fx-cursor: hand;");
        } else {
            installVersionButton.setText("INSTALL");
            installVersionButton.setStyle("-fx-background-color: " + ACCENT + "; -fx-text-fill: #071321; -fx-font-size: 13px;"
                    + " -fx-font-weight: bold; -fx-background-radius: 9; -fx-padding: 12 22 12 22; -fx-cursor: hand;");
        }
        installVersionButton.setDisable(settings.offlineMode() || busy);
    }

    private void repairSelectedVersion() {
        VersionChoice selected = versionPicker == null ? null : versionPicker.getValue();
        if (selected == null) return;
        if (selected.available() != null) {
            appendLog("Repair: re-checking every file of " + selected.id() + " and downloading anything missing or damaged.");
            downloadSelectedVersion(selected);
            return;
        }
        // A mod-loader profile (for example V-Client 1.21.11) is repaired by reinstalling its bundled files.
        Path directory = settings.minecraftDirectory();
        versionStatusLabel.setText("Repairing " + selected.id() + "…");
        executor.execute(() -> {
            try {
                VClientModInstaller.ensureInstalled(directory, line -> Platform.runLater(() -> appendLog(line)));
                BundledResourcePack.ensureInstalled(directory, line -> Platform.runLater(() -> appendLog(line)));
                Platform.runLater(() -> {
                    versionStatusLabel.setText(selected.id() + " · repaired.");
                    refreshVersions(selectedVersionId);
                });
            } catch (IOException e) {
                Platform.runLater(() -> reportProblem(e));
            }
        });
    }

    /** Remembers a problem and shows it as a short message; the technical text stays under "Details". */
    private void reportProblem(Throwable error) {
        lastError = error;
        FriendlyError.Message message = FriendlyError.of(error);
        lastProblem = message.title();
        appendLog("Problem: " + message.title() + " — " + message.message());
        renderProblem();
        updateReadiness();
    }

    private Throwable lastError;

    private void renderProblem() {
        if (problemBox == null) return;
        problemBox.getChildren().clear();
        if (lastError == null || lastProblem.isEmpty()) return;
        FriendlyError.Message message = FriendlyError.of(lastError);
        Label heading = label("⚠  " + message.title(), 15, "#ffb4bd");
        heading.setStyle(heading.getStyle() + "-fx-font-weight: bold;");
        Label text = label(message.message(), 13, "#eaf9ff");
        text.setWrapText(true);
        TextArea raw = new TextArea(message.details() + (settings.debugMode() ? System.lineSeparator() + BackendClient.stackTrace(lastError) : ""));
        raw.setEditable(false);
        raw.setWrapText(true);
        raw.setPrefRowCount(6);
        raw.setStyle("-fx-control-inner-background: rgba(7, 19, 33, 0.9); -fx-text-fill: #d4f3ff; -fx-font-family: 'Consolas'; -fx-font-size: 12px;");
        Button copy = button("COPY LOGS", "#11263D", 11);
        copy.setOnAction(event -> {
            copyLogsToClipboard();
            copy.setText("COPIED");
        });
        Button crashes = button("CRASH REPORTS", "#11263D", 11);
        crashes.setOnAction(event -> showCrashReports(null));
        Button dismiss = button("DISMISS", "#11263D", 11);
        dismiss.setOnAction(event -> {
            lastError = null;
            lastProblem = "";
            renderProblem();
            updateReadiness();
        });
        HBox actions = new HBox(10, copy, crashes, dismiss);
        actions.setAlignment(Pos.CENTER_LEFT);
        VBox box = new VBox(8, heading, text, Widgets.details("Details", raw), actions);
        box.setPadding(new Insets(14, 18, 14, 18));
        box.setStyle("-fx-background-color: rgba(120, 30, 50, 0.32); -fx-background-radius: 12; -fx-border-color: rgba(229, 98, 111, 0.6); -fx-border-radius: 12;");
        problemBox.getChildren().add(box);
    }

    /** Everything useful for a bug report: versions, the launcher log, and the last error's technical details. */
    private void copyLogsToClipboard() {
        StringBuilder text = new StringBuilder();
        text.append("V-Client ").append(AppInfo.VERSION).append(" · ").append(System.getProperty("os.name"))
                .append(" · Java ").append(System.getProperty("java.version")).append(System.lineSeparator());
        text.append("TLS: ").append(PlatformTls.truststoreSummary()).append(System.lineSeparator());
        text.append("Offline mode: ").append(settings.offlineMode()).append(" · Game folder: ")
                .append(settings.minecraftDirectory()).append(System.lineSeparator()).append(System.lineSeparator());
        if (lastError != null) {
            text.append("Last problem: ").append(PlatformTls.describeFailure(lastError)).append(System.lineSeparator())
                    .append(BackendClient.stackTrace(lastError)).append(System.lineSeparator());
        }
        text.append(String.join(System.lineSeparator(), logLines));
        Path logs = settings.minecraftDirectory().resolve("logs");
        appendDiagnosticFile(text, logs.resolve("vclient-launch.log"), "V-Client launch log", 18_000);
        appendDiagnosticFile(text, logs.resolve("latest.log"), "Minecraft latest.log", 12_000);
        CrashReports.list(settings.minecraftDirectory(), 1).stream().findFirst().ifPresent(report ->
                appendDiagnosticFile(text, report.file(), "Newest crash report", 20_000));
        ClipboardContent clip = new ClipboardContent();
        clip.putString(text.toString());
        Clipboard.getSystemClipboard().setContent(clip);
    }

    // ---- Connection checklist ----

    private void renderChecklist(List<NetworkDiagnostics.Check> checks, boolean offline) {
        VBox box = checklistBox;
        if (box == null) return;
        box.getChildren().clear();
        if (offline) {
            connection = Connection.OFFLINE;
            connectionResultLabel.setText("Offline mode is on — nothing is contacted.");
            Label note = label("Turn Offline mode off to check DNS, TLS, Mojang and the V-Client server.", 12, MUTED);
            note.setWrapText(true);
            box.getChildren().add(note);
            updateReadiness();
            return;
        }
        for (NetworkDiagnostics.Check check : checks) {
            // The V-Client server is optional: if it cannot be reached the launcher uses saved data, so this is grey, never red.
            boolean optional = check.name().equals("Backend");
            String color = check.passed() ? Widgets.GREEN : optional ? "#8a93a8" : Widgets.RED;
            Label name = label(check.name(), 13, "#eaf9ff");
            name.setStyle(name.getStyle() + "-fx-font-weight: bold;");
            name.setMinWidth(76);
            Label state = label(check.passed() ? "OK" : optional ? "UNAVAILABLE (using saved data)" : "FAILED", 12, color);
            state.setStyle(state.getStyle() + "-fx-font-weight: bold;");
            HBox line = new HBox(10, dot(color), name, state);
            line.setAlignment(Pos.CENTER_LEFT);
            VBox item = new VBox(3, line);
            if (!check.passed() && !check.hint().isBlank()) {
                Label hint = label((optional ? "" : "Fix: ") + check.hint(), 12, optional ? MUTED : "#ffd9a0");
                hint.setWrapText(true);
                hint.setPadding(new Insets(0, 0, 0, 20));
                item.getChildren().add(hint);
            }
            box.getChildren().add(item);
        }
    }

    private void showChecklistLoading() {
        if (checklistBox == null) return;
        checklistBox.getChildren().setAll(Widgets.skeletonBlock(4));
    }

    private void runConnectionTest() {
        if (settings.offlineMode()) {
            renderChecklist(List.of(), true);
            return;
        }
        if (connectionTestButton == null || connection == Connection.CHECKING) return;
        Button button = connectionTestButton;
        Label summary = connectionResultLabel;
        button.setDisable(true);
        button.setText("TESTING...");
        summary.setText("Checking DNS, TLS, Mojang and the V-Client server…");
        connection = Connection.CHECKING;
        showChecklistLoading();
        updateReadiness();
        String backendAddress = settings.backendUrl();
        executor.execute(() -> {
            List<NetworkDiagnostics.Check> checks = NetworkDiagnostics.checklist(
                    backendAddress, line -> Platform.runLater(() -> appendLog(line)));
            Platform.runLater(() -> {
                button.setDisable(false);
                button.setText("TEST AGAIN");
                boolean core = checks.stream().filter(check -> !check.name().equals("Backend")).allMatch(NetworkDiagnostics.Check::passed);
                NetworkDiagnostics.Check backendCheck = checks.stream().filter(check -> check.name().equals("Backend")).findFirst().orElse(null);
                if (!core) connection = Connection.FAILED;
                else if (backendCheck != null && !backendCheck.passed()) {
                    connection = backendCheck.detail().startsWith("Server waking up") ? Connection.WAKING : Connection.DEGRADED;
                } else connection = Connection.OK;
                summary.setText(switch (connection) {
                    case OK -> "All checks passed.";
                    case WAKING -> "Server is waking up — this can take a minute.";
                    case DEGRADED -> "Game connection is fine; the V-Client server is unreachable.";
                    default -> "Some checks failed — see the fixes below.";
                });
                renderChecklist(checks, false);
                appendLog("Connection check: " + checks.stream()
                        .map(check -> check.name() + (check.passed() ? " OK" : " FAILED")).collect(java.util.stream.Collectors.joining(", ")));
                updateReadiness();
            });
        });
    }

    // ---- Crash reports ----

    /** Lists the game's crash reports with a viewer; {@code focus} selects one (the newest by default). */
    private void showCrashReports(CrashReports.Report focus) {
        Path gameDirectory = settings.minecraftDirectory();
        List<CrashReports.Report> reports = CrashReports.list(gameDirectory, 50);
        Dialog<Void> dialog = new Dialog<>();
        dialog.initOwner(stage);
        dialog.setTitle("Crash reports");
        dialog.setHeaderText(reports.isEmpty() ? "No crash reports found" : reports.size() + " crash report" + (reports.size() == 1 ? "" : "s"));
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        TextArea viewer = new TextArea(reports.isEmpty() ? "Minecraft has not written any crash reports in " + gameDirectory.resolve("crash-reports") + "." : "");
        viewer.setEditable(false);
        viewer.setWrapText(false);
        viewer.setPrefSize(640, 400);
        viewer.setStyle("-fx-font-family: 'Consolas'; -fx-font-size: 12px;");
        ListView<CrashReports.Report> list = new ListView<>();
        list.getItems().setAll(reports);
        list.setPrefWidth(250);
        list.setCellFactory(view -> new ListCell<>() {
            @Override
            protected void updateItem(CrashReports.Report item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.label() + "\n" + item.summary());
            }
        });
        list.getSelectionModel().selectedItemProperty().addListener((observable, was, report) -> {
            if (report == null) return;
            try {
                viewer.setText(CrashReports.read(report));
                viewer.positionCaret(0);
            } catch (IOException e) {
                viewer.setText("Could not read " + report.file() + ": " + e.getMessage());
            }
        });
        Button copy = button("COPY REPORT", "#11263D", 11);
        copy.setOnAction(event -> {
            ClipboardContent clip = new ClipboardContent();
            clip.putString(viewer.getText());
            Clipboard.getSystemClipboard().setContent(clip);
        });
        Button openFolder = button("OPEN FOLDER", "#11263D", 11);
        openFolder.setOnAction(event -> Widgets.openFolder(gameDirectory.resolve("crash-reports")));
        HBox actions = new HBox(10, copy, openFolder);
        VBox right = new VBox(10, viewer, actions);
        HBox.setHgrow(right, Priority.ALWAYS);
        dialog.getDialogPane().setContent(new HBox(12, list, right));
        dialog.getDialogPane().setPrefWidth(960);
        if (!reports.isEmpty()) {
            CrashReports.Report initial = focus == null ? reports.getFirst() : reports.stream()
                    .filter(report -> report.file().equals(focus.file())).findFirst().orElse(reports.getFirst());
            list.getSelectionModel().select(initial);
        }
        dialog.show();
    }

    // ---- First-run onboarding ----

    private void maybeShowOnboarding() {
        if (settings.onboardingDone()) return;
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.initOwner(stage);
        dialog.setTitle("Welcome to V-Client");
        dialog.setHeaderText("Let's get you ready to play");
        ButtonType finish = new ButtonType("Get started", javafx.scene.control.ButtonBar.ButtonData.OK_DONE);
        ButtonType skip = new ButtonType("Skip", javafx.scene.control.ButtonBar.ButtonData.CANCEL_CLOSE);
        dialog.getDialogPane().getButtonTypes().addAll(finish, skip);

        Label intro = label("V-Client keeps its own private Minecraft folder, so it never touches your other launchers. "
                + "Three quick choices, all changeable later in Settings.", 13, "#222");
        intro.setWrapText(true);
        intro.setStyle("-fx-font-size: 14px;");
        Label memoryLabel = new Label("Game memory: " + settings.memoryGb() + " GB");
        Slider memory = new Slider(1, LauncherSettings.maxMemory(), settings.memoryGb());
        memory.setMajorTickUnit(1);
        memory.setMinorTickCount(0);
        memory.setSnapToTicks(true);
        memory.valueProperty().addListener((observable, was, now) -> {
            memoryLabel.setText("Game memory: " + now.intValue() + " GB");
            settings.setMemoryGb(now.intValue());
        });
        Label memoryHint = new Label("4–6 GB suits most setups. Leave some RAM for Windows.");
        memoryHint.setStyle("-fx-font-size: 12px; -fx-text-fill: #555;");
        HBox online = Widgets.switchRow("Download Minecraft (go online)",
                "Turns Offline mode off so V-Client can fetch game versions and Java. Recommended.",
                !settings.offlineMode(), ACCENT, goOnline -> settings.setOfflineMode(!goOnline));
        Button importProfile = button("IMPORT A PROFILE FILE", "#11263D", 11);
        importProfile.setOnAction(event -> importProfileFile());
        Label importHint = new Label("Already set up on another PC? Import the profile you exported there.");
        importHint.setStyle("-fx-font-size: 12px; -fx-text-fill: #555;");
        VBox body = new VBox(14, intro, new Separator(), memoryLabel, memory, memoryHint, new Separator(), online,
                new Separator(), importProfile, importHint);
        body.setPrefWidth(520);
        dialog.getDialogPane().setContent(body);
        dialog.showAndWait();
        settings.setOnboardingDone(true);
        saveSettings();
        // The memory / offline choices change what the home page shows; a sign-in screen is left as it is.
        if (account != null && activePage == Page.HOME) showHome();
    }

    // ---- Profile import / export ----

    private void exportProfileFile() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Export V-Client profile");
        chooser.setInitialFileName("v-client-profile.json");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("V-Client profile", "*.json"));
        var target = chooser.showSaveDialog(stage);
        if (target == null) return;
        try {
            ProfileTransfer.export(settings, target.toPath());
            appendLog("Exported profile to " + target);
            if (status != null) status.setText("Profile exported.");
        } catch (IOException e) {
            reportProblem(e);
            showError("Could not export the profile", e);
        }
    }

    private void importProfileFile() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Import V-Client profile");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("V-Client profile", "*.json"));
        var source = chooser.showOpenDialog(stage);
        if (source == null) return;
        try {
            String summary = ProfileTransfer.importInto(settings, source.toPath());
            saveSettings();
            Theme.apply(settings.themeId(), settings.customAccent());
            appendLog(summary);
            if (status != null) status.setText(summary);
            if (settingsPage) showSettings();
        } catch (IOException e) {
            showError("Could not import the profile", e);
        }
    }

    private void showSettings() {
        activePage = Page.SETTINGS;
        settingsPage = true;
        updateNavigationState();
        StackPane root = baseLayout();
        VBox content = new VBox(22);
        content.setPadding(new Insets(38, 54, 34, 54));
        Label title = label("Settings", 32, "#f3f6fc");
        Label subtitle = label("Tune your game setup. Changes are saved on this device.", 14, MUTED);

        VBox directoryCard = card();
        Label directoryTitle = label("MINECRAFT DIRECTORY", 11, MUTED);
        HBox directoryRow = new HBox(10);
        directoryRow.setAlignment(Pos.CENTER_LEFT);
        TextField directoryField = new TextField(settings.minecraftDirectory().toString());
        directoryField.setEditable(false);
        directoryField.setMaxWidth(Double.MAX_VALUE);
        directoryField.setStyle(fieldStyle());
        HBox.setHgrow(directoryField, Priority.ALWAYS);
        Button selectFolderButton = button("SELECT FOLDER", "#11263D", 11);
        selectFolderButton.setOnAction(event -> {
            DirectoryChooser chooser = new DirectoryChooser();
            chooser.setTitle("Choose Minecraft directory");
            if (settings.minecraftDirectory().toFile().isDirectory()) {
                chooser.setInitialDirectory(settings.minecraftDirectory().toFile());
            }
            var selected = chooser.showDialog(stage);
            if (selected != null) {
                Path selectedDirectory = LauncherSettings.normalizeMinecraftDirectory(selected.toPath());
                settings.setMinecraftDirectory(selectedDirectory);
                directoryField.setText(selectedDirectory.toString());
                saveSettings();
                refreshVersions();
            }
        });
        directoryRow.getChildren().addAll(directoryField, selectFolderButton);
        Label privateFolderHint = label(
                "This is V-Client's private Minecraft folder. Import installed game files below to copy them here without deleting the original or downloading anything.",
                11, MUTED);
        privateFolderHint.setWrapText(true);
        Button importButton = button("IMPORT EXISTING GAME FILES", ACCENT, 10);
        importButton.setOnAction(event -> importLocalMinecraftFiles(importButton));
        directoryCard.getChildren().addAll(directoryTitle, directoryRow, privateFolderHint, importButton);

        VBox memoryCard = card();
        HBox memoryHeading = new HBox();
        memoryHeading.setAlignment(Pos.CENTER_LEFT);
        Label memoryTitle = label("MAXIMUM GAME MEMORY", 11, MUTED);
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        Label memoryValue = label(settings.memoryGb() + " GB", 17, "#f3f6fc");
        memoryHeading.getChildren().addAll(memoryTitle, spacer, memoryValue);
        Slider memorySlider = new Slider(1, LauncherSettings.maxMemory(), settings.memoryGb());
        memorySlider.setMajorTickUnit(1);
        memorySlider.setMinorTickCount(0);
        memorySlider.setSnapToTicks(true);
        memorySlider.setShowTickMarks(true);
        memorySlider.setStyle("-fx-control-inner-background: " + ACCENT + "; -fx-accent: " + ACCENT + ";");
        Label memoryHint = label("More memory can help large modpacks. Leave some RAM for Windows.", 12, MUTED);
        memorySlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            int gigabytes = newValue.intValue();
            memoryValue.setText(gigabytes + " GB");
            settings.setMemoryGb(gigabytes);
            saveSettings();
        });
        memoryCard.getChildren().addAll(memoryHeading, memorySlider, memoryHint);

        VBox javaCard = card();
        Label javaTitle = label("MINECRAFT JAVA RUNTIME", 11, MUTED);
        ComboBox<String> javaChoice = new ComboBox<>();
        String automaticJava = "Automatic (recommended: the version Minecraft needs)";
        java.util.Map<Integer, String> javaNames = new java.util.LinkedHashMap<>();
        javaNames.put(0, automaticJava);
        javaNames.put(17, "Always use Java 17");
        javaNames.put(21, "Always use Java 21");
        javaNames.put(25, "Always use Java 25");
        javaChoice.getItems().setAll(javaNames.values());
        javaChoice.setValue(javaNames.getOrDefault(settings.javaMajorOverride(), automaticJava));
        javaChoice.setMaxWidth(Double.MAX_VALUE);
        javaChoice.setStyle("-fx-background-color: #0c2036; -fx-text-fill: #eaf9ff; -fx-font-size: 15px; -fx-border-color: #2a4d6e; -fx-border-radius: 8; -fx-background-radius: 8;");
        Label javaStatus = label("Checking for an installed 64-bit Java 25 runtime...", 11, MUTED);
        javaStatus.setWrapText(true);
        javaChoice.valueProperty().addListener((observable, oldChoice, newChoice) -> {
            int major = javaNames.entrySet().stream().filter(entry -> entry.getValue().equals(newChoice))
                    .map(java.util.Map.Entry::getKey).findFirst().orElse(0);
            settings.setJavaMajorOverride(major);
            saveSettings();
            if (major != 0 && major < 21) javaStatus.setText("Minecraft 1.21 needs Java 21 or newer; an older runtime will fail to start it. Use Automatic unless you know you need this.");
        });
        TextField jvmField = new TextField(settings.jvmArguments());
        jvmField.setPromptText("e.g. -XX:+UseG1GC -Dfile.encoding=UTF-8");
        jvmField.setStyle(fieldStyle());
        Label jvmStatus = label("Extra JVM arguments (only -X…, -XX:… and -D… are accepted). Applied at the next launch.", 11, MUTED);
        jvmStatus.setWrapText(true);
        jvmField.textProperty().addListener((observable, was, now) -> {
            String problem = JvmArgs.validate(now);
            if (problem != null) {
                jvmStatus.setText(problem);
                jvmStatus.setStyle(jvmStatus.getStyle() + "-fx-text-fill: #ff9aa8;");
                return;
            }
            jvmStatus.setStyle(label("", 11, MUTED).getStyle());
            jvmStatus.setText("Saved. Applied at the next launch.");
            settings.setJvmArguments(now);
            saveSettings();
        });
        javaCard.getChildren().addAll(javaTitle, javaChoice, javaStatus, label("JVM ARGUMENTS", 11, MUTED), jvmField, jvmStatus);
        javaCard.getChildren().addAll(javaTitle, javaChoice, javaStatus);
        executor.execute(() -> {
            try {
                Path installedJava = JavaRuntimeManager.detectInstalledJava25();
                Platform.runLater(() -> javaStatus.setText(installedJava == null
                        ? "Java 25 not detected. V-Client will download it automatically when needed."
                        : "Detected Java 25: " + installedJava));
            } catch (IOException e) {
                Platform.runLater(() -> {
                    javaStatus.setText("Could not check installed Java 25: " + e.getMessage());
                    appendLog("Java 25 detection failed: " + e.getMessage());
                });
            }
        });

        VBox profileCard = card();
        Button exportProfile = button("EXPORT PROFILE", "#11263D", 11);
        exportProfile.setOnAction(event -> exportProfileFile());
        Button importProfile = button("IMPORT PROFILE", "#11263D", 11);
        importProfile.setOnAction(event -> importProfileFile());
        Label profileHint = label("Share your memory, Java, JVM, theme and clip settings between PCs. Accounts and sign-ins are never included.", 12, MUTED);
        profileHint.setWrapText(true);
        profileCard.getChildren().addAll(label("PROFILE", 11, MUTED), new HBox(10, exportProfile, importProfile), profileHint);

        VBox updateCard = card();
        HBox autoUpdateRow = Widgets.switchRow("Update V-Client automatically",
                "Checks for a new launcher at startup, verifies the download (SHA-256), then installs and reopens.",
                settings.autoUpdate(), ACCENT, enabled -> {
                    settings.setAutoUpdate(enabled);
                    saveSettings();
                });
        Button checkUpdates = button("CHECK FOR UPDATES NOW", "#11263D", 11);
        checkUpdates.setOnAction(event -> checkForUpdates(true));
        updateCard.getChildren().addAll(label("LAUNCHER UPDATES  ·  V-Client " + AppInfo.VERSION, 11, MUTED), autoUpdateRow, checkUpdates);

        VBox accountCard = buildAccountCard();

        HBox footer = new HBox(12);
        footer.setAlignment(Pos.CENTER_LEFT);
        Button backButton = button("←    BACK TO PLAY", ACCENT, 12);
        backButton.setPrefHeight(46);
        backButton.setOnAction(event -> showHome());
        status = label("Settings save automatically.", 12, MUTED);
        footer.getChildren().addAll(backButton, status);
        content.getChildren().addAll(title, subtitle, directoryCard, memoryCard, javaCard, profileCard, updateCard, buildVpnCard(), ThemeCard.build(featureHost()), accountCard);
        content.getChildren().add(footer);
        setPageContent(root, content);
        stage.setScene(new Scene(root, stage.getWidth(), stage.getHeight()));
    }

    /** Imports a WireGuard config and connects/disconnects a system-wide VPN (Minecraft traffic included). */
    private VBox buildVpnCard() {
        VBox card = card();
        Label title = label("VPN", 11, MUTED);
        Label state = label("Checking VPN...", 14, "#f3f6fc");
        Label hint = label("Built-in VPN, nothing to install and no administrator prompt. Press CONNECT and V-Client "
                + "tunnels your VSMP connection (" + VSMP_HOST + ", from the Servers page or JOIN OUR SMP) through a "
                + "free Cloudflare WARP VPN. It keeps your connection private but does not change your country, and "
                + "only that server is covered, not the rest of your PC. Have your own VPN? Use IMPORT CONFIG with a "
                + "WireGuard .conf instead.", 11, MUTED);
        hint.setWrapText(true);
        Button importConfig = button("IMPORT CONFIG", "#11263D", 11);
        Button toggle = button("CONNECT", ACCENT, 11);
        HBox row = new HBox(10, importConfig, toggle);
        row.setAlignment(Pos.CENTER_LEFT);
        AtomicBoolean busy = new AtomicBoolean();
        Runnable refresh = () -> executor.execute(() -> {
            boolean connected = VpnManager.isConnected();
            boolean configured = VpnManager.hasConfig();
            Platform.runLater(() -> {
                state.setText(connected ? "Connected" : configured ? "Disconnected" : "Off (free Cloudflare VPN, one click)");
                toggle.setText(connected ? "DISCONNECT" : "CONNECT");
                toggle.setDisable(false);
            });
        });
        importConfig.setOnAction(event -> {
            FileChooser chooser = new FileChooser();
            chooser.setTitle("Choose WireGuard config");
            chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("WireGuard config", "*.conf"));
            var selected = chooser.showOpenDialog(stage);
            if (selected == null) return;
            try {
                VpnManager.importConfig(selected.toPath());
                appendLog("VPN config imported.");
            } catch (IOException e) {
                showError("Could not import VPN config", e);
            }
            refresh.run();
        });
        toggle.setOnAction(event -> {
            if (!busy.compareAndSet(false, true)) return;
            toggle.setDisable(true);
            state.setText("Waiting for Windows...");
            executor.execute(() -> {
                try {
                    boolean wasConnected = VpnManager.isConnected();
                    if (wasConnected) VpnManager.disconnect();
                    else VpnManager.connect(List.of(InetSocketAddress.createUnresolved(VSMP_HOST, VSMP_PORT)),
                            line -> Platform.runLater(() -> appendLog(line)));
                    Platform.runLater(() -> appendLog(wasConnected ? "VPN disconnected." : "VPN connected."));
                } catch (IOException e) {
                    Platform.runLater(() -> {
                        appendLog("VPN error: " + e.getMessage());
                        showError("VPN", e);
                    });
                } finally {
                    busy.set(false);
                    refresh.run();
                }
            });
        });
        card.getChildren().addAll(title, state, row, hint);
        refresh.run();
        return card;
    }

    private void importLocalMinecraftFiles(Button importButton) {
        DirectoryChooser chooser = new DirectoryChooser();
        chooser.setTitle("Choose the Minecraft game folder to import from");
        Path initialDirectory = settings.minecraftDirectory().getParent();
        if (initialDirectory != null && Files.isDirectory(initialDirectory)) {
            chooser.setInitialDirectory(initialDirectory.toFile());
        }
        var selected = chooser.showDialog(stage);
        if (selected == null) return;
        Path source = LauncherSettings.normalizeMinecraftDirectory(selected.toPath());
        Path destination = settings.minecraftDirectory();
        importButton.setDisable(true);
        if (status != null) status.setText("Copying local Minecraft files into V-Client...");
        appendLog("Importing local Minecraft files from " + source + " into " + destination + ".");
        executor.execute(() -> {
            try {
                LocalMinecraftImporter.importGameFiles(source, destination, message ->
                        Platform.runLater(() -> {
                            if (status != null) status.setText(message);
                            appendLog(message);
                        }));
                List<MinecraftLauncher.InstalledVersion> versions = gameLauncher.findVersions(destination);
                Platform.runLater(() -> {
                    installedVersions = versions;
                    MinecraftLauncher.InstalledVersion preferred =
                            MinecraftLauncher.preferredInstalledVersion(versions);
                    if (preferred != null) selectedVersionId = preferred.id();
                    showHome();
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    if (status != null) status.setText("Import failed: " + e.getMessage());
                    appendLog("Minecraft import failed: " + e.getMessage());
                    showError("Could not import Minecraft files", e);
                });
            } finally {
                Platform.runLater(() -> importButton.setDisable(false));
            }
        });
    }

    private VBox pageContent(String eyebrowText, String titleText, String subtitleText) {
        VBox content = new VBox(18);
        content.setPadding(new Insets(30, 32, 30, 32));
        Label eyebrow = label(eyebrowText.toUpperCase(), 10, ACCENT);
        Label title = label(titleText, 30, "#f3f6fc");
        Label subtitle = label(subtitleText, 13, MUTED);
        subtitle.setWrapText(true);
        content.getChildren().add(new VBox(7, eyebrow, title, subtitle));
        return content;
    }

    private void showLibrary() {
        activePage = Page.LIBRARY;
        settingsPage = false;
        updateNavigationState();
        StackPane root = baseLayout();
        VBox content = pageContent("Your games", "Library", "Installed Minecraft profiles from your selected game folder.");
        HBox toolbar = new HBox(10);
        toolbar.setAlignment(Pos.CENTER_LEFT);
        Label directory = label(settings.minecraftDirectory().toString(), 11, MUTED);
        directory.setWrapText(true);
        HBox.setHgrow(directory, Priority.ALWAYS);
        Button refresh = button("REFRESH", "#11263D", 10);
        Label result = label("Scanning installed profiles...", 11, MUTED);
        toolbar.getChildren().addAll(directory, refresh);
        ListView<MinecraftLauncher.InstalledVersion> profiles = new ListView<>();
        profiles.setPlaceholder(label("No installed profiles found.", 13, MUTED));
        profiles.setStyle("-fx-control-inner-background: rgba(7, 19, 33, 0.82); -fx-background-color: transparent; -fx-border-color: rgba(124, 235, 255, 0.24);");
        profiles.setPrefHeight(290);
        profiles.setCellFactory(list -> new ListCell<>() {
            @Override
            protected void updateItem(MinecraftLauncher.InstalledVersion version, boolean empty) {
                super.updateItem(version, empty);
                if (empty || version == null) {
                    setText(null);
                    setGraphic(null);
                    return;
                }
                Label name = label(version.displayName(), 14, "#f3f6fc");
                Label details = label(version.type().toUpperCase() + "  ·  " + version.jsonFile(), 10, MUTED);
                details.setWrapText(true);
                VBox item = new VBox(5, name, details);
                item.setPadding(new Insets(8, 2, 8, 2));
                setText(null);
                setGraphic(item);
            }
        });
        profiles.getItems().setAll(installedVersions);
        Button useProfile = button("USE SELECTED PROFILE ON HOME", ACCENT, 11);
        useProfile.setOnAction(event -> {
            MinecraftLauncher.InstalledVersion chosen = profiles.getSelectionModel().getSelectedItem();
            if (chosen == null) {
                showError("Select a profile", new IOException("Choose an installed Minecraft profile first."));
                return;
            }
            selectedVersionId = chosen.id();
            showHome();
        });
        refresh.setOnAction(event -> loadLibraryProfiles(profiles, result));
        content.getChildren().addAll(toolbar, profiles, useProfile, result);
        setPageContent(root, content);
        stage.setScene(new Scene(root, stage.getWidth(), stage.getHeight()));
        loadLibraryProfiles(profiles, result);
    }

    private void loadLibraryProfiles(ListView<MinecraftLauncher.InstalledVersion> profiles, Label result) {
        result.setText("Scanning installed profiles...");
        executor.execute(() -> {
            try {
                List<MinecraftLauncher.InstalledVersion> found = gameLauncher.findVersions(settings.minecraftDirectory());
                Platform.runLater(() -> {
                    installedVersions = found;
                    profiles.getItems().setAll(found);
                    result.setText(found.size() + (found.size() == 1 ? " installed profile." : " installed profiles."));
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    result.setText("Could not scan profiles: " + e.getMessage());
                    showError("Library scan failed", e);
                });
            }
        });
    }

    /** Shows one of the feature pages built in their own classes. */
    private void showFeaturePage(Page page, String eyebrow, String title, String subtitle,
                                 java.util.function.Function<FeatureHost, javafx.scene.Node> builder) {
        activePage = page;
        settingsPage = false;
        updateNavigationState();
        StackPane root = baseLayout();
        VBox content = pageContent(eyebrow, title, subtitle);
        content.getChildren().add(builder.apply(featureHost()));
        setPageContent(root, content);
        stage.setScene(new Scene(root, stage.getWidth(), stage.getHeight()));
    }

    /**
     * Called once per game launch. Returns the benchmark to run in this launch, or null. A manual request wins;
     * otherwise the very first launch measures a "before" so a profile can be recommended. Players who already have
     * Boost on skip the automatic test (it could not be a "before").
     */
    private BenchmarkStore.Request nextBenchmarkRequest() {
        String label = settings.benchmarkPending();
        if (label.isEmpty() && settings.autoBenchmark() && !settings.autoBenchmarkDone()) {
            settings.setAutoBenchmarkDone(true);
            if (!settings.boostEnabled()) label = "before";
        }
        if (label.isEmpty()) return null;
        settings.setBenchmarkPending("");
        settings.setAutoBenchmarkDone(true);
        saveSettings();
        return new BenchmarkStore.Request(BenchmarkStore.DEFAULT_SECONDS, label, settings.boostProfile().name());
    }

    /**
     * Moves a finished benchmark into the history. After a first-launch "before" it also selects the recommended
     * profile (it is not switched on: that changes video settings and installs mods, which stays the player's choice).
     */
    private void collectBenchmark() {
        BenchmarkStore.ingest(settings.minecraftDirectory()).ifPresent(result -> {
            appendLog("FPS benchmark (" + result.label() + "): " + BenchmarkStore.summary(result));
            if ("before".equals(result.label()) && !settings.boostEnabled()) {
                BoostAdvisor.Recommendation recommendation = BoostAdvisor.recommend(result, PcAnalysis.cachedOrBasic());
                settings.setBoostProfile(recommendation.profile());
                saveSettings();
                appendLog("FrostBoost recommends " + recommendation.profile().label() + ". " + recommendation.reason());
            }
        });
    }

    private FeatureHost featureHost() {
        if (featureHost == null) {
            featureHost = new FeatureHost() {
                @Override public LauncherSettings settings() { return settings; }
                @Override public PlayerAccount account() { return account; }
                @Override public PlayerStats stats() { return stats; }
                @Override public RecordingLibrary recordings() { return recordingLibrary; }
                @Override public ReplayBuffer replayBuffer() { return replayBuffer; }
                @Override public ExecutorService executor() { return executor; }
                @Override public String replayStatus() { return replayStatus; }
                @Override public Stage stage() { return stage; }
                @Override public void log(String line) { appendLogLater(line); }
                @Override public void saveSettings() { LauncherApp.this.saveSettings(); }
                @Override public void saveStats() { stats.save(); }
                @Override public void showSettings() { LauncherApp.this.showSettings(); }
                @Override public void openBoost() { navigate(Page.BOOST); }
                @Override public void showFpsComparison() { navigate(Page.FPS_TEST); }
                @Override public boolean shown(javafx.scene.Node page) {
                    return page.getScene() != null && page.getScene() == stage.getScene();
                }
                @Override public String selectedVersionId() { return selectedVersionId; }
                @Override public void themeChanged() { navigate(activePage); }
                @Override public ActivityLog activity() { return activityLog; }
                @Override public BackendClient backend() { return LauncherApp.this.backend(); }
                @Override public void openFriends() { navigate(Page.FRIENDS); }
                @Override public ModrinthModService modrinth() { return modrinthModService; }
                @Override public ModrinthModService.Target fabricTarget() throws IOException {
                    Path directory = settings.minecraftDirectory();
                    MinecraftLauncher.InstalledVersion fabric = gameLauncher.findVersions(directory).stream()
                            .filter(version -> "Fabric".equals(version.loader()))
                            .sorted(java.util.Comparator.comparing((MinecraftLauncher.InstalledVersion version) ->
                                    !version.id().equals(selectedVersionId)))
                            .findFirst().orElse(null);
                    if (fabric == null) {
                        throw new IOException("No Fabric profile is installed. Install the V-Client Fabric profile on the Home page first.");
                    }
                    return ModrinthModService.resolveTarget(directory, fabric);
                }
                @Override public PlayerAccount refreshedAccount() throws Exception {
                    PlayerAccount current = account;
                    if (current == null) throw new IOException("No account is selected.");
                    PlayerAccount fresh = refreshAccount(current);
                    if (!fresh.equals(current)) Platform.runLater(() -> updateRefreshedAccount(current.id(), fresh));
                    return fresh;
                }
                @Override public Image downloadImage(String address) { return LauncherApp.this.downloadImage(address); }
                @Override public int ownedCosmeticsCount() {
                    PlayerAccount current = account;
                    if (current == null || current.uuid() == null || settings.offlineMode()) return -1;
                    try {
                        return backend().ownedCosmetics(current.uuid()).size();
                    } catch (IOException | InterruptedException e) {
                        return -1;
                    }
                }
            };
        }
        return featureHost;
    }

    private void showBoost() {
        activePage = Page.BOOST;
        settingsPage = false;
        updateNavigationState();
        StackPane root = baseLayout();
        VBox content = pageContent("Performance", "❄ FrostBoost",
                "One switch for more FPS and fewer lag spikes: tuned video settings, optimisation mods, the right amount of memory and smoother garbage collection.");
        BoostPage page = new BoostPage(content);
        content.getChildren().addAll(page.masterCard(), page.status, page.profilesCard(), page.detailsCard(), page.manualMemoryCard());
        setPageContent(root, content);
        stage.setScene(new Scene(root, stage.getWidth(), stage.getHeight()));
        page.refresh();
    }

    /** The Boost page: master switch, four profile cards, what the selected profile changes, manual memory. */
    private final class BoostPage {
        private final VBox content;
        private final VBox status = new VBox(10);
        private final HBox estimateRow = new HBox(12);
        private final VBox detailsBody = new VBox(16);
        private final javafx.scene.layout.FlowPane profileFlow = new javafx.scene.layout.FlowPane(12, 12);
        private final List<VBox> profileCards = new ArrayList<>();
        private final Label masterState = ModsUi.text("", 13, ModsUi.MUTED, false);
        private final Label hardware = ModsUi.text("", 11, "#6f9bb5", false);
        private javafx.scene.layout.StackPane masterSwitch;
        private boolean working;

        BoostPage(VBox content) {
            this.content = content;
            status.setManaged(false);
            status.setVisible(false);
            profileFlow.setMaxWidth(Double.MAX_VALUE);
            profileFlow.widthProperty().addListener((observable, oldWidth, newWidth) -> layoutProfiles());
        }

        VBox masterCard() {
            VBox card = ModsUi.glassCard(14, new Insets(20));
            Label title = ModsUi.text("❄ FROSTBOOST", 16, ModsUi.TEXT, true);
            masterSwitch = ModsUi.switchPill(settings.boostEnabled(), this::onToggle);
            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);
            HBox top = new HBox(14, title, spacer, masterState, masterSwitch);
            top.setAlignment(Pos.CENTER_LEFT);
            estimateRow.setAlignment(Pos.CENTER_LEFT);
            hardware.setWrapText(true);
            card.getChildren().addAll(top, estimateRow, hardware);
            return card;
        }

        VBox profilesCard() {
            VBox card = ModsUi.glassCard(14, new Insets(20));
            card.getChildren().addAll(ModsUi.sectionTitle("Choose a profile"), profileFlow);
            for (BoostProfile profile : BoostProfile.values()) {
                VBox profileCard = profileCard(profile);
                profileCards.add(profileCard);
                profileFlow.getChildren().add(profileCard);
            }
            return card;
        }

        VBox detailsCard() {
            VBox card = ModsUi.glassCard(14, new Insets(20));
            Button apply = new Button("APPLY AND INSTALL MODS");
            apply.setMinHeight(42);
            apply.setStyle("-fx-background-color: " + ACCENT + "; -fx-text-fill: #071321; -fx-font-size: 12px; -fx-font-weight: bold;"
                    + " -fx-background-radius: 12; -fx-padding: 0 22 0 22; -fx-cursor: hand;");
            apply.setOnAction(event -> apply());
            Button restore = new Button("RESTORE MY SETTINGS");
            restore.setMinHeight(42);
            restore.setStyle("-fx-background-color: rgba(255,255,255,0.08); -fx-text-fill: #f5f7fd; -fx-font-size: 12px;"
                    + " -fx-font-weight: bold; -fx-background-radius: 12; -fx-padding: 0 22 0 22; -fx-cursor: hand;");
            restore.setOnAction(event -> disable());
            Button compare = new Button("OPEN FPS COMPARISON");
            compare.setMinHeight(42);
            compare.setStyle(restore.getStyle());
            compare.setOnAction(event -> navigate(Page.FPS_TEST));
            HBox buttons = new HBox(10, apply, restore, compare);
            buttons.setAlignment(Pos.CENTER_LEFT);
            card.getChildren().addAll(ModsUi.sectionTitle("What this profile changes"), detailsBody, buttons,
                    ModsUi.text("Your own video settings are saved first and come back with RESTORE MY SETTINGS or when you switch FrostBoost off. "
                            + "While FrostBoost is on, the profile's video settings are applied at every launch.", 11, ModsUi.MUTED, false));
            ((Label) card.getChildren().get(card.getChildren().size() - 1)).setWrapText(true);
            return card;
        }

        VBox manualMemoryCard() {
            VBox card = ModsUi.glassCard(14, new Insets(20));
            HBox heading = new HBox();
            heading.setAlignment(Pos.CENTER_LEFT);
            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);
            Label value = ModsUi.text(settings.memoryGb() + " GB", 18, ModsUi.TEXT, true);
            heading.getChildren().addAll(ModsUi.sectionTitle("Manual game memory (used when FrostBoost is off)"), spacer, value);
            Slider memory = new Slider(1, LauncherSettings.maxMemory(), settings.memoryGb());
            memory.setMajorTickUnit(1);
            memory.setMinorTickCount(0);
            memory.setSnapToTicks(true);
            memory.setShowTickMarks(true);
            memory.setStyle("-fx-control-inner-background: " + ACCENT + "; -fx-accent: " + ACCENT + ";");
            long ramGb = BoostProfile.physicalRamBytes() / (1024L * 1024 * 1024);
            Label warning = ModsUi.text("", 11, ModsUi.WARNING, false);
            warning.setWrapText(true);
            Runnable checkRam = () -> warning.setText(settings.memoryGb() > ramGb * 3 / 4
                    ? "This PC has about " + ramGb + " GB of RAM. Giving the game this much can slow Windows and the game down; "
                    + "leave at least a quarter for the system." : "");
            memory.valueProperty().addListener((observable, oldValue, newValue) -> {
                settings.setMemoryGb(newValue.intValue());
                value.setText(newValue.intValue() + " GB");
                checkRam.run();
                saveSettings();
            });
            HBox presets = new HBox(8);
            for (int preset : List.of(2, 4, 6, 8, 12, 16, 24, 32)) {
                if (preset > LauncherSettings.maxMemory()) continue;
                Button choice = new Button(preset + " GB");
                choice.setMinHeight(32);
                choice.setStyle("-fx-background-color: rgba(255,255,255,0.08); -fx-text-fill: #f5f7fd; -fx-font-size: 11px;"
                        + " -fx-font-weight: bold; -fx-background-radius: 10; -fx-padding: 0 14 0 14; -fx-cursor: hand;");
                choice.setOnAction(event -> memory.setValue(preset));
                presets.getChildren().add(choice);
            }
            checkRam.run();
            card.getChildren().addAll(heading, memory, presets, warning);
            return card;
        }

        private VBox profileCard(BoostProfile profile) {
            Label name = ModsUi.text(profile.label(), 15, ModsUi.TEXT, true);
            Label tagline = ModsUi.text(profile.tagline(), 11, ModsUi.MUTED, false);
            tagline.setWrapText(true);
            tagline.setMinHeight(32);
            Label gain = ModsUi.chip("≈ " + profile.estimatedFpsGain() + " FPS", ModsUi.GOOD);
            var options = profile.options();
            Label facts = ModsUi.text("Render distance " + options.get("renderDistance") + "  ·  Simulation "
                    + options.get("simulationDistance") + "\n" + profile.mods().size() + " optimisation mods", 11, "#7fb0cc", false);
            facts.setWrapText(true);
            VBox card = new VBox(8, name, tagline, gain, facts);
            card.setPadding(new Insets(16));
            card.setUserData(profile);
            card.setCursor(javafx.scene.Cursor.HAND);
            card.setOnMouseClicked(event -> select(profile));
            return card;
        }

        private void styleProfileCards() {
            for (VBox card : profileCards) {
                boolean selected = card.getUserData() == settings.boostProfile();
                String base = "-fx-background-radius: 14; -fx-border-radius: 14; -fx-border-width: " + (selected ? "2" : "1") + ";"
                        + " -fx-background-color: " + (selected ? Theme.accentRgba(0.13) : "rgba(255,255,255,0.05)") + ";"
                        + " -fx-border-color: " + (selected ? Theme.accentRgba(0.85) : "rgba(255,255,255,0.10)") + ";";
                card.setStyle(base);
                ModsUi.hoverLift(card, base);
            }
        }

        private void layoutProfiles() {
            double available = profileFlow.getWidth();
            if (available <= 0) return;
            int columns = available >= 900 ? 4 : available >= 520 ? 2 : 1;
            double width = Math.floor((available - 12 * (columns - 1)) / columns) - 1;
            profileFlow.setPrefWrapLength(available);
            for (VBox card : profileCards) {
                card.setPrefWidth(width);
                card.setMinWidth(Math.min(width, 180));
                card.setMaxWidth(width);
            }
        }

        // ---- state -----------------------------------------------------------------------------------

        void refresh() {
            long ram = BoostProfile.physicalRamBytes();
            BoostProfile profile = settings.boostProfile();
            boolean enabled = settings.boostEnabled();
            masterState.setText(enabled ? profile.label() + " is on" : "Off");
            masterState.setStyle(masterState.getStyle() + " -fx-text-fill: " + (enabled ? ModsUi.GOOD : ModsUi.MUTED) + ";");
            ModsUi.setSwitch(masterSwitch, enabled);
            estimateRow.getChildren().setAll(
                    ModsUi.text("Estimated FPS gain", 12, ModsUi.MUTED, false),
                    ModsUi.chip("≈ " + profile.estimatedFpsGain(), ModsUi.GOOD),
                    ModsUi.text("typical range, not a measurement - it depends on your PC, world and server", 11, "#6f9bb5", false));
            hardware.setText("This PC has about " + (ram / (1024L * 1024 * 1024)) + " GB of RAM, so " + profile.label()
                    + " gives the game " + profile.recommendedMemoryGb(ram) + " GB. Java is chosen automatically: V-Client uses the Azul Zulu version your Minecraft version needs and downloads it when missing.");
            styleProfileCards();
            layoutProfiles();
            showDetails(profile, ram);
        }

        private void showDetails(BoostProfile profile, long ram) {
            Path modsDirectory = settings.minecraftDirectory().resolve("mods");
            VBox video = new VBox(4);
            video.getChildren().add(ModsUi.text("Video settings", 12, ModsUi.TEXT, true));
            profile.options(PcAnalysis.tier(PcAnalysis.cachedOrBasic())).forEach((key, value) -> video.getChildren().add(
                    ModsUi.text(prettyOption(key) + "  →  " + value.replace("\"", ""), 11, ModsUi.MUTED, false)));
            VBox java = new VBox(4);
            int memory = profile.recommendedMemoryGb(ram);
            java.getChildren().addAll(ModsUi.text("Memory and JVM", 12, ModsUi.TEXT, true),
                    ModsUi.text("Heap  -Xmx" + memory + "G  -Xms" + profile.initialHeap(memory), 11, ModsUi.MUTED, false),
                    ModsUi.text(profile.jvmFlags().size() + " garbage-collector flags for short, even pauses", 11, ModsUi.MUTED, false),
                    ModsUi.text(String.join("  ", profile.jvmFlags()), 10, "#5f8aa6", false));
            ((Label) java.getChildren().get(3)).setWrapText(true);
            VBox mods = new VBox(4);
            mods.getChildren().add(ModsUi.text("Optimisation mods (Fabric, from Modrinth)", 12, ModsUi.TEXT, true));
            for (BoostProfile.BoostMod mod : profile.mods()) {
                boolean present = modInstalled(modsDirectory, mod.slug());
                mods.getChildren().add(ModsUi.text((present ? "✓ " : "○ ") + mod.name() + "  —  " + mod.effect(), 11,
                        present ? ModsUi.GOOD : ModsUi.MUTED, false));
            }
            javafx.scene.layout.FlowPane columns = new javafx.scene.layout.FlowPane(28, 16, video, java, mods);
            detailsBody.getChildren().setAll(columns);
            columns.setPrefWrapLength(600);
        }

        private String prettyOption(String key) {
            return switch (key) {
                case "enableVsync" -> "VSync";
                case "maxFps" -> "Max FPS";
                case "graphicsPreset" -> "Graphics";
                case "ao" -> "Smooth lighting";
                case "entityShadows" -> "Entity shadows";
                case "renderClouds" -> "Clouds";
                case "particles" -> "Particles (0 all, 1 fewer, 2 minimal)";
                case "mipmapLevels" -> "Mipmap levels";
                case "renderDistance" -> "Render distance";
                case "simulationDistance" -> "Simulation distance";
                case "biomeBlendRadius" -> "Biome blend";
                case "entityDistanceScaling" -> "Entity distance";
                default -> key;
            };
        }

        private boolean modInstalled(Path modsDirectory, String slug) {
            String token = slug.replace("-", "");
            try (var files = Files.isDirectory(modsDirectory) ? Files.list(modsDirectory) : java.util.stream.Stream.<Path>empty()) {
                return files.anyMatch(file -> {
                    String name = file.getFileName().toString().toLowerCase(java.util.Locale.ROOT).replace("-", "").replace("_", "");
                    return name.contains(token) && name.endsWith(".jar");
                });
            } catch (IOException e) {
                return false;
            }
        }

        private void select(BoostProfile profile) {
            if (working) return;
            settings.setBoostProfile(profile);
            saveSettings();
            refresh();
            if (settings.boostEnabled()) apply();
        }

        private void onToggle(boolean on) {
            if (working) {
                refresh();
                return;
            }
            if (on) apply();
            else disable();
        }

        private void showStatus(javafx.scene.Node... nodes) {
            status.getChildren().setAll(nodes);
            status.setManaged(true);
            status.setVisible(true);
        }

        private HBox success(String message) {
            Label icon = ModsUi.text("✓", 16, "#08140e", true);
            icon.setMinSize(30, 30);
            icon.setAlignment(Pos.CENTER);
            icon.setStyle(icon.getStyle() + " -fx-background-color: " + ModsUi.GOOD + "; -fx-background-radius: 15;");
            Label text = ModsUi.text(message, 13, "#bff5d6", true);
            text.setWrapText(true);
            HBox box = new HBox(12, icon, text);
            box.setAlignment(Pos.CENTER_LEFT);
            box.setPadding(new Insets(12, 16, 12, 14));
            box.setStyle("-fx-background-color: rgba(57,217,138,0.10); -fx-background-radius: 14;"
                    + " -fx-border-color: rgba(57,217,138,0.40); -fx-border-radius: 14;");
            return box;
        }

        // ---- apply / restore ---------------------------------------------------------------------------

        void apply() {
            if (working) return;
            working = true;
            BoostProfile profile = settings.boostProfile();
            settings.setBoostEnabled(true);
            saveSettings();
            if (stats.unlock(PlayerStats.FPS_BOOST)) stats.save();
            refresh();
            showStatus(ModsUi.busyLabel("Applying " + profile.label() + "..."));
            Path minecraftDirectory = settings.minecraftDirectory();
            boolean offline = settings.offlineMode();
            executor.execute(() -> {
                List<javafx.scene.Node> notes = new ArrayList<>();
                int installed = 0;
                int already = 0;
                int unavailable = 0;
                String modProblem = null;
                int changed = 0;
                try {
                    changed = BoostOptions.apply(minecraftDirectory, profile.options(PcAnalysis.tier(PcAnalysis.cached())),
                            line -> Platform.runLater(() -> appendLog(line)));
                } catch (IOException e) {
                    modProblem = null;
                    String message = e.getMessage();
                    notes.add(ModsUi.warningBox("Couldn't write the video settings", message, null));
                    Platform.runLater(() -> appendLog("Boost: could not write options.txt: " + message));
                }
                Path modsDirectory = minecraftDirectory.resolve("mods");
                try {
                    if (offline) throw new IOException("Offline mode is on, so Modrinth is not contacted. Turn it off on the Home page to install the optimisation mods.");
                    MinecraftLauncher.InstalledVersion fabric = gameLauncher.findVersions(minecraftDirectory).stream()
                            .filter(version -> "Fabric".equals(version.loader()))
                            .sorted(java.util.Comparator.comparing((MinecraftLauncher.InstalledVersion version) ->
                                    !version.id().equals(selectedVersionId)))
                            .findFirst().orElse(null);
                    if (fabric == null) {
                        throw new IOException("No Fabric profile is installed, so the optimisation mods were skipped. Install the V-Client Fabric profile on the Home page first.");
                    }
                    ModrinthModService.Target target = ModrinthModService.resolveTarget(minecraftDirectory, fabric);
                    for (BoostProfile.BoostMod mod : profile.mods()) {
                        if (modInstalled(modsDirectory, mod.slug())) {
                            already++;
                            continue;
                        }
                        ModrinthModService.ModProject project = modrinthModService.findBySlug(mod.slug(), mod.name(), target,
                                line -> Platform.runLater(() -> appendLog(line)));
                        if (project == null) {
                            unavailable++;
                            Platform.runLater(() -> appendLog("Boost: " + mod.name() + " has no release for "
                                    + target.loader() + " " + target.gameVersion() + " yet; skipped."));
                            continue;
                        }
                        modrinthModService.install(project, minecraftDirectory, line -> Platform.runLater(() -> appendLog(line)));
                        installed++;
                    }
                } catch (IOException | InterruptedException e) {
                    if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                    modProblem = e.getMessage();
                    Platform.runLater(() -> appendLog("Boost: optimisation mods could not be installed: " + e.getMessage()));
                }
                int changedSettings = changed;
                int installedMods = installed;
                int alreadyMods = already;
                int unavailableMods = unavailable;
                String problem = modProblem;
                Platform.runLater(() -> {
                    working = false;
                    refresh();
                    List<javafx.scene.Node> all = new ArrayList<>();
                    all.add(success(profile.label() + " applied: " + changedSettings + " video settings changed, "
                            + installedMods + " mods installed, " + alreadyMods + " already installed"
                            + (unavailableMods > 0 ? ", " + unavailableMods + " not available for this version yet" : "") + "."));
                    if (problem != null) {
                        String[] message = ModsUi.describeFailure("Installing the optimisation mods", problem);
                        all.add(ModsUi.warningBox(message[0], message[1], null));
                    }
                    all.addAll(notes);
                    showStatus(all.toArray(new javafx.scene.Node[0]));
                    appendLog("Boost: " + profile.label() + " applied.");
                    if (BenchmarkStore.awaitingAfter(BenchmarkStore.load(minecraftDirectory)) && settings.benchmarkPending().isEmpty()) {
                        settings.setBenchmarkPending("after");
                        saveSettings();
                        appendLog("FrostBoost: the next launch will measure the \"after\" FPS for the comparison.");
                    }
                });
            });
        }

        void disable() {
            if (working) return;
            settings.setBoostEnabled(false);
            saveSettings();
            Path minecraftDirectory = settings.minecraftDirectory();
            try {
                int restored = BoostOptions.restore(minecraftDirectory, line -> appendLog(line));
                refresh();
                showStatus(success(restored > 0 ? "FrostBoost is off and your own video settings are back (" + restored + " restored)."
                        : "FrostBoost is off."));
            } catch (IOException e) {
                refresh();
                showStatus(ModsUi.warningBox("Couldn't restore your settings", e.getMessage(), null));
            }
        }
    }

    private void showWardrobe() {
        activePage = Page.WARDROBE;
        settingsPage = false;
        updateNavigationState();
        StackPane root = baseLayout();
        VBox content = pageContent("Player profile", "Wardrobe", "Preview the skin and cape saved with your selected account.");
        HBox preview = new HBox(22);
        preview.setAlignment(Pos.CENTER_LEFT);
        preview.setPadding(new Insets(22));
        preview.setStyle("-fx-background-color: rgba(17, 38, 61, 0.84); -fx-background-radius: 12; -fx-border-color: rgba(124, 235, 255, 0.24); -fx-border-radius: 12;");
        ImageView skin = new ImageView();
        skin.setFitWidth(192);
        skin.setFitHeight(192);
        skin.setPreserveRatio(true);
        ImageView cape = new ImageView();
        cape.setFitWidth(112);
        cape.setFitHeight(192);
        cape.setPreserveRatio(true);
        Label description = label("", 13, MUTED);
        description.setWrapText(true);
        VBox info = new VBox(12, label(account == null ? "No account selected" : account.name(), 20, "#f3f6fc"),
                description);
        preview.getChildren().addAll(skin, cape, info);
        Button reload = button("RELOAD SAVED PREVIEW", "#11263D", 10);
        reload.setOnAction(event -> loadPreviews(account, skin, cape, description, () -> account));
        Button accountSettings = button("MANAGE ACCOUNTS", ACCENT, 10);
        accountSettings.setOnAction(event -> showSettings());
        content.getChildren().addAll(preview, reload, accountSettings,
                label("Wardrobe displays the saved skin/cape image. Uploading or changing Ely.by skins must be done through Ely.by.", 11, MUTED),
                SkinStudio.build(featureHost()));
        setPageContent(root, content);
        stage.setScene(new Scene(root, stage.getWidth(), stage.getHeight()));
        loadPreviews(account, skin, cape, description, () -> account);
    }

    private void showCosmetics() {
        activePage = Page.COSMETICS;
        settingsPage = false;
        updateNavigationState();
        StackPane root = baseLayout();
        VBox content = pageContent("Your look", "Cosmetics",
                "Capes, wings, hats, emotes, animated pieces and trails. What you equip here is what you wear in game. "
                        + "Open the in-game menu with K for a live 3D preview. Cosmetics are visual only.");
        Path configFile = CosmeticsStore.configFile(settings.minecraftDirectory());
        boolean adminUnlock = account != null && settings.isAdmin(account);
        BackendClient client = backend();
        Label status = label("Loading cosmetics...", 12, MUTED);
        status.setWrapText(true);
        java.util.function.BiConsumer<String, Boolean> setStatus = (message, failed) -> {
            status.setText(message);
            status.setTextFill(Color.web(failed ? "#ff9aa5" : MUTED));
        };
        VBox diagnostics = new VBox(4);
        diagnostics.setVisible(false);
        diagnostics.setManaged(false);
        VBox list = new VBox(8);
        HBox tabs = new HBox(6);
        HBox tiers = new HBox(6);
        List<CosmeticsStore.Item> items = new ArrayList<>();
        java.util.Set<String> owned = new java.util.HashSet<>();
        String[] selectedCategory = {"cape"};
        String[] selectedTier = {""};
        Runnable[] render = new Runnable[1];

        render[0] = () -> {
            long now = System.currentTimeMillis() / 1000;
            Map<String, String> equipped = CosmeticsStore.equipped(configFile);
            tabs.getChildren().clear();
            for (String category : CosmeticsStore.CATEGORIES) {
                Button tab = button(categoryLabel(category), category.equals(selectedCategory[0]) ? ACCENT : "#11263D", 10);
                tab.setOnAction(event -> {
                    selectedCategory[0] = category;
                    render[0].run();
                });
                tabs.getChildren().add(tab);
            }
            tiers.getChildren().clear();
            for (String tier : List.of("", "free", "premium", "event")) {
                Button chip = button(tier.isEmpty() ? "All" : Character.toUpperCase(tier.charAt(0)) + tier.substring(1),
                        tier.equals(selectedTier[0]) ? ACCENT : "#11263D", 10);
                chip.setOnAction(event -> {
                    selectedTier[0] = tier;
                    render[0].run();
                });
                tiers.getChildren().add(chip);
            }
            list.getChildren().clear();
            int shown = 0;
            for (CosmeticsStore.Item item : items) {
                if (!item.category().equals(selectedCategory[0])
                        || (!selectedTier[0].isEmpty() && !item.tier().equals(selectedTier[0]))) continue;
                shown++;
                boolean unlocked = adminUnlock || CosmeticsStore.unlocked(item, owned, now);
                boolean isEquipped = item.id().equals(equipped.get(item.slot()));
                Label name = label(item.name(), 14, unlocked ? "#f3f6fc" : "#8e8eb2");
                String tierColor = switch (item.tier()) {
                    case "free" -> "#7cf29a";
                    case "event" -> "#B8F4FF";
                    default -> ACCENT;
                };
                Label tag = label(item.tier().toUpperCase() + "  ·  " + item.slot().charAt(0)
                        + item.slot().substring(1).toLowerCase(), 10, tierColor);
                Label description = label(item.description(), 11, MUTED);
                description.setWrapText(true);
                VBox text = new VBox(3, name, tag, description);
                HBox.setHgrow(text, Priority.ALWAYS);
                Button action = button(isEquipped ? "UNEQUIP" : unlocked ? "EQUIP"
                        : item.tier().equals("premium") ? "PREMIUM" : "LOCKED",
                        isEquipped ? "#482332" : unlocked ? ACCENT : "#2a2a3a", 10);
                action.setMinWidth(92);
                action.setDisable(!unlocked && !isEquipped);
                action.setOnAction(event -> {
                    try {
                        if (isEquipped) CosmeticsStore.unequip(configFile, item.slot());
                        else CosmeticsStore.equip(configFile, item.slot(), item.id());
                        status.setText((isEquipped ? "Unequipped " : "Equipped ") + item.name()
                                + ". It shows the next time you start the game.");
                        appendLog("Cosmetics: " + (isEquipped ? "unequipped " : "equipped ") + item.id() + ".");
                    } catch (IOException e) {
                        status.setText("Could not save cosmetics: " + e.getMessage());
                    }
                    render[0].run();
                });
                HBox row = new HBox(14, text, action);
                row.setAlignment(Pos.CENTER_LEFT);
                row.setPadding(new Insets(12, 14, 12, 14));
                row.setStyle("-fx-background-color: rgba(17, 38, 61, 0.84); -fx-background-radius: 10; -fx-border-radius: 10;"
                        + " -fx-border-color: " + (isEquipped ? Theme.accentRgba(0.7) : "rgba(124, 235, 255, 0.24)") + ";");
                list.getChildren().add(row);
            }
            if (shown == 0) list.getChildren().add(label("Nothing here yet.", 12, MUTED));
        };

        Button refresh = button("REFRESH", "#11263D", 10);
        Button clear = button("UNEQUIP ALL", "#482332", 10);
        clear.setOnAction(event -> {
            try {
                for (String slot : List.of("CAPE", "WINGS", "HAT", "TRAIL", "EMOTE")) {
                    CosmeticsStore.unequip(configFile, slot);
                }
                status.setText("Everything unequipped.");
            } catch (IOException e) {
                status.setText("Could not save cosmetics: " + e.getMessage());
            }
            render[0].run();
        });
        Runnable load = () -> {
            setStatus.accept("Loading cosmetics...", false);
            refresh.setDisable(true);
            String uuid = account == null ? "" : account.uuid();
            boolean online = client.configured() && !settings.offlineMode();
            boolean checkOwned = account != null && !uuid.isBlank();
            appendLog("Cosmetics: loading the catalog (backend " + (client.configured() ? client.baseUrl() : "not set")
                    + ", " + (online ? "online" : "not contacting it") + ", account "
                    + (account == null ? "none" : account.name() + " / " + account.type().label()) + ").");
            // Every outcome ends in a result: success, or a failure with the real reason. A 10 second limit
            // (plus a little for the request itself) guarantees the page can never wait forever.
            CompletableFuture.supplyAsync(() -> {
                try {
                    com.fasterxml.jackson.databind.JsonNode remote = null;
                    java.util.Set<String> ownedNow = new java.util.HashSet<>();
                    if (online) {
                        remote = client.cosmeticsCatalog();
                        if (checkOwned) {
                            try {
                                ownedNow.addAll(client.ownedCosmetics(uuid));
                            } catch (IOException e) {
                                appendLogLater("Cosmetics: owned items could not be loaded (" + e.getMessage()
                                        + "); continuing without them.");
                            }
                        }
                    }
                    return new Object[]{CosmeticsStore.merge(CosmeticsStore.builtIn(), remote), ownedNow};
                } catch (IOException | InterruptedException e) {
                    if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                    throw new java.util.concurrent.CompletionException(e);
                }
            }, executor).orTimeout(CosmeticsDiagnostics.TIMEOUT_SECONDS + 2, TimeUnit.SECONDS)
                    .whenComplete((result, failure) -> Platform.runLater(() -> {
                refresh.setDisable(false);
                List<CosmeticsStore.Item> loaded;
                if (failure == null) {
                    @SuppressWarnings("unchecked")
                    List<CosmeticsStore.Item> merged = (List<CosmeticsStore.Item>) ((Object[]) result)[0];
                    @SuppressWarnings("unchecked")
                    java.util.Set<String> ownedNow = (java.util.Set<String>) ((Object[]) result)[1];
                    loaded = merged;
                    owned.clear();
                    owned.addAll(ownedNow);
                    setStatus.accept((online ? "Online catalog loaded. " : "Showing the built-in cosmetics"
                            + (client.configured() ? " (offline mode). " : " (set the backend address on the News page for more). "))
                            + loaded.size() + " items.", false);
                } else {
                    Throwable cause = failure instanceof java.util.concurrent.CompletionException && failure.getCause() != null
                            ? failure.getCause() : failure;
                    String reason = cause instanceof java.util.concurrent.TimeoutException
                            ? "timed out after " + CosmeticsDiagnostics.TIMEOUT_SECONDS + " seconds"
                            : CosmeticsDiagnostics.describe(cause);
                    appendLog("Cosmetics: could not load the online catalog: " + reason
                            + (settings.debugMode() ? "\n" + BackendClient.stackTrace(cause) : ""));
                    loaded = CosmeticsStore.merge(CosmeticsStore.builtIn(), null);
                    setStatus.accept("Could not load the online catalog: " + reason + ". Showing the built-in "
                            + loaded.size() + " cosmetics. Press REFRESH to retry or DIAGNOSE to find the problem.", true);
                }
                items.clear();
                items.addAll(loaded);
                render[0].run();
            }));
        };
        refresh.setOnAction(event -> load.run());

        Button diagnose = button("DIAGNOSE", "#11263D", 10);
        diagnose.setOnAction(event -> {
            diagnose.setDisable(true);
            diagnostics.getChildren().setAll(label("Checking... (each check gives up after "
                    + CosmeticsDiagnostics.TIMEOUT_SECONDS + " seconds)", 11, ACCENT));
            diagnostics.setVisible(true);
            diagnostics.setManaged(true);
            CosmeticsDiagnostics.Context context = new CosmeticsDiagnostics.Context(
                    BackendClient.resolveUrl(settings.backendUrl()), account, settings.backendToken(), settings.offlineMode());
            appendLog("Diagnostics: started.");
            executor.execute(() -> {
                CosmeticsDiagnostics.run(context, check -> Platform.runLater(() -> {
                    String color = switch (check.result()) {
                        case OK -> "#7cf29a";
                        case FAIL -> "#ff9aa5";
                        case INFO -> MUTED;
                    };
                    Label line = label((check.result() == CosmeticsDiagnostics.Result.OK ? "OK    "
                            : check.result() == CosmeticsDiagnostics.Result.FAIL ? "FAIL  " : "info  ")
                            + check.name() + " - " + check.detail(), 11, color);
                    line.setWrapText(true);
                    diagnostics.getChildren().add(line);
                    appendLog("Diagnostics: " + check.result() + " " + check.name() + " - " + check.detail());
                }));
                Platform.runLater(() -> {
                    diagnose.setDisable(false);
                    appendLog("Diagnostics: finished.");
                });
            });
        });
        javafx.scene.control.CheckBox debugBox = new javafx.scene.control.CheckBox(
                "Debug mode (log every request, URL, status and stack traces)");
        debugBox.setSelected(settings.debugMode());
        debugBox.setTextFill(Color.web(MUTED));
        debugBox.setOnAction(event -> {
            settings.setDebugMode(debugBox.isSelected());
            BackendClient.setRequestLog(line -> Platform.runLater(() -> appendLog(line)), settings.debugMode());
            saveSettings();
            appendLog("Debug mode " + (settings.debugMode() ? "on" : "off") + ".");
        });
        VBox controls = card();
        controls.getChildren().addAll(tabs, tiers, new HBox(10, refresh, clear, diagnose), status, debugBox, diagnostics);
        content.getChildren().addAll(controls, list,
                label((adminUnlock ? "Admin account: every cosmetic is unlocked for you. " : "")
                        + "The cosmetics file is shared with the game: " + configFile, 10, MUTED));
        setPageContent(root, content);
        stage.setScene(new Scene(root, stage.getWidth(), stage.getHeight()));
        render[0].run();
        load.run();
    }

    private static String categoryLabel(String category) {
        return switch (category) {
            case "cape" -> "Capes";
            case "wings" -> "Wings";
            case "hat" -> "Hats";
            case "emote" -> "Emotes";
            case "animated" -> "Animated";
            default -> "Trails";
        };
    }

    private void showFriends() {
        activePage = Page.FRIENDS;
        settingsPage = false;
        updateNavigationState();
        StackPane root = baseLayout();
        VBox content = pageContent("Community", "Friends",
                "Add friends by their V-Client username, see who is online and what they are playing. Needs a free V-Client account.");
        FriendsPage page = new FriendsPage();
        content.getChildren().addAll(page.notice, page.accountSection(), page.localCard());
        setPageContent(root, content);
        stage.setScene(new Scene(root, stage.getWidth(), stage.getHeight()));
        page.start();
    }

    /** What the launcher tells friends it is doing; sent as a heartbeat every 45 seconds while signed in. */
    private volatile String presenceActivity = "In the launcher";
    private volatile String presenceServer = "";
    private java.util.concurrent.ScheduledExecutorService presenceScheduler;

    private void startPresence() {
        if (presenceScheduler != null) return;
        presenceScheduler = java.util.concurrent.Executors.newSingleThreadScheduledExecutor(runnable -> {
            Thread thread = new Thread(runnable, "vclient-presence");
            thread.setDaemon(true);
            return thread;
        });
        presenceScheduler.scheduleWithFixedDelay(this::sendPresenceNow, 3, 45, TimeUnit.SECONDS);
    }

    private void sendPresenceNow() {
        String token = settings.backendToken();
        BackendClient client = backend();
        if (token.isBlank() || !client.configured() || settings.offlineMode()) return;
        try {
            client.sendPresence(token, presenceActivity, presenceServer);
        } catch (IOException | InterruptedException e) {
            if (e instanceof InterruptedException) Thread.currentThread().interrupt();
            // A missed heartbeat only means friends see you as offline for a moment; the next one retries.
        }
    }

    private void setPresence(String activity, String server) {
        presenceActivity = activity;
        presenceServer = server;
        executor.execute(this::sendPresenceNow);
    }

    /** The Friends page: V-Client account friends with presence, plus the old on-device list of names. */
    private final class FriendsPage {
        private final VBox notice = new VBox(10);
        private final VBox requestsCard = ModsUi.glassCard(12, new Insets(20));
        private final VBox friendsCard = ModsUi.glassCard(12, new Insets(20));
        private final VBox requestsBody = new VBox(8);
        private final VBox friendsBody = new VBox(8);
        private final Label friendsCount = ModsUi.chip("", ModsUi.MUTED);
        private final TextField username = new TextField();
        private final Button add = new Button("ADD FRIEND");
        private javafx.animation.Timeline refreshTimer;

        FriendsPage() {
            notice.setManaged(false);
            notice.setVisible(false);
            requestsCard.setManaged(false);
            requestsCard.setVisible(false);
        }

        private boolean signedIn() {
            return !settings.backendToken().isBlank() && backend().configured();
        }

        private void showNotice(javafx.scene.Node... nodes) {
            notice.getChildren().setAll(nodes);
            notice.setManaged(nodes.length > 0);
            notice.setVisible(nodes.length > 0);
        }

        VBox accountSection() {
            VBox section = new VBox(16);
            if (!signedIn()) {
                VBox card = ModsUi.glassCard(14, new Insets(22));
                boolean noBackend = !backend().configured();
                Label title = ModsUi.text(noBackend ? "Connect to the V-Client backend first" : "Sign in to add friends", 16, ModsUi.TEXT, true);
                Label body = ModsUi.text(noBackend
                        ? "Friends are stored on the V-Client backend. Set its address on the News page (Backend & updates), then create your account there."
                        : "Create a free V-Client account or sign in on the News page. Then you can add friends by username, see who is online and what they are playing.",
                        12, ModsUi.MUTED, false);
                body.setWrapText(true);
                Button open = new Button("OPEN THE NEWS PAGE");
                open.setMinHeight(40);
                open.setStyle("-fx-background-color: " + ACCENT + "; -fx-text-fill: #071321; -fx-font-size: 12px; -fx-font-weight: bold;"
                        + " -fx-background-radius: 12; -fx-padding: 0 22 0 22; -fx-cursor: hand;");
                open.setOnAction(event -> showNews());
                card.getChildren().addAll(title, body, open);
                section.getChildren().add(card);
                return section;
            }
            VBox addCard = ModsUi.glassCard(12, new Insets(20));
            username.setPromptText("Your friend's V-Client username");
            username.setStyle("-fx-background-color: rgba(7, 19, 33, 0.85); -fx-text-fill: #f5f7fd; -fx-prompt-text-fill: #6f9bb5;"
                    + " -fx-font-size: 13px; -fx-border-color: rgba(255,255,255,0.14); -fx-background-radius: 12;"
                    + " -fx-border-radius: 12; -fx-padding: 0 14 0 14;");
            username.setMinHeight(44);
            username.setPrefHeight(44);
            HBox.setHgrow(username, Priority.ALWAYS);
            add.setMinHeight(44);
            add.setMinWidth(Region.USE_PREF_SIZE);
            add.setStyle("-fx-background-color: " + ACCENT + "; -fx-text-fill: #071321; -fx-font-size: 12px; -fx-font-weight: bold;"
                    + " -fx-background-radius: 12; -fx-padding: 0 24 0 24; -fx-cursor: hand;");
            add.setOnAction(event -> sendRequest());
            username.setOnAction(event -> sendRequest());
            HBox row = new HBox(12, username, add);
            row.setAlignment(Pos.CENTER_LEFT);
            addCard.getChildren().addAll(ModsUi.sectionTitle("Add a friend"), row);

            requestsCard.getChildren().addAll(ModsUi.sectionTitle("Friend requests"), requestsBody);
            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);
            HBox heading = new HBox(10, ModsUi.sectionTitle("Friends"), friendsCount);
            heading.setAlignment(Pos.CENTER_LEFT);
            friendsCard.getChildren().addAll(heading, friendsBody);
            friendsBody.getChildren().add(ModsUi.busyLabel("Loading your friends…"));
            section.getChildren().addAll(addCard, requestsCard, friendsCard);
            return section;
        }

        void start() {
            if (!signedIn()) return;
            reload();
            refreshTimer = new javafx.animation.Timeline(new javafx.animation.KeyFrame(javafx.util.Duration.seconds(20), event -> {
                if (activePage != Page.FRIENDS) {
                    refreshTimer.stop();
                    return;
                }
                reload();
            }));
            refreshTimer.setCycleCount(javafx.animation.Animation.INDEFINITE);
            refreshTimer.play();
        }

        private void reload() {
            String token = settings.backendToken();
            BackendClient client = backend();
            executor.execute(() -> {
                try {
                    BackendClient.FriendsOverview overview = client.friends(token);
                    Platform.runLater(() -> {
                        if (activePage == Page.FRIENDS) render(overview);
                    });
                } catch (IOException | InterruptedException e) {
                    if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                    boolean expired = e instanceof BackendClient.BackendException && e.getMessage() != null
                            && e.getMessage().toLowerCase(java.util.Locale.ROOT).contains("sign in");
                    Platform.runLater(() -> {
                        if (activePage != Page.FRIENDS) return;
                        if (expired) {
                            settings.setBackendToken("");
                            saveSettings();
                            showFriends();
                            return;
                        }
                        String[] message = ModsUi.describeFailure("Loading your friends", e.getMessage());
                        showNotice(ModsUi.warningBox(message[0], message[1], this::reload));
                        friendsBody.getChildren().setAll(ModsUi.emptyCard("⚠", "Friends are unavailable right now",
                                "Check the message above, then try again."));
                    });
                }
            });
        }

        private void render(BackendClient.FriendsOverview overview) {
            showNotice();
            long online = overview.friends().stream().filter(BackendClient.Friend::online).count();
            friendsCount.setText(overview.friends().size() + " friends  ·  " + online + " online");
            if (overview.friends().isEmpty()) {
                friendsBody.getChildren().setAll(ModsUi.emptyCard("♢", "No friends yet",
                        "Type a friend's V-Client username above and send them a request."));
            } else {
                List<javafx.scene.Node> rows = new ArrayList<>();
                for (BackendClient.Friend friend : overview.friends()) rows.add(friendRow(friend));
                friendsBody.getChildren().setAll(rows);
            }
            boolean hasRequests = !overview.incoming().isEmpty() || !overview.outgoing().isEmpty();
            requestsCard.setManaged(hasRequests);
            requestsCard.setVisible(hasRequests);
            List<javafx.scene.Node> requests = new ArrayList<>();
            for (BackendClient.FriendRequest request : overview.incoming()) {
                Button accept = smallButton("ACCEPT", ACCENT, "#071321");
                accept.setOnAction(event -> respond(() -> backend().acceptFriend(settings.backendToken(), request.requestId())));
                Button decline = smallButton("DECLINE", "rgba(255,255,255,0.08)", "#f5f7fd");
                decline.setOnAction(event -> respond(() -> backend().dropFriendRequest(settings.backendToken(), request.requestId())));
                requests.add(personRow(ModsUi.text(request.username(), 13, ModsUi.TEXT, true),
                        ModsUi.text("wants to be your friend", 11, ModsUi.MUTED, false), accept, decline));
            }
            for (BackendClient.FriendRequest request : overview.outgoing()) {
                Button cancel = smallButton("CANCEL", "rgba(255,255,255,0.08)", "#f5f7fd");
                cancel.setOnAction(event -> respond(() -> backend().dropFriendRequest(settings.backendToken(), request.requestId())));
                requests.add(personRow(ModsUi.text(request.username(), 13, ModsUi.TEXT, true),
                        ModsUi.text("request sent, waiting for them", 11, ModsUi.MUTED, false), cancel));
            }
            requestsBody.getChildren().setAll(requests);
        }

        private Button smallButton(String label, String background, String textColor) {
            Button button = new Button(label);
            button.setMinHeight(32);
            button.setMinWidth(Region.USE_PREF_SIZE);
            button.setStyle("-fx-background-color: " + background + "; -fx-text-fill: " + textColor + "; -fx-font-size: 10px;"
                    + " -fx-font-weight: bold; -fx-background-radius: 9; -fx-padding: 0 14 0 14; -fx-cursor: hand;");
            return button;
        }

        private HBox personRow(javafx.scene.Node name, javafx.scene.Node detail, Button... actions) {
            VBox text = new VBox(2, name, detail);
            text.setMinWidth(0);
            HBox.setHgrow(text, Priority.ALWAYS);
            HBox row = new HBox(10, text);
            row.getChildren().addAll(actions);
            row.setAlignment(Pos.CENTER_LEFT);
            row.setPadding(new Insets(10, 14, 10, 14));
            String base = "-fx-background-color: rgba(255,255,255,0.05); -fx-background-radius: 12;";
            row.setStyle(base);
            row.setOnMouseEntered(event -> row.setStyle(base + " -fx-background-color: rgba(255,255,255,0.09);"));
            row.setOnMouseExited(event -> row.setStyle(base));
            return row;
        }

        private HBox friendRow(BackendClient.Friend friend) {
            Region dot = dot(friend.online() ? ModsUi.GOOD : "#4a6a85");
            Label name = ModsUi.text(friend.username(), 14, ModsUi.TEXT, true);
            String detail = friend.online()
                    ? (friend.activity().isBlank() ? "Online" : friend.activity()) + (friend.server().isBlank() ? "" : "  ·  " + friend.server())
                    : "Offline";
            Label state = ModsUi.text(detail, 11, friend.online() ? "#8ff0b8" : "#6f9bb5", false);
            HBox title = new HBox(8, dot, name);
            if (!friend.minecraftName().isBlank()) title.getChildren().add(ModsUi.chip("MC: " + friend.minecraftName(), ModsUi.MUTED));
            title.setAlignment(Pos.CENTER_LEFT);
            Button remove = smallButton("REMOVE", "rgba(255,99,120,0.14)", "#ff9aa8");
            remove.setOnAction(event -> {
                Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, "Remove " + friend.username() + " from your friends?",
                        ButtonType.OK, ButtonType.CANCEL);
                confirm.initOwner(stage);
                confirm.setTitle("V-Client");
                confirm.setHeaderText("Remove friend");
                if (confirm.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
                    respond(() -> backend().removeFriend(settings.backendToken(), friend.userId()));
                }
            });
            return personRow(title, state, remove);
        }

        @FunctionalInterface
        private interface Call {
            void run() throws IOException, InterruptedException;
        }

        private void respond(Call call) {
            executor.execute(() -> {
                try {
                    call.run();
                    Platform.runLater(this::reload);
                } catch (IOException | InterruptedException e) {
                    if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                    Platform.runLater(() -> showNotice(ModsUi.warningBox("That didn't work", e.getMessage(), null)));
                }
            });
        }

        private void sendRequest() {
            String name = username.getText() == null ? "" : username.getText().strip();
            if (name.isEmpty()) return;
            add.setDisable(true);
            executor.execute(() -> {
                try {
                    String result = backend().requestFriend(settings.backendToken(), name);
                    Platform.runLater(() -> {
                        username.clear();
                        showNotice(friendNotice("accepted".equals(result)
                                ? "You and " + name + " are now friends."
                                : "Friend request sent to " + name + "."));
                        reload();
                    });
                } catch (IOException | InterruptedException e) {
                    if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                    Platform.runLater(() -> showNotice(ModsUi.warningBox("Couldn't add " + name, e.getMessage(), null)));
                } finally {
                    Platform.runLater(() -> add.setDisable(false));
                }
            });
        }

        private HBox friendNotice(String message) {
            Label icon = ModsUi.text("✓", 16, "#08140e", true);
            icon.setMinSize(30, 30);
            icon.setAlignment(Pos.CENTER);
            icon.setStyle(icon.getStyle() + " -fx-background-color: " + ModsUi.GOOD + "; -fx-background-radius: 15;");
            HBox box = new HBox(12, icon, ModsUi.text(message, 13, "#bff5d6", true));
            box.setAlignment(Pos.CENTER_LEFT);
            box.setPadding(new Insets(12, 16, 12, 14));
            box.setStyle("-fx-background-color: rgba(57,217,138,0.10); -fx-background-radius: 14;"
                    + " -fx-border-color: rgba(57,217,138,0.40); -fx-border-radius: 14;");
            return box;
        }

        /** The original list of Minecraft names saved only on this PC (no account needed). */
        VBox localCard() {
            VBox card = ModsUi.glassCard(12, new Insets(20));
            TextField name = new TextField();
            name.setPromptText("Minecraft username");
            name.setStyle("-fx-background-color: rgba(7, 19, 33, 0.85); -fx-text-fill: #f5f7fd; -fx-prompt-text-fill: #6f9bb5;"
                    + " -fx-font-size: 13px; -fx-border-color: rgba(255,255,255,0.14); -fx-background-radius: 12;"
                    + " -fx-border-radius: 12; -fx-padding: 0 14 0 14;");
            name.setMinHeight(40);
            HBox.setHgrow(name, Priority.ALWAYS);
            Button save = smallButton("SAVE NAME", "rgba(255,255,255,0.08)", "#f5f7fd");
            save.setMinHeight(40);
            VBox list = new VBox(6);
            Runnable render = () -> {
                List<javafx.scene.Node> rows = new ArrayList<>();
                for (String saved : localFriends) {
                    Button remove = smallButton("REMOVE", "rgba(255,99,120,0.14)", "#ff9aa8");
                    remove.setOnAction(event -> {
                        try {
                            localFriends.clear();
                            localFriends.addAll(friendsStore.remove(saved));
                            showFriends();
                        } catch (IOException e) {
                            showNotice(ModsUi.warningBox("Couldn't remove the name", e.getMessage(), null));
                        }
                    });
                    rows.add(personRow(ModsUi.text(saved, 13, ModsUi.TEXT, true), ModsUi.text("saved on this PC only", 11, ModsUi.MUTED, false), remove));
                }
                if (rows.isEmpty()) rows.add(ModsUi.text("No names saved yet.", 12, ModsUi.MUTED, false));
                list.getChildren().setAll(rows);
            };
            save.setOnAction(event -> {
                try {
                    localFriends.clear();
                    localFriends.addAll(friendsStore.add(name.getText()));
                    name.clear();
                    render.run();
                } catch (IOException e) {
                    showNotice(ModsUi.warningBox("Couldn't save the name", e.getMessage(), null));
                }
            });
            render.run();
            HBox row = new HBox(12, name, save);
            row.setAlignment(Pos.CENTER_LEFT);
            Label hint = ModsUi.text("Just a private notepad of Minecraft usernames on this device. No account and no server needed.", 11, ModsUi.MUTED, false);
            hint.setWrapText(true);
            card.getChildren().addAll(ModsUi.sectionTitle("Saved names (this PC only)"), row, list, hint);
            return card;
        }
    }

    private void showConsole() {
        activePage = Page.CONSOLE;
        settingsPage = false;
        updateNavigationState();
        StackPane root = baseLayout();
        VBox content = pageContent("Diagnostics", "Console", "Recent launcher and Minecraft output for this session.");
        HBox actions = new HBox(10);
        Button copy = button("COPY LOG", "#11263D", 10);
        Button clear = button("CLEAR LOG", "#482332", 10);
        actions.getChildren().addAll(copy, clear);
        consoleLog = new TextArea(String.join(System.lineSeparator(), logLines));
        consoleLog.setEditable(false);
        consoleLog.setWrapText(true);
        consoleLog.setPrefRowCount(22);
        consoleLog.setStyle("-fx-control-inner-background: rgba(7, 19, 33, 0.82); -fx-text-fill: #b8dcee; -fx-font-family: 'Consolas'; -fx-font-size: 11px; -fx-background-color: rgba(7, 19, 33, 0.82); -fx-border-color: #1e4260; -fx-border-radius: 8; -fx-background-radius: 8;");
        VBox.setVgrow(consoleLog, Priority.ALWAYS);
        copy.setOnAction(event -> {
            ClipboardContent clipboard = new ClipboardContent();
            clipboard.putString(consoleLog.getText());
            Clipboard.getSystemClipboard().setContent(clipboard);
        });
        clear.setOnAction(event -> {
            logLines.clear();
            consoleLog.clear();
            if (log != null) log.clear();
        });
        content.getChildren().addAll(actions, consoleLog);
        setPageContent(root, content);
        stage.setScene(new Scene(root, stage.getWidth(), stage.getHeight()));
    }

    // ---- VSMP backend: news, announcements, server status, accounts, updates, error logs ----

    private BackendClient backend() {
        return new BackendClient(BackendClient.resolveUrl(settings.backendUrl()));
    }

    private static String announcementColor(String level) {
        return switch (level) {
            case "critical" -> "#5a1c26";
            case "warning" -> "#4a3a12";
            default -> "#17315a";
        };
    }

    /** A box that fills itself with active announcements; stays empty when the backend is unavailable. */
    /** Tells the backend which account is playing so admins can find the player later; never blocks or fails the launch. */
    private void recordPlayerAsync(PlayerAccount player) {
        BackendClient client = backend();
        if (player == null || !client.configured() || settings.offlineMode()) return;
        String type = switch (player.type()) {
            case MICROSOFT -> "microsoft";
            case ELY_BY -> "ely_by";
            case OFFLINE -> "offline";
        };
        executor.execute(() -> client.recordPlayer(player.uuid(), player.name(), type));
    }

    private static String timeAgo(String iso) {
        try {
            long seconds = Math.max(0, java.time.Duration.between(java.time.Instant.parse(iso), java.time.Instant.now()).getSeconds());
            if (seconds < 90) return "just now";
            if (seconds < 3600) return seconds / 60 + " min ago";
            if (seconds < 86400) return seconds / 3600 + " h ago";
            return seconds / 86400 + " d ago";
        } catch (java.time.format.DateTimeParseException e) {
            return "";
        }
    }

    /** The admin panel on the News page: only shown (and only works) when the signed-in V-Client account is the admin. */
    private VBox adminCard() {
        VBox box = card();
        box.setManaged(false);
        box.setVisible(false);
        BackendClient client = backend();
        String token = settings.backendToken();
        // Only the admin game account (Izyrn on Ely.by) gets the panel, whatever V-Client account is signed in.
        if (account == null || !settings.isAdmin(account) || token.isBlank() || !client.configured()) return box;

        Label summary = label("Loading players…", 12, "#e6ebf7");
        TextField search = new TextField();
        search.setPromptText("Search players by name");
        search.setStyle(fieldStyle());
        HBox.setHgrow(search, Priority.ALWAYS);
        Button refresh = button("REFRESH", "#11263D", 10);
        HBox searchRow = new HBox(10, search, refresh);
        searchRow.setAlignment(Pos.CENTER_LEFT);
        VBox rows = new VBox(8);
        TextField byName = new TextField();
        byName.setPromptText("Player name (even if they have not played yet)");
        byName.setStyle(fieldStyle());
        HBox.setHgrow(byName, Priority.ALWAYS);
        Button grantByName = button("UNLOCK FOR A NAME", ACCENT, 10);
        HBox nameRow = new HBox(10, byName, grantByName);
        nameRow.setAlignment(Pos.CENTER_LEFT);
        box.getChildren().addAll(label("ADMIN PANEL", 11, ACCENT), summary, searchRow, rows,
                label("Not in the list yet?", 11, MUTED), nameRow);

        Runnable load = () -> {
            summary.setText("Loading players…");
            executor.execute(() -> {
                try {
                    BackendClient.AdminOverview overview = client.adminPlayers(token, search.getText().trim());
                    Platform.runLater(() -> {
                        summary.setText(overview.total() + " players have played  ·  " + overview.activeToday()
                                + " in the last 24 hours  ·  " + overview.accounts() + " V-Client accounts");
                        rows.getChildren().clear();
                        if (overview.players().isEmpty()) {
                            rows.getChildren().add(label("No players found yet. They appear here after they start the game from V-Client 1.3.0 or newer.", 12, MUTED));
                        }
                        for (BackendClient.AdminPlayer player : overview.players()) {
                            Label name = label(player.name(), 13, "#f3f6fc");
                            name.setStyle(name.getStyle() + "-fx-font-weight: bold;");
                            Label kind = ModsUi.chip(switch (player.accountType()) {
                                case "ely_by" -> "ELY.BY";
                                case "microsoft" -> "PREMIUM";
                                default -> "OFFLINE";
                            }, ModsUi.MUTED);
                            Label seen = label(timeAgo(player.lastSeen()) + "  ·  " + player.launches() + " launches"
                                    + (player.grants() > 0 ? "  ·  " + player.grants() + " unlocked" : ""), 11, MUTED);
                            Region spacer = new Region();
                            HBox.setHgrow(spacer, Priority.ALWAYS);
                            Button manage = button("UNLOCK", "#11263D", 10);
                            manage.setOnAction(event -> openGrantDialog(client, token, player.name(), player.uuid(), refresh::fire));
                            HBox row = new HBox(10, name, kind, seen, spacer, manage);
                            row.setAlignment(Pos.CENTER_LEFT);
                            rows.getChildren().add(row);
                        }
                    });
                } catch (IOException | InterruptedException e) {
                    if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                    Platform.runLater(() -> summary.setText("Could not load players: " + e.getMessage()));
                }
            });
        };
        refresh.setOnAction(event -> load.run());
        search.setOnAction(event -> load.run());
        grantByName.setOnAction(event -> {
            String typed = byName.getText().trim();
            if (typed.isEmpty()) return;
            openGrantDialog(client, token, typed, typed, load);
        });
        executor.execute(() -> {
            try {
                if (client.isAdmin(token)) {
                    Platform.runLater(() -> {
                        box.setManaged(true);
                        box.setVisible(true);
                        load.run();
                    });
                }
            } catch (IOException | InterruptedException e) {
                if (e instanceof InterruptedException) Thread.currentThread().interrupt();
            }
        });
        return box;
    }

    /** Dialog that unlocks or removes cosmetics, or gives an invite reward, for one player (a name or a UUID). */
    private void openGrantDialog(BackendClient client, String token, String displayName, String player, Runnable onChanged) {
        java.util.Map<String, String> names = new java.util.HashMap<>();
        for (CosmeticsStore.Item item : CosmeticsStore.builtIn()) names.put(item.id(), item.name());
        java.util.function.Function<String, String> nameOf = id -> names.getOrDefault(id, id);

        Dialog<Void> dialog = new Dialog<>();
        dialog.initOwner(stage);
        dialog.setTitle("Unlock cosmetics");
        dialog.setHeaderText(displayName);
        dialog.getDialogPane().getButtonTypes().add(javafx.scene.control.ButtonType.CLOSE);
        dialog.getDialogPane().setPrefWidth(560);

        Label owned = label("Loading what they have…", 12, "#e6ebf7");
        owned.setWrapText(true);
        Label result = label("", 12, MUTED);
        result.setWrapText(true);

        ComboBox<CosmeticsStore.Item> cosmetic = new ComboBox<>();
        cosmetic.setMaxWidth(Double.MAX_VALUE);
        cosmetic.getItems().addAll(CosmeticsStore.builtIn().stream().filter(item -> !"free".equals(item.tier())).toList());
        cosmetic.setConverter(new javafx.util.StringConverter<>() {
            @Override public String toString(CosmeticsStore.Item item) {
                return item == null ? "" : item.name() + "  —  " + item.category() + " (" + item.tier() + ")";
            }
            @Override public CosmeticsStore.Item fromString(String text) { return null; }
        });
        cosmetic.setPromptText("Choose a cosmetic");
        Button unlock = button("UNLOCK", ACCENT, 10);
        Button revoke = button("TAKE AWAY", "#482332", 10);
        HBox cosmeticRow = new HBox(10, cosmetic, unlock, revoke);
        HBox.setHgrow(cosmetic, Priority.ALWAYS);
        cosmeticRow.setAlignment(Pos.CENTER_LEFT);

        ComboBox<BackendClient.AdminReward> reward = new ComboBox<>();
        reward.setMaxWidth(Double.MAX_VALUE);
        reward.setPromptText("Invite reward");
        reward.setConverter(new javafx.util.StringConverter<>() {
            @Override public String toString(BackendClient.AdminReward value) {
                return value == null ? "" : value.invites() + " invites  —  "
                        + value.cosmetics().stream().map(nameOf).collect(java.util.stream.Collectors.joining(", "));
            }
            @Override public BackendClient.AdminReward fromString(String text) { return null; }
        });
        Button giveReward = button("GIVE REWARD", ACCENT, 10);
        HBox rewardRow = new HBox(10, reward, giveReward);
        HBox.setHgrow(reward, Priority.ALWAYS);
        rewardRow.setAlignment(Pos.CENTER_LEFT);

        VBox content = new VBox(10, label("UNLOCKED NOW", 11, MUTED), owned, label("UNLOCK ONE COSMETIC", 11, MUTED), cosmeticRow,
                label("INVITE REWARD (includes every tier below it)", 11, MUTED), rewardRow, result);
        content.setPadding(new Insets(14));
        content.setStyle("-fx-background-color: #0b1c30;");
        dialog.getDialogPane().setStyle("-fx-background-color: #0b1c30;");
        dialog.getDialogPane().setContent(content);

        java.util.concurrent.atomic.AtomicReference<List<String>> uuids = new java.util.concurrent.atomic.AtomicReference<>(List.of());
        Runnable showOwned = () -> executor.execute(() -> {
            try {
                List<String> lines = new ArrayList<>();
                for (String uuid : uuids.get()) {
                    List<String> ids = client.adminGrants(token, uuid);
                    lines.add(ids.isEmpty() ? "Nothing granted yet." : ids.stream().map(nameOf).collect(java.util.stream.Collectors.joining(", ")));
                }
                Platform.runLater(() -> owned.setText(String.join("   |   ", lines)));
            } catch (IOException | InterruptedException e) {
                if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                Platform.runLater(() -> owned.setText("Could not load: " + e.getMessage()));
            }
        });
        java.util.function.Consumer<String> fail = message -> Platform.runLater(() -> {
            result.setStyle("-fx-text-fill: #ff9aa5; -fx-font-size: 12px;");
            result.setText(message);
        });
        java.util.function.Consumer<String> ok = message -> Platform.runLater(() -> {
            result.setStyle("-fx-text-fill: #6fd39b; -fx-font-size: 12px;");
            result.setText(message);
            onChanged.run();
        });

        executor.execute(() -> {
            try {
                // A name can be an offline account and an Ely.by account (different UUIDs); the backend returns both.
                uuids.set(client.adminGrant(token, player, null, 0).uuids());
                List<BackendClient.AdminReward> rewards = client.adminRewards(token);
                Platform.runLater(() -> reward.getItems().setAll(rewards));
                showOwned.run();
            } catch (IOException | InterruptedException e) {
                if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                fail.accept(e.getMessage());
            }
        });

        unlock.setOnAction(event -> {
            CosmeticsStore.Item item = cosmetic.getValue();
            if (item == null) return;
            executor.execute(() -> {
                try {
                    client.adminGrant(token, player, item.id(), null);
                    ok.accept("Unlocked " + item.name() + " for " + displayName + ". They see it after restarting the game or pressing Refresh in the Cosmetics menu.");
                    showOwned.run();
                } catch (IOException | InterruptedException e) {
                    if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                    fail.accept(e.getMessage());
                }
            });
        });
        revoke.setOnAction(event -> {
            CosmeticsStore.Item item = cosmetic.getValue();
            if (item == null) return;
            executor.execute(() -> {
                try {
                    for (String uuid : uuids.get()) client.adminRevoke(token, uuid, item.id());
                    ok.accept("Took " + item.name() + " away from " + displayName + ".");
                    showOwned.run();
                } catch (IOException | InterruptedException e) {
                    if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                    fail.accept(e.getMessage());
                }
            });
        });
        giveReward.setOnAction(event -> {
            BackendClient.AdminReward tier = reward.getValue();
            if (tier == null) return;
            executor.execute(() -> {
                try {
                    BackendClient.GrantResult granted = client.adminGrant(token, player, null, tier.invites());
                    ok.accept("Gave the " + tier.invites() + "-invite reward to " + displayName + ": "
                            + granted.granted().stream().map(nameOf).collect(java.util.stream.Collectors.joining(", ")) + ".");
                    showOwned.run();
                } catch (IOException | InterruptedException e) {
                    if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                    fail.accept(e.getMessage());
                }
            });
        });
        dialog.show();
    }


    /** The built-in launch-event notice: always shown, needs no backend. */
    private VBox launchEventBanner() {
        Label tag = label("NEWS  ·  SHOUTOUT  ·  LIVE NOW", 10, "#B8F4FF");
        tag.setStyle(tag.getStyle() + "-fx-font-weight: bold; -fx-letter-spacing: 2;");
        Label headline = label("Senpai_🔥🥶 The Goat!!!", 16, "#f3f6fc");
        headline.setStyle(headline.getStyle() + "-fx-font-weight: bold; -fx-font-family: 'Segoe UI Emoji', 'Segoe UI';");
        headline.setWrapText(true);
        Label detail = label("Anime capes (animated and still), new trails and more are in the Cosmetics menu until 31 December.", 12, "#c9d3e6");
        detail.setWrapText(true);
        VBox box = new VBox(6, tag, headline, detail);
        box.setPadding(new Insets(16, 20, 16, 20));
        box.setStyle("-fx-background-color: linear-gradient(to right, rgba(0, 150, 200, 0.40), rgba(17, 38, 61, 0.7)); -fx-background-radius: 12; -fx-border-color: rgba(124, 235, 255, 0.55); -fx-border-radius: 12;");
        return box;
    }

    private VBox announcementBox() {
        VBox box = new VBox(8);
        BackendClient client = backend();
        if (!client.configured()) return box;
        // Last known announcements show at once (the backend may be asleep); a pulsing placeholder covers a first run.
        BackendClient.Cached<List<BackendClient.Announcement>> cached = client.cachedAnnouncements();
        if (cached != null) fillAnnouncements(box, cached.value());
        else box.getChildren().add(Widgets.skeleton(0, 38));
        executor.execute(() -> {
            try {
                List<BackendClient.Announcement> items = client.announcements();
                Platform.runLater(() -> fillAnnouncements(box, items));
            } catch (IOException | InterruptedException e) {
                if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                if (cached == null) Platform.runLater(() -> box.getChildren().clear());
            }
        });
        return box;
    }

    private void fillAnnouncements(VBox box, List<BackendClient.Announcement> items) {
        box.getChildren().clear();
        for (BackendClient.Announcement item : items) {
            Label message = label(item.message(), 13, "#f3f6fc");
            message.setWrapText(true);
            HBox row = new HBox(message);
            row.setPadding(new Insets(10, 14, 10, 14));
            row.setStyle("-fx-background-color: " + announcementColor(item.level()) + "; -fx-background-radius: 9;");
            box.getChildren().add(row);
        }
    }

    /** Fills {@code target} with the VSMP server state; safe to call from the FX thread. */
    private void loadServerStatus(Label target, Region indicator) {
        BackendClient client = backend();
        if (!client.configured()) {
            target.setText("VSMP status unavailable — set the backend address on the News page.");
            return;
        }
        BackendClient.Cached<BackendClient.ServerStatus> cached = client.cachedServerStatus();
        if (cached != null) {
            showServerStatus(target, indicator, cached.value(), "last known " + timeAgoMillis(cached.savedAtMillis()), true);
        } else {
            target.setText("Checking VSMP…");
        }
        executor.execute(() -> {
            try {
                BackendClient.ServerStatus state = client.serverStatus();
                Platform.runLater(() -> showServerStatus(target, indicator, state, "", false));
            } catch (IOException | InterruptedException e) {
                if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                boolean waking = BackendClient.isWaking(e);
                Platform.runLater(() -> {
                    indicator.setStyle("-fx-background-color: " + (waking ? Widgets.YELLOW : "#64728a") + "; -fx-background-radius: 50%;");
                    if (cached != null) {
                        showServerStatus(target, indicator, cached.value(),
                                (waking ? "server waking up… · " : "") + "last known " + timeAgoMillis(cached.savedAtMillis()), true);
                        indicator.setStyle("-fx-background-color: " + (waking ? Widgets.YELLOW : "#64728a") + "; -fx-background-radius: 50%;");
                    } else {
                        target.setText(waking ? "Server waking up… (this can take up to a minute)"
                                : "VSMP status unavailable — " + FriendlyError.of(e).title().toLowerCase(java.util.Locale.ROOT));
                    }
                });
            }
        });
    }

    private void showServerStatus(Label target, Region indicator, BackendClient.ServerStatus state, String note, boolean stale) {
        indicator.setStyle("-fx-background-color: " + (stale ? "#64728a" : state.online() ? Widgets.GREEN : Widgets.RED)
                + "; -fx-background-radius: 50%;");
        String suffix = note.isBlank() ? "" : "  ·  " + note;
        target.setText((state.online()
                ? "VSMP ONLINE  ·  " + state.players() + " / " + state.maxPlayers() + " players  ·  " + state.version()
                : "VSMP is offline right now") + suffix);
        if (!stale && state.online()) {
            smpButtonText = "JOIN OUR SMP  ·  " + state.players() + " online";
        } else if (!stale) {
            smpButtonText = "JOIN OUR SMP";
        }
        if (singleplayerButton != null && !singleplayerButton.isDisable()) singleplayerButton.setText(smpButtonText);
    }

    private static String timeAgoMillis(long millis) {
        long seconds = Math.max(0, (System.currentTimeMillis() - millis) / 1000);
        if (seconds < 90) return "just now";
        if (seconds < 3600) return seconds / 60 + " min ago";
        if (seconds < 86_400) return seconds / 3600 + " h ago";
        return seconds / 86_400 + " d ago";
    }

    private void showServers() {
        activePage = Page.SERVERS;
        settingsPage = false;
        updateNavigationState();
        StackPane root = baseLayout();
        VBox content = pageContent("Multiplayer", "Servers", "Live status of our servers, pinged straight from your PC. Press JOIN to launch the selected version and connect.");
        List<Runnable> refreshers = new ArrayList<>();
        Button refreshAll = button("REFRESH ALL", "#11263D", 10);
        refreshAll.setOnAction(event -> refreshers.forEach(Runnable::run));
        content.getChildren().add(refreshAll);
        for (ServerEntry server : SERVER_LIST) {
            VBox box = card();
            Region indicator = dot("#64728a");
            Label name = label(server.name(), 17, "#f3f6fc");
            String address = server.port() == 25565 ? server.host() : server.host() + ":" + server.port();
            Label addressLabel = label(address, 11, MUTED);
            Label state = label("Pinging…", 12, "#b3c0d3");
            Label motd = label("", 11, "#b8dcee");
            motd.setWrapText(true);
            motd.managedProperty().bind(motd.visibleProperty());
            motd.setVisible(false);
            Button join = button("JOIN", ACCENT, 12);
            join.setOnAction(event -> launchGame(server));
            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);
            HBox header = new HBox(10, indicator, new VBox(2, name, addressLabel), spacer, join);
            header.setAlignment(Pos.CENTER_LEFT);
            box.getChildren().addAll(header, state, motd);
            Runnable refresh = () -> {
                state.setText("Pinging…");
                indicator.setStyle("-fx-background-color: #64728a; -fx-background-radius: 50%;");
                executor.execute(() -> {
                    ServerPinger.Result result = ServerPinger.ping(server.host(), server.port());
                    Platform.runLater(() -> {
                        indicator.setStyle("-fx-background-color: " + (result.online() ? "#39d98a" : "#e5626f") + "; -fx-background-radius: 50%;");
                        state.setText(result.online()
                                ? "ONLINE  ·  " + result.players() + " / " + result.maxPlayers() + " players"
                                + (result.latencyMs() >= 0 ? "  ·  " + result.latencyMs() + " ms" : "")
                                + (result.version().isBlank() ? "" : "  ·  " + result.version())
                                : "OFFLINE  ·  " + result.error());
                        motd.setText(result.motd());
                        motd.setVisible(!result.motd().isBlank());
                    });
                });
            };
            refreshers.add(refresh);
            refresh.run();
            content.getChildren().add(box);
        }
        setPageContent(root, content);
        stage.setScene(new Scene(root, stage.getWidth(), stage.getHeight()));
    }

    private void showNews() {
        activePage = Page.NEWS;
        settingsPage = false;
        updateNavigationState();
        StackPane root = baseLayout();
        VBox content = pageContent("Community", "News", "Launcher updates and VSMP server announcements, shared with the Windows and Android apps.");
        BackendClient client = backend();

        VBox statusCard = card();
        Region indicator = dot("#64728a");
        Label statusText = label("", 13, "#e6ebf7");
        Button refreshStatus = button("REFRESH", "#11263D", 10);
        refreshStatus.setOnAction(event -> loadServerStatus(statusText, indicator));
        Button website = button("OPEN WEBSITE", "#11263D", 10);
        website.setDisable(!client.configured());
        website.setOnAction(event -> openExternalPage(client.baseUrl()));
        HBox statusRow = new HBox(10, indicator, statusText);
        statusRow.setAlignment(Pos.CENTER_LEFT);
        statusCard.getChildren().addAll(label("SERVER STATUS", 11, MUTED), statusRow, new HBox(10, refreshStatus, website));
        loadServerStatus(statusText, indicator);

        VBox posts = new VBox(12);
        if (client.configured()) {
            posts.getChildren().add(label("Loading news…", 12, MUTED));
            executor.execute(() -> {
                try {
                    List<BackendClient.NewsPost> items = client.news(20);
                    Platform.runLater(() -> {
                        posts.getChildren().clear();
                        if (items.isEmpty()) posts.getChildren().add(label("No news yet. Check back soon.", 12, MUTED));
                        for (BackendClient.NewsPost post : items) posts.getChildren().add(newsCard(post));
                    });
                } catch (IOException | InterruptedException e) {
                    if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                    Platform.runLater(() -> {
                        posts.getChildren().setAll(label("News could not be loaded: " + e.getMessage(), 12, "#ff9aa5"));
                    });
                }
            });
        } else {
            posts.getChildren().add(label("Set the V-Client backend address below to load news.", 12, MUTED));
        }

        content.getChildren().addAll(launchEventBanner(), announcementBox(), statusCard, posts, accountCard(root), adminCard(), backendCard());
        setPageContent(root, content);
        stage.setScene(new Scene(root, stage.getWidth(), stage.getHeight()));
    }

    private VBox newsCard(BackendClient.NewsPost post) {
        VBox box = card();
        String tag = (post.pinned() ? "PINNED  ·  " : "") + post.category().toUpperCase()
                + "  ·  " + (post.createdAt().length() >= 10 ? post.createdAt().substring(0, 10) : post.createdAt());
        Label meta = label(tag, 10, post.category().equals("server") ? "#6fd39b" : ACCENT);
        Label title = label(post.title(), 17, "#f3f6fc");
        title.setWrapText(true);
        Label body = label(post.body(), 12, "#b8dcee");
        body.setWrapText(true);
        box.getChildren().addAll(meta, title, body);
        return box;
    }

    private VBox accountCard(StackPane root) {
        VBox box = card();
        box.getChildren().add(label("V-CLIENT ACCOUNT", 11, MUTED));
        BackendClient client = backend();
        Label result = label("", 11, MUTED);
        result.setWrapText(true);
        if (!settings.backendToken().isBlank() && client.configured()) {
            Label who = label("Checking your account…", 13, "#e6ebf7");
            TextField minecraft = new TextField();
            minecraft.setPromptText("Minecraft username");
            minecraft.setStyle(fieldStyle());
            TextField ely = new TextField();
            ely.setPromptText("Ely.by username");
            ely.setStyle(fieldStyle());
            Button save = button("SAVE LINKED NAMES", ACCENT, 10);
            Button signOut = button("SIGN OUT", "#482332", 10);
            save.setDisable(true);
            box.getChildren().addAll(who, minecraft, ely, new HBox(10, save, signOut), result);
            executor.execute(() -> {
                try {
                    BackendClient.Session session = client.profile(settings.backendToken());
                    Platform.runLater(() -> {
                        who.setText("Signed in as " + session.username());
                        minecraft.setText(session.minecraftName());
                        ely.setText(session.elybyName());
                        save.setDisable(false);
                    });
                } catch (IOException | InterruptedException e) {
                    if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                    boolean expired = e instanceof BackendClient.BackendException;
                    Platform.runLater(() -> {
                        if (expired) {
                            settings.setBackendToken("");
                            saveSettings();
                            showNews();
                        } else {
                            who.setText("Could not reach the backend: " + e.getMessage());
                        }
                    });
                }
            });
            save.setOnAction(event -> executor.execute(() -> {
                try {
                    client.linkNames(settings.backendToken(), minecraft.getText().strip(), ely.getText().strip());
                    Platform.runLater(() -> result.setText("Linked names saved to your V-Client account."));
                } catch (IOException | InterruptedException e) {
                    if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                    Platform.runLater(() -> result.setText(e.getMessage()));
                }
            }));
            signOut.setOnAction(event -> {
                settings.setBackendToken("");
                saveSettings();
                showNews();
            });
        } else {
            box.getChildren().add(label("One account for Windows, Android and the website. Optional — you can play without it.", 11, MUTED));
            TextField login = new TextField();
            login.setPromptText("Username or email  (for a new account: the username you want)");
            login.setStyle(fieldStyle());
            TextField email = new TextField();
            email.setPromptText("Email (only needed to create an account)");
            email.setStyle(fieldStyle());
            PasswordField password = new PasswordField();
            password.setPromptText("Password (8+ characters)");
            password.setStyle(fieldStyle());
            Button signIn = button("SIGN IN", ACCENT, 10);
            Button create = button("CREATE ACCOUNT", "#11263D", 10);
            if (!client.configured()) {
                box.getChildren().add(ModsUi.warningBox("The V-Client backend address is not set",
                        "Accounts and friends live on the V-Client backend. Enter its address in the \"Backend & updates\" box below and press SAVE ADDRESS, then come back here.",
                        null));
            }
            box.getChildren().addAll(login, email, password, new HBox(10, signIn, create), result);
            java.util.function.Consumer<Boolean> submit = register -> {
                if (!backend().configured()) {
                    result.setText("Set the backend address in the box below first.");
                    return;
                }
                if (login.getText().isBlank() || password.getText().isEmpty() || (register && email.getText().isBlank())) {
                    result.setText(register ? "Enter a username, an email and a password (8+ characters)."
                            : "Enter your username (or email) and your password.");
                    return;
                }
                signIn.setDisable(true);
                create.setDisable(true);
                String loginText = login.getText().strip();
                String emailText = email.getText().strip();
                String passwordText = password.getText();
                result.setText("Contacting the backend…");
                executor.execute(() -> {
                    try {
                        BackendClient.Session session = register
                                ? client.register(loginText, emailText, passwordText)
                                : client.login(loginText, passwordText);
                        Platform.runLater(() -> {
                            settings.setBackendToken(session.token());
                            saveSettings();
                            showNews();
                        });
                    } catch (IOException | InterruptedException e) {
                        if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                        Platform.runLater(() -> {
                            result.setText(e.getMessage());
                            signIn.setDisable(false);
                            create.setDisable(false);
                        });
                    }
                });
            };
            signIn.setOnAction(event -> submit.accept(false));
            create.setOnAction(event -> submit.accept(true));
        }
        return box;
    }

    private VBox backendCard() {
        VBox box = card();
        box.getChildren().add(label("BACKEND & UPDATES", 11, MUTED));
        TextField url = new TextField(settings.backendUrl());
        url.setPromptText("https://your-vclient-backend.example.com");
        url.setStyle(fieldStyle());
        Label result = label("V-Client " + AppInfo.VERSION
                + (BackendClient.resolveUrl("").equals(System.getenv("VCLIENT_BACKEND_URL")) ? "  ·  backend set by VCLIENT_BACKEND_URL" : ""), 11, MUTED);
        result.setWrapText(true);
        Button save = button("SAVE ADDRESS", ACCENT, 10);
        Button check = button("CHECK FOR UPDATES", "#11263D", 10);
        Button auto = button("", "#11263D", 10);
        Runnable refreshAuto = () -> auto.setText(settings.autoUpdate() ? "AUTO-UPDATE: ON" : "AUTO-UPDATE: OFF");
        refreshAuto.run();
        save.setOnAction(event -> {
            String address = BackendClient.normalize(url.getText());
            if (!address.isEmpty() && !BackendClient.isValidUrl(address)) {
                result.setText("Enter a full address starting with https:// (or http:// for a local test server).");
                return;
            }
            settings.setBackendUrl(address);
            saveSettings();
            showNews();
        });
        check.setOnAction(event -> checkForUpdates(true));
        auto.setOnAction(event -> {
            settings.setAutoUpdate(!settings.autoUpdate());
            saveSettings();
            refreshAuto.run();
        });
        box.getChildren().addAll(url, new HBox(10, save, check, auto), result);
        return box;
    }

    // ---- Updates ----

    private void checkForUpdates(boolean manual) {
        BackendClient client = backend();
        // The update file lives on the website, so updates work even while the (sleeping) backend is unreachable.
        executor.execute(() -> {
            try {
                BackendClient.UpdateInfo info = client.checkForUpdate(AppInfo.VERSION);
                Platform.runLater(() -> {
                    if (info.updateAvailable() && info.latest() != null && info.latest().url().endsWith(".exe")) {
                        // A startup check installs the update on its own and reopens V-Client; only the manual
                        // button asks first.
                        if (manual) promptUpdate(info);
                        else downloadUpdate(info.latest());
                    } else if (manual) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION, "You are running the latest version (" + AppInfo.VERSION + ").");
                        alert.initOwner(stage);
                        alert.setHeaderText("V-Client is up to date");
                        alert.show();
                    }
                });
            } catch (IOException | InterruptedException e) {
                if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                Platform.runLater(() -> {
                    appendLog("Update check failed: " + e.getMessage());
                    if (manual) showError("Could not check for updates", e);
                });
            }
        });
    }

    private void promptUpdate(BackendClient.UpdateInfo info) {
        BackendClient.Release release = info.latest();
        ButtonType install = new ButtonType("Update now", javafx.scene.control.ButtonBar.ButtonData.OK_DONE);
        ButtonType later = info.mandatory()
                ? new ButtonType("Quit", javafx.scene.control.ButtonBar.ButtonData.CANCEL_CLOSE)
                : new ButtonType("Later", javafx.scene.control.ButtonBar.ButtonData.CANCEL_CLOSE);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "", install, later);
        alert.initOwner(stage);
        alert.setTitle("V-Client update");
        alert.setHeaderText("V-Client " + release.version() + " is available" + (info.mandatory() ? " (required)" : ""));
        alert.setContentText((release.notes().isBlank() ? "Bug fixes and improvements." : release.notes())
                + "\n\nYou have " + AppInfo.VERSION + ". The installer will be downloaded, checked, and started; V-Client closes while it installs.");
        alert.getDialogPane().setPrefWidth(520);
        alert.showAndWait().ifPresent(choice -> {
            if (choice == install) downloadUpdate(release);
            else if (info.mandatory()) Platform.exit();
        });
    }

    private void downloadUpdate(BackendClient.Release release) {
        javafx.scene.control.ProgressBar bar = new javafx.scene.control.ProgressBar(0);
        bar.setPrefWidth(420);
        Dialog<Void> dialog = new Dialog<>();
        dialog.initOwner(stage);
        dialog.setTitle("Updating V-Client");
        dialog.setHeaderText("Downloading V-Client " + release.version() + "…");
        Label speed = new Label("Starting…");
        dialog.getDialogPane().setContent(new VBox(8, bar, speed));
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);
        long startedNanos = System.nanoTime();
        Thread worker = new Thread(() -> {
            try {
                Path installer = UpdateService.download(release, fraction -> Platform.runLater(() -> {
                    bar.setProgress(fraction);
                    double seconds = Math.max(0.5, (System.nanoTime() - startedNanos) / 1e9);
                    if (release.size() > 0 && fraction > 0) {
                        double rate = release.size() * fraction / seconds;
                        long eta = Math.round(seconds * (1 - fraction) / fraction);
                        speed.setText(DownloadStats.formatSpeed(rate) + "  ·  ETA " + DownloadStats.formatDuration(eta));
                    }
                }));
                UpdateService.launchInstallerAfterExit(installer);
                Platform.runLater(() -> {
                    dialog.close();
                    Platform.exit();
                    System.exit(0);
                });
            } catch (IOException | InterruptedException e) {
                Platform.runLater(() -> {
                    dialog.close();
                    if (!(e instanceof InterruptedException)) showError("Update failed", e);
                });
            }
        }, "vclient-update");
        worker.setDaemon(true);
        worker.start();
        dialog.showAndWait();
        worker.interrupt();
    }

    // ---- Error logs ----

    private void showLogs() {
        activePage = Page.LOGS;
        settingsPage = false;
        updateNavigationState();
        StackPane root = baseLayout();
        VBox content = pageContent("Diagnostics", "Error logs",
                "The latest launch log, Minecraft crash report, and this session's launcher output. Copy any of them when asking for help.");
        Path logsDirectory = settings.minecraftDirectory().resolve("logs");
        Path crashDirectory = settings.minecraftDirectory().resolve("crash-reports");
        TextArea viewer = new TextArea("Choose a log above.");
        viewer.setEditable(false);
        viewer.setWrapText(false);
        viewer.setPrefRowCount(24);
        viewer.setStyle("-fx-control-inner-background: rgba(7, 19, 33, 0.82); -fx-text-fill: #b8dcee; -fx-font-family: 'Consolas'; -fx-font-size: 11px; -fx-background-color: rgba(7, 19, 33, 0.82); -fx-border-color: #1e4260; -fx-border-radius: 8; -fx-background-radius: 8;");
        VBox.setVgrow(viewer, Priority.ALWAYS);
        Button launchLog = button("LAUNCH LOG", "#11263D", 10);
        Button crash = button("LATEST CRASH REPORT", "#11263D", 10);
        Button session = button("LAUNCHER OUTPUT", "#11263D", 10);
        Button copy = button("COPY", "#11263D", 10);
        Button openFolder = button("OPEN LOGS FOLDER", "#11263D", 10);
        launchLog.setOnAction(event -> showLogFile(viewer, logsDirectory.resolve("vclient-launch.log"), "No launch log yet. It is written the first time you press Play."));
        crash.setOnAction(event -> showLogFile(viewer, newestFile(crashDirectory), "No crash reports found. That is good news."));
        session.setOnAction(event -> viewer.setText(logLines.isEmpty() ? "No launcher output in this session yet." : String.join(System.lineSeparator(), logLines)));
        copy.setOnAction(event -> {
            ClipboardContent clipboard = new ClipboardContent();
            clipboard.putString(viewer.getText());
            Clipboard.getSystemClipboard().setContent(clipboard);
        });
        openFolder.setOnAction(event -> {
            try {
                Files.createDirectories(logsDirectory);
                Desktop.getDesktop().open(logsDirectory.toFile());
            } catch (IOException | UnsupportedOperationException e) {
                showError("Could not open the logs folder", e);
            }
        });
        javafx.scene.layout.FlowPane actions = new javafx.scene.layout.FlowPane(10, 10, launchLog, crash, session, copy, openFolder);
        content.getChildren().addAll(actions, viewer);
        setPageContent(root, content);
        stage.setScene(new Scene(root, stage.getWidth(), stage.getHeight()));
        launchLog.fire();
    }

    private void showLogFile(TextArea viewer, Path file, String missingMessage) {
        if (file == null || !Files.isRegularFile(file)) {
            viewer.setText(missingMessage);
            return;
        }
        viewer.setText("Loading " + file.getFileName() + "…");
        executor.execute(() -> {
            String text;
            try {
                text = tail(file, 120_000);
            } catch (IOException e) {
                text = "Could not read " + file + ": " + e.getMessage();
            }
            String shown = text;
            Platform.runLater(() -> {
                viewer.setText(shown);
                viewer.positionCaret(shown.length());
            });
        });
    }

    /** Reads at most the last {@code maxChars} characters of a text file. */
    static String tail(Path file, int maxChars) throws IOException {
        String text = Files.readString(file, java.nio.charset.StandardCharsets.UTF_8);
        return text.length() <= maxChars ? text : "… (earlier output omitted)\n" + text.substring(text.length() - maxChars);
    }

    private static Path newestFile(Path directory) {
        if (!Files.isDirectory(directory)) return null;
        try (java.util.stream.Stream<Path> files = Files.list(directory)) {
            return files.filter(Files::isRegularFile)
                    .max(java.util.Comparator.comparingLong(file -> file.toFile().lastModified()))
                    .orElse(null);
        } catch (IOException e) {
            return null;
        }
    }

    /** Anonymous usage counters, on a background thread so the UI never waits for the network. */
    private void reportEventAsync(String event) {
        // Only one anonymous "launch" event per day per install is ever sent (random local install id, no IP or personal
        // data), and nothing at all while Offline mode is on. Other event names are intentionally not reported.
        if (!"launch".equals(event) || settings.offlineMode()) return;
        String day = java.time.LocalDate.now(java.time.ZoneOffset.UTC).toString();
        if (day.equals(settings.lastLaunchEventDay())) return;
        BackendClient client = backend();
        if (!client.configured()) return;
        executor.execute(() -> {
            if (client.reportEvent(settings.installId(), event)) {
                Platform.runLater(() -> {
                    settings.setLastLaunchEventDay(day);
                    try {
                        settings.save();
                    } catch (IOException ignored) {
                        // the event is re-sent next start at worst
                    }
                });
            }
        });
    }

    private void startBackendTasks() {
        reportEventAsync("launch");
        recordPlayerAsync(account);
        startPresence();
        if (settings.autoUpdate()) checkForUpdates(false);
    }

    private void showDiscord() {
        activePage = Page.DISCORD;
        settingsPage = false;
        updateNavigationState();
        StackPane root = baseLayout();
        VBox content = pageContent("Community", "Discord", "Save an invite URL to open your community in the system browser.");
        VBox inviteCard = card();
        TextField invite = new TextField(settings.discordInvite());
        invite.setPromptText("https://discord.gg/your-invite");
        invite.setStyle(fieldStyle());
        Button save = button("SAVE INVITE", ACCENT, 10);
        Button open = button("OPEN DISCORD INVITE", "#11263D", 10);
        Label result = label("Invite URL is stored locally in launcher settings.", 11, MUTED);
        save.setOnAction(event -> {
            String address = invite.getText() == null ? "" : invite.getText().strip();
            if (!validDiscordInvite(address)) {
                showError("Invalid Discord invite", new IOException("Enter an HTTPS discord.gg invite or a discord.com/invite URL."));
                return;
            }
            settings.setDiscordInvite(address);
            saveSettings();
            result.setText("Discord invite saved.");
        });
        open.setOnAction(event -> {
            String address = settings.discordInvite();
            if (!validDiscordInvite(address)) {
                showError("Discord invite not set", new IOException("Save your community's Discord invite URL first."));
                return;
            }
            openExternalPage(address);
        });
        inviteCard.getChildren().addAll(label("COMMUNITY INVITE URL", 11, MUTED), invite, new HBox(10, save, open), result);
        content.getChildren().addAll(inviteCard,
                label("V-Client does not have a configured community invite yet. Add one above; no URL is invented or contacted automatically.", 12, MUTED));
        setPageContent(root, content);
        stage.setScene(new Scene(root, stage.getWidth(), stage.getHeight()));
    }

    private static boolean validDiscordInvite(String address) {
        try {
            URI uri = URI.create(address);
            String host = uri.getHost();
            return "https".equalsIgnoreCase(uri.getScheme()) && host != null
                    && uri.getUserInfo() == null && uri.getPort() == -1
                    && (host.equalsIgnoreCase("discord.gg")
                    || host.equalsIgnoreCase("discord.com") && uri.getPath() != null
                    && uri.getPath().startsWith("/invite/"));
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    private void openExternalPage(String address) {
        ExternalLinks.open(address, message -> Platform.runLater(() -> appendLog(message)));
    }

    private void showMods() {
        activePage = Page.MODS;
        settingsPage = false;
        updateNavigationState();
        StackPane root = baseLayout();
        VBox content = pageContent("Modrinth", "Mods",
                "Browse Modrinth and install mods straight into your mods folder. The folder is created automatically on your first install.");
        ModsPage page = new ModsPage(content);
        content.getChildren().addAll(page.controlsCard(), page.notice, page.resultsCard(), page.installedCard());
        setPageContent(root, content);
        stage.setScene(new Scene(root, stage.getWidth(), stage.getHeight()));
        page.start();
    }

    /** The Mods page: one glass card for the controls, one for the results, one for what is installed. */
    private final class ModsPage {
        private final Path modsDirectory = settings.minecraftDirectory().resolve("mods").toAbsolutePath().normalize();
        private final AtomicInteger generation = new AtomicInteger();
        private final List<javafx.animation.Animation> animations = new ArrayList<>();
        private final java.util.Map<String, Image> iconCache = new java.util.HashMap<>();
        private final VBox content;
        private final ComboBox<MinecraftLauncher.InstalledVersion> profilePicker = new ComboBox<>();
        private final TextField query = new TextField();
        private final Button search = new Button("SEARCH");
        private final VBox notice = new VBox(10);
        private final VBox resultsBody = new VBox(12);
        private final HBox resultsHeader = new HBox(12);
        private final Label resultsCount = ModsUi.chip("", ModsUi.MUTED);
        private final VBox installedBody = new VBox(8);
        private final Label installedCount = ModsUi.chip("", ModsUi.MUTED);
        private List<ModrinthModService.ModProject> current = List.of();
        private javafx.scene.layout.FlowPane flow;

        ModsPage(VBox content) {
            this.content = content;
            notice.setMaxWidth(Double.MAX_VALUE);
            notice.setManaged(false);
            notice.setVisible(false);
            // The two-column grid follows the real width of the results area.
            resultsBody.widthProperty().addListener((observable, oldWidth, newWidth) -> layoutColumns());
        }

        private static final String FIELD = "-fx-background-color: rgba(7, 19, 33, 0.85); -fx-text-fill: #f5f7fd;"
                + " -fx-prompt-text-fill: #6f9bb5; -fx-font-size: 13px; -fx-border-color: rgba(255,255,255,0.14);"
                + " -fx-background-radius: 12; -fx-border-radius: 12; -fx-padding: 0 14 0 14;";

        VBox controlsCard() {
            VBox card = ModsUi.glassCard(14, new Insets(20));
            profilePicker.setPromptText("Scanning profiles...");
            profilePicker.setStyle(FIELD);
            // The closed box and the dropdown rows both need light text on the dark glass.
            profilePicker.setButtonCell(profileCell());
            profilePicker.setCellFactory(list -> profileCell());
            profilePicker.setPrefWidth(250);
            profilePicker.setMinWidth(170);
            query.setPromptText("Search Modrinth (leave empty for the most popular)");
            query.setStyle(FIELD);
            search.setStyle("-fx-background-color: " + ACCENT + "; -fx-text-fill: #071321; -fx-font-size: 12px;"
                    + " -fx-font-weight: bold; -fx-background-radius: 12; -fx-padding: 0 24 0 24; -fx-cursor: hand;");
            for (javafx.scene.layout.Region control : List.of(profilePicker, query, search)) {
                control.setMinHeight(44);
                control.setPrefHeight(44);
                control.setMaxHeight(44);
            }
            search.setMinWidth(Region.USE_PREF_SIZE);
            query.setMinWidth(120);
            HBox.setHgrow(query, Priority.ALWAYS);
            HBox row = new HBox(12, profilePicker, query, search);
            row.setAlignment(Pos.CENTER_LEFT);
            card.getChildren().addAll(ModsUi.sectionTitle("Find mods"), row);
            search.setOnAction(event -> runSearch());
            query.setOnAction(event -> runSearch());
            profilePicker.valueProperty().addListener((observable, oldProfile, newProfile) -> {
                if (newProfile != null) runSearch();
            });
            return card;
        }

        VBox resultsCard() {
            VBox card = ModsUi.glassCard(14, new Insets(20));
            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);
            resultsHeader.setAlignment(Pos.CENTER_LEFT);
            resultsHeader.getChildren().addAll(ModsUi.sectionTitle("Results"), resultsCount, spacer);
            resultsCount.setVisible(false);
            resultsCount.setManaged(false);
            resultsBody.getChildren().add(ModsUi.emptyCard("✦", "Pick a profile to browse mods",
                    "Choose a Fabric, Forge, NeoForge or Quilt profile above and the compatible mods appear here."));
            card.getChildren().addAll(resultsHeader, resultsBody);
            return card;
        }

        VBox installedCard() {
            VBox card = ModsUi.glassCard(14, new Insets(20));
            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);
            Button refresh = secondaryButton("REFRESH");
            refresh.setOnAction(event -> loadInstalled());
            Button openFolder = secondaryButton("OPEN FOLDER");
            openFolder.setOnAction(event -> {
                try {
                    Files.createDirectories(modsDirectory);
                    if (!Desktop.isDesktopSupported()) throw new IOException("This computer does not support opening folders from V-Client.");
                    Desktop.getDesktop().open(modsDirectory.toFile());
                } catch (IOException | UnsupportedOperationException e) {
                    showNotice(ModsUi.warningBox("Couldn't open the mods folder", e.getMessage(), null));
                }
            });
            HBox header = new HBox(10, ModsUi.sectionTitle("Installed mods"), installedCount, spacer, refresh, openFolder);
            header.setAlignment(Pos.CENTER_LEFT);
            Label path = ModsUi.text(modsDirectory.toString(), 10, "#6f9bb5", false);
            path.setWrapText(true);
            card.getChildren().addAll(header, path, installedBody);
            return card;
        }

        private ListCell<MinecraftLauncher.InstalledVersion> profileCell() {
            return new ListCell<>() {
                @Override
                protected void updateItem(MinecraftLauncher.InstalledVersion version, boolean empty) {
                    super.updateItem(version, empty);
                    setText(empty || version == null ? null : version.displayName());
                    setStyle("-fx-text-fill: #f5f7fd; -fx-font-size: 13px; -fx-background-color: transparent;");
                }
            };
        }

        private Button secondaryButton(String label) {
            Button button = new Button(label);
            button.setMinHeight(34);
            button.setStyle("-fx-background-color: rgba(255,255,255,0.08); -fx-text-fill: #f5f7fd; -fx-font-size: 11px;"
                    + " -fx-font-weight: bold; -fx-background-radius: 10; -fx-padding: 0 14 0 14; -fx-cursor: hand;");
            return button;
        }

        void start() {
            loadInstalled();
            executor.execute(() -> {
                try {
                    List<MinecraftLauncher.InstalledVersion> found = gameLauncher.findVersions(settings.minecraftDirectory());
                    List<MinecraftLauncher.InstalledVersion> loaderProfiles = found.stream()
                            .filter(version -> !"Vanilla".equals(version.loader())).toList();
                    Platform.runLater(() -> {
                        installedVersions = found;
                        if (activePage != Page.MODS) return;
                        profilePicker.getItems().setAll(loaderProfiles);
                        if (loaderProfiles.isEmpty()) {
                            profilePicker.setPromptText("No mod-loader profiles");
                            showNotice(ModsUi.warningBox("No mod-loader profile installed",
                                    "Mods need a Fabric, Forge, NeoForge or Quilt profile. Install one in V-Client's game folder, then come back.",
                                    null));
                            return;
                        }
                        profilePicker.setValue(loaderProfiles.stream()
                                .filter(version -> version.id().equals(selectedVersionId))
                                .findFirst().orElse(loaderProfiles.getFirst()));
                    });
                } catch (Exception e) {
                    Platform.runLater(() -> showNotice(ModsUi.warningBox("Couldn't scan your profiles", e.getMessage(), null)));
                }
            });
        }

        // ---- notices and states ----------------------------------------------------------------------

        private void showNotice(javafx.scene.Node box) {
            notice.getChildren().setAll(box);
            notice.setManaged(true);
            notice.setVisible(true);
        }

        private void clearNotice() {
            notice.getChildren().clear();
            notice.setManaged(false);
            notice.setVisible(false);
        }

        private void showLoading(String message) {
            ModsUi.stop(animations);
            HBox busy = ModsUi.busyLabel(message);
            resultsCount.setVisible(false);
            resultsCount.setManaged(false);
            resultsBody.getChildren().setAll(busy, ModsUi.skeleton(3, animations));
        }

        private void showResults(List<ModrinthModService.ModProject> found, ModrinthModService.Target target) {
            ModsUi.stop(animations);
            current = found;
            resultsCount.setText(found.size() + (found.size() == 1 ? " mod" : " mods") + "  ·  " + target.loader()
                    + "  ·  " + target.gameVersion());
            resultsCount.setVisible(true);
            resultsCount.setManaged(true);
            if (found.isEmpty()) {
                resultsBody.getChildren().setAll(ModsUi.emptyCard("⌕", "No mods found",
                        "Nothing compatible with " + target.loader() + " on Minecraft " + target.gameVersion()
                                + (query.getText() == null || query.getText().isBlank() ? "" : " matches “" + query.getText().strip() + "”")
                                + ". Try another search or profile."));
                return;
            }
            renderCards();
        }

        private void renderCards() {
            flow = new javafx.scene.layout.FlowPane(12, 12);
            flow.setMaxWidth(Double.MAX_VALUE);
            for (ModrinthModService.ModProject project : current) {
                boolean installed = Files.isRegularFile(modsDirectory.resolve(project.fileName()));
                boolean downloading = modsDownloading.contains(project.fileName());
                Image icon = iconCache.computeIfAbsent(project.iconUrl(), url -> modIcon(url));
                flow.getChildren().add(ModsUi.modCard(project, icon, installed, downloading,
                        formatDownloads(project.downloads()), () -> install(project)));
            }
            resultsBody.getChildren().setAll(flow);
            layoutColumns();
        }

        private void layoutColumns() {
            if (flow == null) return;
            double available = resultsBody.getWidth() > 0 ? resultsBody.getWidth() : Math.max(300, content.getWidth() - 110);
            flow.setPrefWrapLength(available);
            ModsUi.applyColumns(flow, available);
        }

        private void showFailure(Exception error) {
            ModsUi.stop(animations);
            resultsCount.setVisible(false);
            resultsCount.setManaged(false);
            String[] message = ModsUi.describeFailure("Modrinth", error.getMessage());
            resultsBody.getChildren().setAll(ModsUi.warningBox(message[0], message[1], this::runSearch));
        }

        // ---- search ----------------------------------------------------------------------------------

        void runSearch() {
            if (settings.offlineMode()) {
                showNotice(ModsUi.warningBox("Offline mode is on",
                        "Modrinth is not contacted while offline mode is on. Turn it off on the Home page to browse and install mods.", null));
                return;
            }
            MinecraftLauncher.InstalledVersion profile = profilePicker.getValue();
            if (profile == null) {
                showNotice(ModsUi.warningBox("Choose a profile first",
                        "Install a Fabric, Forge, NeoForge or Quilt profile, then pick it in the list above.", null));
                return;
            }
            clearNotice();
            int mine = generation.incrementAndGet();
            search.setDisable(true);
            showLoading("Searching Modrinth…");
            Path minecraftDirectory = settings.minecraftDirectory();
            String text = query.getText() == null ? "" : query.getText();
            executor.execute(() -> {
                try {
                    ModrinthModService.Target target = ModrinthModService.resolveTarget(minecraftDirectory, profile);
                    List<ModrinthModService.ModProject> found = modrinthModService.search(text, target, message -> {
                        Platform.runLater(() -> appendLog(message));
                    });
                    Platform.runLater(() -> {
                        if (generation.get() == mine) showResults(found, target);
                    });
                } catch (Exception e) {
                    Platform.runLater(() -> {
                        if (generation.get() != mine) return;
                        showFailure(e);
                        appendLog("Modrinth search failed: " + e.getMessage());
                    });
                } finally {
                    Platform.runLater(() -> {
                        if (generation.get() == mine) search.setDisable(false);
                    });
                }
            });
        }

        // ---- install / installed list ------------------------------------------------------------------

        private void install(ModrinthModService.ModProject project) {
            if (settings.offlineMode()) {
                showNotice(ModsUi.warningBox("Offline mode is on", "Turn it off on the Home page to install mods.", null));
                return;
            }
            if (!modsDownloading.add(project.fileName())) return;
            clearNotice();
            renderCardsIfShown();
            appendLog("Installing mod " + project.title() + " (" + project.fileName() + ") into " + modsDirectory + ".");
            Path minecraftDirectory = modsDirectory.getParent();
            executor.execute(() -> {
                try {
                    Path installed = modrinthModService.install(project, minecraftDirectory,
                            message -> Platform.runLater(() -> appendLog(message)));
                    if (stats.unlock(PlayerStats.FIRST_MOD)) stats.save();
                    Platform.runLater(() -> {
                        appendLog("Installed mod " + installed + ".");
                        showNotice(successBox(project.title() + " installed"));
                    });
                } catch (Exception e) {
                    Platform.runLater(() -> {
                        appendLog("Mod install failed for " + project.title() + ": " + e.getMessage());
                        String[] message = ModsUi.describeFailure("Installing " + project.title(), e.getMessage());
                        showNotice(ModsUi.warningBox(message[0], message[1], null));
                    });
                } finally {
                    modsDownloading.remove(project.fileName());
                    Platform.runLater(() -> {
                        renderCardsIfShown();
                        loadInstalled();
                    });
                }
            });
        }

        private HBox successBox(String message) {
            Label icon = ModsUi.text("✓", 16, "#08140e", true);
            icon.setMinSize(30, 30);
            icon.setAlignment(Pos.CENTER);
            icon.setStyle(icon.getStyle() + " -fx-background-color: " + ModsUi.GOOD + "; -fx-background-radius: 15;");
            HBox box = new HBox(12, icon, ModsUi.text(message, 13, "#bff5d6", true));
            box.setAlignment(Pos.CENTER_LEFT);
            box.setPadding(new Insets(12, 16, 12, 14));
            box.setStyle("-fx-background-color: rgba(57,217,138,0.10); -fx-background-radius: 14;"
                    + " -fx-border-color: rgba(57,217,138,0.40); -fx-border-radius: 14;");
            return box;
        }

        private void renderCardsIfShown() {
            if (flow != null && !current.isEmpty() && resultsBody.getChildren().contains(flow)) renderCards();
        }

        void loadInstalled() {
            executor.execute(() -> {
                List<Path> mods = new ArrayList<>();
                String error = null;
                if (Files.isDirectory(modsDirectory)) {
                    try (var files = Files.list(modsDirectory)) {
                        files.filter(Files::isRegularFile)
                                .filter(file -> {
                                    String name = file.getFileName().toString().toLowerCase(java.util.Locale.ROOT);
                                    return name.endsWith(".jar") || name.endsWith(".jar.disabled");
                                })
                                .sorted(java.util.Comparator.comparing(file -> file.getFileName().toString().toLowerCase(java.util.Locale.ROOT)))
                                .forEach(mods::add);
                    } catch (IOException e) {
                        error = e.getMessage();
                    }
                }
                String scanError = error;
                Platform.runLater(() -> showInstalled(mods, scanError));
            });
        }

        private void showInstalled(List<Path> mods, String scanError) {
            installedCount.setText(String.valueOf(mods.size()));
            if (scanError != null) {
                installedBody.getChildren().setAll(ModsUi.warningBox("Couldn't read the mods folder", scanError, null));
                return;
            }
            if (mods.isEmpty()) {
                installedBody.getChildren().setAll(ModsUi.emptyCard("▣", "No mods installed yet",
                        Files.isDirectory(modsDirectory) ? "Install a mod from the results above."
                                : "The mods folder is created on your first install."));
                return;
            }
            List<javafx.scene.Node> rows = new ArrayList<>();
            for (Path file : mods) {
                String fileName = file.getFileName().toString();
                boolean disabled = fileName.toLowerCase(java.util.Locale.ROOT).endsWith(".disabled");
                Label name = ModsUi.text(fileName, 13, disabled ? ModsUi.MUTED : ModsUi.TEXT, true);
                name.setMinWidth(0);
                HBox.setHgrow(name, Priority.ALWAYS);
                name.setMaxWidth(Double.MAX_VALUE);
                Label state = ModsUi.chip(disabled ? "Disabled" : "Enabled", disabled ? "#6f9bb5" : ModsUi.GOOD);
                Button remove = new Button("REMOVE");
                remove.setMinHeight(32);
                remove.setStyle("-fx-background-color: rgba(255,99,120,0.14); -fx-text-fill: #ff9aa8; -fx-font-size: 10px;"
                        + " -fx-font-weight: bold; -fx-background-radius: 9; -fx-padding: 0 14 0 14; -fx-cursor: hand;");
                remove.setOnAction(event -> removeMod(file));
                HBox row = new HBox(12, name, state, remove);
                row.setAlignment(Pos.CENTER_LEFT);
                row.setPadding(new Insets(8, 12, 8, 14));
                String base = "-fx-background-color: rgba(255,255,255,0.045); -fx-background-radius: 12;";
                row.setStyle(base);
                row.setOnMouseEntered(event -> row.setStyle(base + " -fx-background-color: rgba(255,255,255,0.09);"));
                row.setOnMouseExited(event -> row.setStyle(base));
                rows.add(row);
            }
            installedBody.getChildren().setAll(rows);
        }

        private void removeMod(Path selected) {
            Path file = selected.toAbsolutePath().normalize();
            if (!modsDirectory.equals(file.getParent())) {
                showNotice(ModsUi.warningBox("Couldn't remove the mod", "That file is not inside V-Client's mods folder.", null));
                return;
            }
            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                    "Remove " + file.getFileName() + " from your mods folder?", ButtonType.OK, ButtonType.CANCEL);
            confirm.initOwner(stage);
            confirm.setTitle("V-Client");
            confirm.setHeaderText("Remove mod");
            if (confirm.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK) return;
            try {
                Files.deleteIfExists(file);
                appendLog("Removed mod " + file + ".");
            } catch (IOException e) {
                showNotice(ModsUi.warningBox("Couldn't remove the mod", e.getMessage(), null));
            }
            renderCardsIfShown();
            loadInstalled();
        }
    }

    private static Image modIcon(String iconUrl) {
        try {
            URI uri = URI.create(iconUrl);
            if (!"https".equalsIgnoreCase(uri.getScheme()) || !"cdn.modrinth.com".equalsIgnoreCase(uri.getHost())) return null;
            return new Image(uri.toString(), 112, 112, true, true, true);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private static String formatDownloads(long downloads) {
        if (downloads >= 1_000_000) return String.format(java.util.Locale.ROOT, "%.1fM", downloads / 1_000_000.0);
        if (downloads >= 1_000) return String.format(java.util.Locale.ROOT, "%.1fK", downloads / 1_000.0);
        return Long.toString(downloads);
    }

    private void showLogin() {
        activePage = Page.SETTINGS;
        settingsPage = true;
        updateNavigationState();
        StackPane root = baseLayout();
        VBox content = new VBox(20);
        content.setAlignment(Pos.CENTER);
        content.setPadding(new Insets(42, 72, 42, 72));
        Canvas logo = logo(72);
        Label heading = label("Choose an account", 30, "#f3f6fc");
        Label subtitle = label("Sign in to Minecraft or create an offline profile.", 14, MUTED);
        Button microsoftButton = button("MICROSOFT  ·  PREMIUM", ACCENT, 14);
        Button elyButton = button("ELY.BY", "#11263D", 14);
        Button offlineButton = button("OFFLINE ACCOUNT", "#11263D", 14);
        for (Button option : List.of(microsoftButton, elyButton, offlineButton)) {
            option.setMaxWidth(Double.MAX_VALUE);
            option.setPrefHeight(48);
        }
        microsoftButton.setOnAction(event -> signInMicrosoft());
        elyButton.setOnAction(event -> signInElyBy());
        offlineButton.setOnAction(event -> addOfflineAccount());
        VBox buttons = new VBox(11, microsoftButton, elyButton, offlineButton);
        if (!accounts.isEmpty()) {
            ComboBox<PlayerAccount> savedAccounts = new ComboBox<>();
            savedAccounts.getItems().setAll(accounts);
            savedAccounts.setButtonCell(accountCell());
            savedAccounts.setCellFactory(list -> accountCell());
            savedAccounts.setMaxWidth(Double.MAX_VALUE);
            savedAccounts.setValue(account);
            savedAccounts.setOnAction(event -> {
                if (savedAccounts.getValue() != null) selectAccount(savedAccounts.getValue());
            });
            content.getChildren().addAll(logo, heading, subtitle, savedAccounts, buttons);
        } else {
            content.getChildren().addAll(logo, heading, subtitle, buttons);
        }
        status = label("", 12, MUTED);
        content.getChildren().add(status);
        setPageContent(root, content);
        stage.setScene(new Scene(root, stage.getWidth(), stage.getHeight()));
    }

    private VBox buildAccountCard() {
        VBox accountCard = card();
        Label accountTitle = label("SAVED PLAYER ACCOUNTS", 11, MUTED);
        HBox accountRow = new HBox(12);
        accountRow.setAlignment(Pos.CENTER_LEFT);
        accountPicker = new ComboBox<>();
        accountPicker.getItems().setAll(accounts);
        accountPicker.setCellFactory(list -> accountCell());
        accountPicker.setButtonCell(accountCell());
        accountPicker.setPromptText("Add or select an account");
        accountPicker.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(accountPicker, Priority.ALWAYS);
        accountPicker.setValue(account);
        accountPicker.setOnAction(event -> {
            if (accountPicker.getValue() != null && accountPicker.getValue() != account) {
                selectAccount(accountPicker.getValue());
            }
        });
        Button removeAccount = button("REMOVE", "#482332", 10);
        removeAccount.setOnAction(event -> removeSelectedAccount());
        accountRow.getChildren().addAll(accountPicker, removeAccount);
        HBox addButtons = new HBox(9);
        addButtons.setAlignment(Pos.CENTER_LEFT);
        Button microsoftButton = button("+ MICROSOFT", ACCENT, 10);
        Button elyButton = button("+ ELY.BY", "#11263D", 10);
        Button offlineButton = button("+ OFFLINE", "#11263D", 10);
        microsoftButton.setOnAction(event -> signInMicrosoft());
        elyButton.setOnAction(event -> signInElyBy());
        offlineButton.setOnAction(event -> addOfflineAccount());
        addButtons.getChildren().addAll(microsoftButton, elyButton, offlineButton);

        HBox previews = new HBox(16);
        previews.setAlignment(Pos.CENTER_LEFT);
        ImageView skin = new ImageView();
        skin.setFitWidth(64);
        skin.setFitHeight(64);
        skin.setPreserveRatio(true);
        ImageView cape = new ImageView();
        cape.setFitWidth(40);
        cape.setFitHeight(64);
        cape.setPreserveRatio(true);
        Label previewsLabel = label("Skin and cape previews load for the selected account.", 12, MUTED);
        previews.getChildren().addAll(skin, cape, previewsLabel);
        accountLabel = label(account == null ? "Choose Microsoft, Ely.by, or an offline username."
                : account.name() + "  ·  " + account.type().label(), 13,
                account == null ? MUTED : "#f3f6fc");
        accountPicker.valueProperty().addListener((observable, oldAccount, newAccount) ->
                loadPreviews(newAccount, skin, cape, previewsLabel));
        loadPreviews(account, skin, cape, previewsLabel);
        accountCard.getChildren().addAll(accountTitle, accountRow, addButtons, accountLabel, previews);
        return accountCard;
    }

    private StackPane baseLayout() {
        StackPane root = new StackPane();
        root.setStyle("-fx-background-color: " + BACKGROUND + "; -fx-font-family: 'Segoe UI';");
        Canvas nightSky = new Canvas();
        nightSky.widthProperty().bind(root.widthProperty());
        nightSky.heightProperty().bind(root.heightProperty());
        nightSky.setMouseTransparent(true);
        root.getChildren().add(nightSky);
        if (backgroundAnimation != null) backgroundAnimation.stop();
        backgroundAnimation = new AnimationTimer() {
            @Override
            public void handle(long now) {
                if (now - lastBackgroundFrame < 33_000_000L) return;
                lastBackgroundFrame = now;
                drawNightSky(nightSky, now / 1_000_000_000.0);
            }
        };
        backgroundAnimation.start();
        BorderPane layout = new BorderPane();
        layout.setStyle("-fx-background-color: transparent; -fx-font-family: 'Segoe UI';");
        // Top bar: brand and QUICK PLAY on the left, the account chip on the right.
        HBox header = new HBox(14);
        header.setAlignment(Pos.CENTER_LEFT);
        header.setPadding(new Insets(10, 22, 10, 18));
        avatar = new ImageView(createIcon());
        avatar.setFitWidth(30);
        avatar.setFitHeight(30);
        avatar.setPreserveRatio(true);
        avatar.setClip(new Circle(15, 15, 15));
        if (account != null) loadAvatar(account, avatar);
        Canvas logo = logo(32);
        HBox quickPlay = new HBox(8);
        quickPlay.setAlignment(Pos.CENTER_LEFT);
        quickPlay.setPadding(new Insets(5, 10, 5, 12));
        quickPlay.setStyle("-fx-background-color: rgba(17, 38, 61, 0.85); -fx-background-radius: 12;"
                + " -fx-border-color: rgba(124, 235, 255, 0.25); -fx-border-radius: 12;");
        Label quickLabel = label("QUICK PLAY", 10, "#9fc6dc");
        quickLabel.setStyle(quickLabel.getStyle() + "-fx-font-weight: bold; -fx-letter-spacing: 1.5;");
        quickPlay.getChildren().add(quickLabel);
        for (ServerEntry entry : SERVER_LIST) {
            Button server = new Button(entry.name());
            server.setStyle("-fx-background-color: rgba(0, 207, 255, 0.14); -fx-text-fill: #eaf9ff; -fx-font-size: 11px;"
                    + " -fx-font-weight: bold; -fx-background-radius: 9; -fx-padding: 5 11 5 11; -fx-cursor: hand;");
            server.setTooltip(new javafx.scene.control.Tooltip("Launch and join " + entry.host()));
            server.setOnAction(event -> launchGame(entry));
            quickPlay.getChildren().add(server);
        }
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        headerAccountLabel = label(account == null ? "NO ACCOUNT" : account.name(), 12,
                account == null ? MUTED : "#eaf9ff");
        headerAccountLabel.setStyle(headerAccountLabel.getStyle() + "-fx-font-weight: bold;");
        HBox accountChip = new HBox(9, avatar, headerAccountLabel, dot(account == null ? "#64728a" : "#39d98a"));
        accountChip.setAlignment(Pos.CENTER_LEFT);
        accountChip.setPadding(new Insets(5, 14, 5, 6));
        accountChip.setCursor(javafx.scene.Cursor.HAND);
        accountChip.setStyle("-fx-background-color: rgba(0, 150, 200, 0.30); -fx-background-radius: 14;"
                + " -fx-border-color: rgba(124, 235, 255, 0.40); -fx-border-radius: 14;");
        accountChip.setOnMouseClicked(event -> showSettings());
        header.getChildren().addAll(logo, quickPlay, spacer, accountChip);
        header.setStyle("-fx-background-color: rgba(7, 19, 33, 0.78); -fx-border-color: transparent transparent rgba(124, 235, 255, 0.18) transparent;");
        layout.setTop(header);

        // Slim icon sidebar: main pages, "more" for the rest, Settings at the bottom. Names show as tooltips.
        VBox navigation = new VBox(6);
        navigation.setAlignment(Pos.TOP_CENTER);
        navigation.setPadding(new Insets(12, 6, 12, 6));
        navigation.setPrefWidth(66);
        navigation.setMinWidth(66);
        navigation.setStyle("-fx-background-color: rgba(7, 19, 33, 0.72); -fx-border-color: transparent rgba(124, 235, 255, 0.14) transparent transparent;");
        List<Page> mainPages = List.of(Page.HOME, Page.MODS, Page.COSMETICS, Page.BOOST, Page.RECORDINGS, Page.NEWS);
        List<Page> morePages = List.of(Page.SERVERS, Page.LIBRARY, Page.PACKS, Page.WARDROBE, Page.FRIENDS, Page.DISCORD,
                Page.PROFILE, Page.SCREENSHOTS, Page.FPS_TEST, Page.PERFORMANCE, Page.BROWSER, Page.ASSISTANT,
                Page.LOGS, Page.CONSOLE);
        navigationButtons.clear();
        for (Page page : mainPages) navigation.getChildren().add(navigationItem(page));
        Region navigationSpacer = new Region();
        VBox.setVgrow(navigationSpacer, Priority.ALWAYS);
        Button moreButton = new Button("⋯");
        moreButton.setMinSize(52, 42);
        moreButton.setPrefSize(52, 42);
        moreButton.setTooltip(new javafx.scene.control.Tooltip("More pages"));
        moreButton.setStyle("-fx-background-color: transparent; -fx-text-fill: #9fc6dc; -fx-font-size: 20px; -fx-cursor: hand;");
        javafx.scene.control.ContextMenu moreMenu = new javafx.scene.control.ContextMenu();
        for (Page page : morePages) {
            javafx.scene.control.MenuItem item = new javafx.scene.control.MenuItem(navigationText(page).replace("\n", "  "));
            item.setOnAction(event -> navigate(page));
            moreMenu.getItems().add(item);
        }
        moreButton.setOnAction(event -> moreMenu.show(moreButton, javafx.geometry.Side.RIGHT, 0, 0));
        navigation.getChildren().addAll(navigationSpacer, moreButton, navigationItem(Page.SETTINGS));
        layout.setMinSize(0, 0);
        layout.setLeft(navigation);
        updateNavigationState();
        root.getChildren().add(layout);
        return root;
    }

    private static Label navigationHeader(String title) {
        Label header = new Label(title);
        header.setMaxWidth(Double.MAX_VALUE);
        header.setAlignment(Pos.CENTER_LEFT);
        header.setPadding(new Insets(8, 0, 2, 8));
        header.setStyle("-fx-font-size: 9px; -fx-font-weight: bold; -fx-text-fill: #8f8fb8; -fx-letter-spacing: 1.5;");
        return header;
    }

    private Button navigationItem(Page page) {
        String[] parts = navigationText(page).split("\n", 2);
        Label glyph = new Label(parts[0]);
        glyph.setMinSize(32, 26);
        glyph.setPrefSize(32, 26);
        glyph.setMaxSize(32, 26);
        glyph.setAlignment(Pos.CENTER);
        VBox stack = new VBox(glyph);
        stack.setAlignment(Pos.CENTER);
        Button item = new Button();
        item.setGraphic(stack);
        item.setContentDisplay(javafx.scene.control.ContentDisplay.GRAPHIC_ONLY);
        item.setMinSize(52, 46);
        item.setPrefSize(52, 46);
        item.setMaxSize(52, 46);
        if (parts.length > 1) item.setTooltip(new javafx.scene.control.Tooltip(parts[1]));
        item.setOnAction(event -> navigate(page));
        item.setOnMouseEntered(event -> {
            hoveredPage = page;
            updateNavigationState();
        });
        item.setOnMouseExited(event -> {
            if (hoveredPage == page) hoveredPage = null;
            updateNavigationState();
        });
        navigationButtons.put(page, item);
        return item;
    }

    private void navigate(Page page) {
        switch (page) {
            case HOME -> showHome();
            case SERVERS -> showServers();
            case LIBRARY -> showLibrary();
            case MODS -> showMods();
            case BOOST -> showBoost();
            case BROWSER -> showFeaturePage(Page.BROWSER, "Web", "Browser",
                    "Browse the web with DNS lookups sent over HTTPS (Cloudflare DoH).", BrowserPage::build);
            case PACKS -> showFeaturePage(Page.PACKS, "One click", "Mod Packs",
                    "PvP, FPS, SMP and Builder packs, installed in one click.", PacksPage::build);
            case FPS_TEST -> showFeaturePage(Page.FPS_TEST, "FrostBoost", "❄ FPS Comparison",
                    "Before and after, diagnostics, and proof that your settings are really applied.", BenchmarkPage::build);
            case PERFORMANCE -> showFeaturePage(Page.PERFORMANCE, "Performance", "FPS & PC analysis",
                    "How the game runs on your PC, and what to change to make it run better.", PerformancePage::build);
            case RECORDINGS -> showFeaturePage(Page.RECORDINGS, "Capture", "❄ Frozen Memories",
                    "Videos recorded while Minecraft runs are imported here automatically.", RecordingsPage::build);
            case SCREENSHOTS -> showFeaturePage(Page.SCREENSHOTS, "Capture", "Screenshots",
                    "Your in-game screenshots, picked up automatically.", ScreenshotsPage::build);
            case PROFILE -> showFeaturePage(Page.PROFILE, "You", "Profile",
                    "Your playtime, achievements, daily rewards and music.", ProfilePage::build);
            case ASSISTANT -> showFeaturePage(Page.ASSISTANT, "Help", "VSMP Assistant",
                    "Fix launch errors, find crashes and free up disk space.", AssistantPage::build);
            case WARDROBE -> showWardrobe();
            case COSMETICS -> showCosmetics();
            case FRIENDS -> showFriends();
            case NEWS -> showNews();
            case LOGS -> showLogs();
            case CONSOLE -> showConsole();
            case SETTINGS -> showSettings();
            case DISCORD -> showDiscord();
        }
    }

    private void updateNavigationState() {
        navigationButtons.forEach((page, item) -> {
            boolean selected = page == activePage;
            boolean hovered = page == hoveredPage;
            String color = selected ? ACCENT : hovered ? "#f5f7fd" : "#9fc6dc";
            item.setStyle("-fx-background-color: " + (selected ? Theme.accentRgba(0.17)
                    : hovered ? "rgba(255, 255, 255, 0.07)" : "transparent")
                    + "; -fx-background-radius: 14; -fx-border-radius: 14; -fx-padding: 0; -fx-cursor: hand;"
                    + " -fx-border-color: " + (selected ? Theme.accentRgba(0.55) : "transparent") + "; -fx-border-width: 1;");
            if (item.getGraphic() instanceof VBox stack && !stack.getChildren().isEmpty()) {
                stack.getChildren().get(0).setStyle("-fx-font-size: 20px; -fx-font-family: 'Segoe UI Symbol', 'Segoe UI';"
                        + " -fx-text-fill: " + color + ";");
            }
        });
    }

    private static String navigationText(Page page) {
        return switch (page) {
            case HOME -> "⌂\nHome";
            case SERVERS -> "☰\nServers";
            case LIBRARY -> "▤\nLibrary";
            case MODS -> "✚\nMods";
            case BOOST -> "❄\nFrost";
            case BROWSER -> "◎\nBrowser";
            case PACKS -> "▦\nPacks";
            case FPS_TEST -> "⇄\nCompare";
            case PERFORMANCE -> "◔\nFPS";
            case PROFILE -> "☺\nProfile";
            case RECORDINGS -> "❄\nMemories";
            case SCREENSHOTS -> "▣\nShots";
            case ASSISTANT -> "?\nHelp";
            case WARDROBE -> "♧\nWardrobe";
            case COSMETICS -> "✦\nCosmetics";
            case FRIENDS -> "♟\nFriends";
            case NEWS -> "✉\nNews";
            case LOGS -> "⚠\nLogs";
            case CONSOLE -> ">_\nConsole";
            case SETTINGS -> "⚙\nSettings";
            case DISCORD -> "◉\nDiscord";
        };
    }

    private static void setPageContent(StackPane root, javafx.scene.Node content) {
        BorderPane layout = (BorderPane) root.getChildren().get(1);
        ScrollPane scroll = new ScrollPane(content);
        scroll.setFitToWidth(true);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroll.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        layout.setCenter(scroll);
    }

    private void refreshVersions() {
        refreshVersions("");
    }

    private void refreshVersions(String selectId) {
        if (versionPicker == null) return;
        versionPicker.setDisable(true);
        if (refreshVersionsButton != null) refreshVersionsButton.setDisable(true);
        boolean offline = settings.offlineMode();
        versionPicker.setPromptText(offline ? "Scanning installed versions..." : "Fetching Mojang versions...");
        Path directory = settings.minecraftDirectory();
        executor.execute(() -> {
            List<MinecraftLauncher.InstalledVersion> versions;
            try {
                try {
                    VClientModInstaller.ensureInstalled(directory,
                            line -> Platform.runLater(() -> appendLog(line)));
                } catch (IOException e) {
                    Platform.runLater(() -> appendLog("Could not install the V-Client mod profile: " + e.getMessage()));
                }
                try {
                    BundledResourcePack.ensureInstalled(directory,
                            line -> Platform.runLater(() -> appendLog(line)));
                } catch (IOException e) {
                    Platform.runLater(() -> appendLog("Could not install the bundled resource pack: " + e.getMessage()));
                }
                versions = gameLauncher.findVersions(directory);
            } catch (Exception e) {
                Platform.runLater(() -> {
                    if (refreshVersionsButton != null) refreshVersionsButton.setDisable(false);
                    if (versionPicker != null) versionPicker.setDisable(false);
                    versionStatusLabel.setText("Could not scan installed versions.");
                    reportProblem(e);
                });
                return;
            }
            if (offline) {
                Platform.runLater(() -> showInstalledVersionsOnly(versions, selectId, directory,
                        "Offline mode · nothing is contacted"));
                return;
            }
            try {
                MinecraftLauncher.VersionCatalog catalog = gameLauncher.fetchVersionCatalog(
                        line -> Platform.runLater(() -> appendLog(line)));
                Platform.runLater(() -> {
                    installedVersions = versions;
                    versionCatalog = catalog;
                    if (settingsPage || versionPicker == null) return;
                    versionPicker.getItems().setAll(buildVersionChoices(catalog, versions));
                    versionPicker.setDisable(false);
                    versionPicker.setPromptText("Choose a Mojang release or installed profile");
                    if (refreshVersionsButton != null) refreshVersionsButton.setDisable(false);
                    VersionChoice chosen = versionPicker.getItems().stream()
                            .filter(choice -> choice.id().equals(selectId))
                            .filter(VersionChoice::preferredEntry).findFirst()
                            .orElseGet(() -> defaultVersionChoice(catalog, versions));
                    if (chosen != null) {
                        versionPicker.getSelectionModel().select(chosen);
                        selectedVersionId = chosen.id();
                    }
                    versionStatusLabel.setText("Mojang versions: " + catalog.versions().size()
                            + " · Installed profiles: " + versions.size());
                    updateInstallButton();
                    updateReadiness();
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    appendLog("Mojang version list unavailable (" + e.getMessage()
                            + "); showing installed versions only.");
                    showInstalledVersionsOnly(versions, selectId, directory,
                            "Mojang unreachable · showing installed versions · turn on Offline mode to stop connecting");
                });
            }
        });
    }

    private void showInstalledVersionsOnly(List<MinecraftLauncher.InstalledVersion> versions, String selectId,
                                           Path directory, String reason) {
        installedVersions = versions;
        versionCatalog = null;
        if (settingsPage || versionPicker == null) return;
        if (refreshVersionsButton != null) refreshVersionsButton.setDisable(false);
        List<VersionChoice> choices = versions.stream()
                .map(profile -> new VersionChoice(profile.id(), profile.displayName(), "Installed",
                        null, profile, true))
                .toList();
        versionPicker.getItems().setAll(choices);
        versionPicker.setDisable(false);
        versionPicker.setPromptText(choices.isEmpty() ? "No installed versions found" : "Choose an installed version");
        MinecraftLauncher.InstalledVersion preferred = MinecraftLauncher.preferredInstalledVersion(versions);
        VersionChoice chosen = choices.stream().filter(choice -> choice.id().equals(selectId)).findFirst()
                .orElseGet(() -> choices.stream()
                        .filter(choice -> preferred != null && choice.id().equals(preferred.id()))
                        .findFirst().orElse(choices.isEmpty() ? null : choices.getFirst()));
        if (chosen != null) {
            versionPicker.getSelectionModel().select(chosen);
            selectedVersionId = chosen.id();
        }
        versionStatusLabel.setText(reason + " · Installed profiles: " + versions.size());
        updateInstallButton();
        updateReadiness();
    }

    private List<VersionChoice> buildVersionChoices(MinecraftLauncher.VersionCatalog catalog,
                                                   List<MinecraftLauncher.InstalledVersion> installed) {
        List<VersionChoice> choices = new ArrayList<>();
        MinecraftLauncher.AvailableVersion latestRelease = findAvailable(catalog, catalog.latestReleaseId());
        MinecraftLauncher.AvailableVersion latestSnapshot = findAvailable(catalog, catalog.latestSnapshotId());
        if (latestRelease != null) {
            choices.add(versionChoice(latestRelease, installed, "Latest Release — " + latestRelease.id(), true));
        }
        if (latestSnapshot != null) {
            choices.add(versionChoice(latestSnapshot, installed, "Latest Snapshot — " + latestSnapshot.id(), true));
        }
        for (MinecraftLauncher.AvailableVersion available : catalog.versions()) {
            if (available.id().equals(catalog.latestReleaseId())
                    || available.id().equals(catalog.latestSnapshotId())) continue;
            choices.add(versionChoice(available, installed, available.id(), false));
        }
        for (MinecraftLauncher.InstalledVersion profile : installed) {
            boolean listed = choices.stream().anyMatch(choice -> choice.id().equals(profile.id()));
            if (!listed) {
                choices.add(new VersionChoice(profile.id(), profile.displayName(), "Installed",
                        null, profile, true));
            }
        }
        return List.copyOf(choices);
    }

    private static MinecraftLauncher.AvailableVersion findAvailable(
            MinecraftLauncher.VersionCatalog catalog, String id) {
        return catalog.versions().stream().filter(version -> version.id().equals(id))
                .findFirst().orElse(null);
    }

    private VersionChoice versionChoice(MinecraftLauncher.AvailableVersion available,
                                        List<MinecraftLauncher.InstalledVersion> installed,
                                        String label, boolean preferredEntry) {
        MinecraftLauncher.InstalledVersion profile = installed.stream()
                .filter(version -> version.id().equals(available.id())).findFirst().orElse(null);
        String status = versionsDownloading.contains(available.id()) ? "Downloading"
                : profile == null ? "Not Installed" : "Installed";
        return new VersionChoice(available.id(), label,
                status,
                available, profile, preferredEntry);
    }

    private VersionChoice defaultVersionChoice(MinecraftLauncher.VersionCatalog catalog,
                                               List<MinecraftLauncher.InstalledVersion> installed) {
        MinecraftLauncher.InstalledVersion preferred = MinecraftLauncher.preferredInstalledVersion(installed);
        String defaultId = preferred == null ? catalog.latestReleaseId() : preferred.id();
        return versionPicker.getItems().stream().filter(choice -> choice.id().equals(defaultId))
                .filter(VersionChoice::preferredEntry).findFirst()
                .orElseGet(() -> versionPicker.getItems().stream().findFirst().orElse(null));
    }

    private void installSelectedVersion() {
        VersionChoice selected = versionPicker == null ? null : versionPicker.getValue();
        if (selected == null) {
            showError("Select a Minecraft version", new IOException("Choose a version before installing."));
            return;
        }
        if (selected.available() == null) {
            versionStatusLabel.setText(selected.id() + " is an installed mod-loader profile.");
            return;
        }
        downloadSelectedVersion(selected);
    }

    private void downloadSelectedVersion(VersionChoice selected) {
        if (selected.available() == null || !versionsDownloading.add(selected.id())) return;
        if (versionPicker != null && versionCatalog != null) {
            List<VersionChoice> downloadingChoices = buildVersionChoices(versionCatalog, installedVersions);
            versionPicker.getItems().setAll(downloadingChoices);
            downloadingChoices.stream().filter(choice -> choice.id().equals(selected.id()))
                    .filter(VersionChoice::preferredEntry).findFirst()
                    .ifPresent(choice -> versionPicker.getSelectionModel().select(choice));
        }
        if (versionStatusLabel != null) {
            versionStatusLabel.setText("Downloading " + selected.id() + "…");
        }
        if (playButton != null) playButton.setDisable(true);
        if (singleplayerButton != null) singleplayerButton.setDisable(true);
        if (versionPicker != null) versionPicker.setDisable(true);
        if (installVersionButton != null) installVersionButton.setDisable(true);
        if (refreshVersionsButton != null) refreshVersionsButton.setDisable(true);
        updateReadiness();
        // Progress bar with download speed and ETA: bytes come from the downloader, file counts from its progress lines.
        DownloadStats downloadStats = new DownloadStats();
        downloadStats.start();
        javafx.animation.Timeline progressTicker = new javafx.animation.Timeline(new javafx.animation.KeyFrame(
                javafx.util.Duration.millis(500), event -> {
            downloadStats.sample();
            showInstallProgress(selected.id(), downloadStats);
        }));
        progressTicker.setCycleCount(javafx.animation.Animation.INDEFINITE);
        progressTicker.play();
        showInstallProgress(selected.id(), downloadStats);
        appendLog("Downloading Minecraft " + selected.id() + " and preparing its libraries, assets, and Java runtime.");
        executor.execute(() -> {
            try {
                MinecraftLauncher.InstalledVersion installed = gameLauncher.installVersion(
                        settings.minecraftDirectory(), selected.available(),
                        line -> {
                            downloadStats.accept(line);
                            Platform.runLater(() -> appendLog(line));
                        });
                List<MinecraftLauncher.InstalledVersion> profiles =
                        gameLauncher.findVersions(settings.minecraftDirectory());
                Platform.runLater(() -> {
                    installedVersions = profiles;
                    if (versionCatalog != null && versionPicker != null) {
                        versionPicker.getItems().setAll(buildVersionChoices(versionCatalog, profiles));
                        VersionChoice completed = versionPicker.getItems().stream()
                                .filter(choice -> choice.id().equals(installed.id()))
                                .filter(VersionChoice::preferredEntry).findFirst().orElse(null);
                        if (completed != null) versionPicker.getSelectionModel().select(completed);
                    }
                    versionStatusLabel.setText(installed.id()
                            + " · Installed · libraries, assets, and Java are ready.");
                    appendLog("Minecraft " + installed.id() + " installation completed.");
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    versionStatusLabel.setText(selected.id() + " · Not Installed · " + FriendlyError.of(e).title());
                    appendLog("Minecraft " + selected.id() + " installation failed: " + e.getMessage());
                    reportProblem(e);
                });
            } finally {
                versionsDownloading.remove(selected.id());
                Platform.runLater(() -> {
                    progressTicker.stop();
                    hideInstallProgress();
                    if (versionPicker != null) versionPicker.setDisable(false);
                    updateInstallButton();
                    updateReadiness();
                    if (refreshVersionsButton != null) refreshVersionsButton.setDisable(false);
                    if (playButton != null) playButton.setDisable(false);
                    if (singleplayerButton != null) singleplayerButton.setDisable(false);
                    if (versionCatalog != null && versionPicker != null) {
                        VersionChoice current = versionPicker.getValue();
                        versionPicker.getItems().setAll(buildVersionChoices(versionCatalog, installedVersions));
                        if (current != null) versionPicker.getSelectionModel().select(
                                versionPicker.getItems().stream().filter(choice -> choice.id().equals(current.id()))
                                        .filter(VersionChoice::preferredEntry).findFirst().orElse(null));
                    }
                });
            }
        });
    }

    private void showInstallProgress(String versionId, DownloadStats stats) {
        if (installProgress == null || !(installProgress.getUserData() instanceof VBox box)) return;
        box.setVisible(true);
        double fraction = stats.fraction();
        installProgress.setProgress(fraction < 0 ? javafx.scene.control.ProgressIndicator.INDETERMINATE_PROGRESS : fraction);
        installProgressLabel.setText("Installing " + versionId + "  ·  " + stats.describe());
    }

    private void hideInstallProgress() {
        if (installProgress != null && installProgress.getUserData() instanceof VBox box) box.setVisible(false);
    }

    /** Starts the selected version; with a {@code server} it connects straight to that server. */
    private void launchGame(ServerEntry server) {
        boolean joinSmp = server != null;
        if (account == null) {
            showLogin();
            return;
        }
        VersionChoice choice = versionPicker == null ? null : versionPicker.getValue();
        if (choice == null && versionCatalog != null) {
            MinecraftLauncher.AvailableVersion latest = findAvailable(
                    versionCatalog, versionCatalog.latestReleaseId());
            if (latest != null) {
                downloadSelectedVersion(new VersionChoice(latest.id(), "Latest Release — " + latest.id(),
                        "Not Installed", latest, null, true));
                return;
            }
        }
        if (choice == null || choice.installed() == null) {
            if (versionStatusLabel != null) {
                versionStatusLabel.setText(choice == null
                        ? (versionCatalog == null
                        ? "No installed versions found. Turn off Offline mode once to download one, or import game files in Settings."
                        : "Refresh the Mojang version catalog before playing.")
                        : choice.id() + " is downloading. Wait for installation to finish.");
            }
            return;
        }
        MinecraftLauncher.InstalledVersion selected = choice.installed();
        PlayerAccount selectedAccount = account;
        long launchedAt = System.currentTimeMillis();
        lastError = null;
        lastProblem = "";
        renderProblem();
        reportEventAsync(joinSmp ? "join" : "play");
        recordPlayerAsync(selectedAccount);
        boolean offline = settings.offlineMode();
        Button launchingButton = joinSmp ? singleplayerButton : playButton;
        playButton.setDisable(true);
        playButton.setText(joinSmp ? "▶    LAUNCH" : "STARTING...");
        if (singleplayerButton != null) singleplayerButton.setDisable(true);
        if (joinSmp && launchingButton != null) {
            launchingButton.setText("CONNECTING...");
        }
        appendLog((joinSmp ? "Preparing a launch for " + server.name() + " (" + server.host() + ":" + server.port() + ") with "
                : "Starting Minecraft from V-Client's private folder ")
                + selected.displayName()
                + " for " + selectedAccount.name() + " (" + selectedAccount.type().label() + ")...");
        setPresence("Playing Minecraft", joinSmp ? server.name() : "");
        // With the VPN on, join through its local forwarding port instead of the server's own address.
        Integer vpnPort = joinSmp ? VpnManager.route(server.host(), server.port()) : null;
        String vpnHost = vpnPort != null ? "127.0.0.1" : joinSmp ? server.host() : "";
        int vpnJoinPort = vpnPort != null ? vpnPort : joinSmp ? server.port() : 0;
        if (vpnPort != null) appendLog("VPN is on: joining " + server.name() + " through the tunnel.");
        executor.execute(() -> {
            try {
                Consumer<String> output = line -> Platform.runLater(() -> appendLog(line));
                // Make sure the game starts with the launcher's own V-Client mod, not a copy left by an older run.
                try {
                    VClientModInstaller.ensureInstalled(settings.minecraftDirectory(), output);
                } catch (IOException e) {
                    output.accept("Could not refresh the V-Client mod before launching (is the game already open?): " + e.getMessage());
                }
                if (settings.replayBufferEnabled()) {
                    try {
                        if (GameOptionsFix.keepRunningWhenUnfocused(settings.minecraftDirectory())) {
                            output.accept("Turned off \"pause on lost focus\" so saving a clip cannot open the pause menu.");
                        }
                    } catch (IOException e) {
                        output.accept("Could not update options.txt: " + e.getMessage());
                    }
                }
                String joinHost = vpnHost;
                int joinPort = vpnJoinPort;
                boolean viaVpn = vpnPort != null;
                if (viaVpn && !ServerPinger.ping("127.0.0.1", vpnPort, false).online()) {
                    // The tunnel is up as a process but never completed its handshake (the network blocks it), so
                    // joining through it would just time out. Join directly instead.
                    output.accept("The VPN tunnel is not carrying traffic (the network is probably blocking it); joining "
                            + server.name() + " directly instead. Turn the VPN off in Settings if this keeps happening.");
                    viaVpn = false;
                    joinHost = server.host();
                    joinPort = server.port();
                }
                // A DNS filter that blocks the server's name is handled when the game starts: its secure-DNS helper looks
                // the name up itself (keeping the hostname, which some hosts need), or the launcher joins on the real address.
                MinecraftLauncher.InstalledVersion launchVersion = selected;
                if (offline) {
                    if (!joinSmp) {
                        gameLauncher.launchSingleplayerLocal(settings.minecraftDirectory(), launchVersion,
                                settings.memoryGb(), selectedAccount, output);
                    } else {
                        gameLauncher.launchToServerLocally(settings.minecraftDirectory(), launchVersion,
                                settings.memoryGb(), selectedAccount, joinHost, joinPort, output);
                    }
                } else if (!joinSmp) {
                    gameLauncher.launchSingleplayer(settings.minecraftDirectory(), launchVersion,
                            settings.memoryGb(), selectedAccount, output);
                } else {
                    gameLauncher.launchToServer(settings.minecraftDirectory(), launchVersion, settings.memoryGb(),
                            selectedAccount, joinHost, joinPort, output);
                }
            } catch (Exception e) {
                Platform.runLater(() -> {
                    appendLog("Launch failed: " + e.getMessage());
                    showLaunchFailure(e, settings.minecraftDirectory(), launchedAt);
                });
            } finally {
                setPresence("In the launcher", "");
                Platform.runLater(() -> {
                    if (playButton != null) {
                        playButton.setDisable(false);
                        playButton.setText("▶    LAUNCH");
                    }
                    if (singleplayerButton != null) {
                        singleplayerButton.setDisable(false);
                        singleplayerButton.setText(smpButtonText);
                    }
                    updateReadiness();
                });
            }
        });
    }

    private record ElyCredentials(String username, char[] password) {}

    private void signInMicrosoft() {
        MicrosoftAuthService service = authService;
        CompletableFuture<PlayerAccount> signIn = service.signIn(executor, device -> Platform.runLater(() -> {
            if (status != null) status.setText("Enter the sign-in code on " + device.url() + ".");
            try {
                if (Desktop.isDesktopSupported()) Desktop.getDesktop().browse(URI.create(device.url()));
            } catch (IOException e) {
                if (status != null) status.setText("Open " + device.url() + " and enter code " + device.code());
            }
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initOwner(stage);
            alert.setTitle("Microsoft sign-in");
            alert.setHeaderText("Sign in to your Premium account");
            alert.setContentText("Open " + device.url() + " and enter this code:\n\n" + device.code());
            alert.show();
        }));
        showSignInProgress("Waiting for Microsoft account authorization...");
        signIn.whenComplete((signedIn, error) -> Platform.runLater(() -> {
            if (error != null) {
                showSignInError("Microsoft sign-in failed", error);
                return;
            }
            addAccount(signedIn);
        }));
    }

    private void signInElyBy() {
        Dialog<ElyCredentials> dialog = new Dialog<>();
        dialog.initOwner(stage);
        dialog.setTitle("Sign in to Ely.by");
        dialog.setHeaderText("Use your Ely.by account credentials.");
        ButtonType loginType = new ButtonType("SIGN IN", javafx.scene.control.ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(loginType, ButtonType.CANCEL);
        TextField username = new TextField();
        username.setPromptText("Ely.by username or email");
        PasswordField password = new PasswordField();
        password.setPromptText("Password");
        GridPane fields = new GridPane();
        fields.setHgap(10);
        fields.setVgap(12);
        fields.add(label("Username", 12, MUTED), 0, 0);
        fields.add(username, 1, 0);
        fields.add(label("Password", 12, MUTED), 0, 1);
        fields.add(password, 1, 1);
        Label note = label("Your password is used for sign-in and is never saved.", 11, MUTED);
        fields.add(note, 0, 2, 2, 1);
        dialog.getDialogPane().setContent(fields);
        dialog.setResultConverter(button -> button == loginType
                ? new ElyCredentials(username.getText(), password.getText().toCharArray()) : null);
        ElyCredentials credentials = dialog.showAndWait().orElse(null);
        if (credentials == null) return;
        showSignInProgress("Contacting Ely.by to verify your account (12-second timeout)...");
        attemptElyByLogin(credentials.username(), credentials.password(), false);
    }

    private void attemptElyByLogin(String username, char[] password, boolean retriedWithTotp) {
        elyByAuthService.signIn(username, password, executor, message -> Platform.runLater(() -> {
            if (status != null) status.setText(message);
            appendLog(message);
        })).whenComplete((signedIn, error) ->
                Platform.runLater(() -> {
                    if (error == null) {
                        java.util.Arrays.fill(password, '\0');
                        addAccount(signedIn);
                        return;
                    }
                    Throwable cause = unwrap(error);
                    String message = cause.getMessage() == null ? "" : cause.getMessage();
                    if (!retriedWithTotp && message.toLowerCase(java.util.Locale.ROOT).contains("two factor auth")) {
                        TextInputDialog totp = new TextInputDialog();
                        totp.initOwner(stage);
                        totp.setTitle("Ely.by two-factor verification");
                        totp.setHeaderText("This Ely.by account requires an authenticator code.");
                        totp.setContentText("Six-digit verification code:");
                        String code = totp.showAndWait().orElse("");
                        if (code.matches("\\d{6,8}")) {
                            char[] totpPassword = java.util.Arrays.copyOf(password,
                                    password.length + code.length() + 1);
                            totpPassword[password.length] = ':';
                            code.getChars(0, code.length(), totpPassword, password.length + 1);
                            java.util.Arrays.fill(password, '\0');
                            attemptElyByLogin(username, totpPassword, true);
                        } else {
                            java.util.Arrays.fill(password, '\0');
                            showError("Invalid verification code",
                                    new IOException("Enter the current 6–8 digit authenticator code."));
                        }
                    } else {
                        java.util.Arrays.fill(password, '\0');
                        showSignInError("Ely.by sign-in failed", cause);
                    }
                }));
    }

    private void addOfflineAccount() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.initOwner(stage);
        dialog.setTitle("Add offline account");
        dialog.setHeaderText("Choose a Minecraft username for offline play.");
        dialog.setContentText("Username (3–16 letters, numbers, or underscores):");
        dialog.showAndWait().ifPresent(username -> {
            try {
                addAccount(PlayerAccount.offline(username));
            } catch (IllegalArgumentException e) {
                showError("Invalid Minecraft username", e);
            }
        });
    }

    private void addAccount(PlayerAccount added) {
        if (accountPersistenceInProgress || protectedAccountSavePending) {
            showError("Account change in progress",
                    new IOException("Wait for the current account update to finish. The account is already "
                            + "signed in and available for this session."));
            return;
        }
        List<PlayerAccount> updated = new ArrayList<>(accounts);
        int existing = -1;
        for (int index = 0; index < updated.size(); index++) {
            if (updated.get(index).id().equals(added.id())) {
                existing = index;
                break;
            }
        }
        if (existing >= 0) updated.set(existing, added);
        else updated.add(added);
        if (added.type() != PlayerAccount.Type.OFFLINE) {
            persistNewProtectedAccount(updated, added);
            return;
        }
        persistAccounts(updated, () -> {
            account = added;
            settings.setLastAccountId(added.id());
            saveSettings();
            updateAccountControls();
            showHome();
            if (added.type() == PlayerAccount.Type.ELY_BY) loadElyByTextures(added);
        }, "Could not save account", added.type() == PlayerAccount.Type.OFFLINE);
    }

    private void persistNewProtectedAccount(List<PlayerAccount> updated, PlayerAccount added) {
        accountPersistenceInProgress = true;
        protectedAccountSavePending = true;
        accounts.clear();
        accounts.addAll(updated);
        account = added;
        settings.setLastAccountId(added.id());
        saveSettings();
        updateAccountControls();
        showHome();
        appendLog("Signed in as " + added.name() + ". Saving account credentials securely in the background...");
        AtomicBoolean timeoutReported = new AtomicBoolean();
        CompletableFuture<Void> save = CompletableFuture.runAsync(() -> {
            try {
                accountStore.saveProtectedAccounts(updated, message ->
                        Platform.runLater(() -> appendLog(message)));
            } catch (IOException e) {
                throw new java.util.concurrent.CompletionException(e);
            }
        }, executor);
        CompletableFuture.delayedExecutor(15, TimeUnit.SECONDS).execute(() -> {
            if (!save.isDone() && timeoutReported.compareAndSet(false, true)) {
                Platform.runLater(() -> {
                    accountPersistenceInProgress = false;
                    String message = "Windows secure storage has not responded after 15 seconds. "
                            + "Sign-in succeeded and the account works for this session, but saving "
                            + "has not been confirmed. Do not enter your password again.";
                    appendLog(message);
                    if (status != null) status.setText(message);
                });
            }
        });
        save.whenComplete((ignored, error) -> Platform.runLater(() -> {
            accountPersistenceInProgress = false;
            protectedAccountSavePending = false;
            if (error != null) {
                String message = "Sign-in succeeded, but the account could not be saved securely: "
                        + unwrap(error).getMessage();
                appendLog(message);
                showError("Account is signed in but not saved", new IOException(message, unwrap(error)));
                return;
            }
            appendLog(timeoutReported.get()
                    ? "Windows secure storage responded late; the account is now saved."
                    : "Account saved securely.");
            if (added.type() == PlayerAccount.Type.ELY_BY) loadElyByTextures(added);
        }));
    }

    private void loadElyByTextures(PlayerAccount signedIn) {
        appendLog("Ely.by profile: loading skin and cape for " + signedIn.name() + " in the background...");
        CompletableFuture.supplyAsync(() -> {
            try {
                return elyByAuthService.loadTextures(signedIn,
                        line -> Platform.runLater(() -> appendLog(line)));
            } catch (IOException | InterruptedException e) {
                if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                throw new java.util.concurrent.CompletionException(e);
            }
        }, executor).whenComplete((profile, error) -> Platform.runLater(() -> {
            if (error != null) {
                appendLog("Ely.by is signed in, but its optional skin/cape lookup failed: "
                        + unwrap(error).getMessage());
                return;
            }
            if (profile.skinUrl().isBlank() && profile.capeUrl().isBlank()) {
                appendLog("Ely.by is signed in. No skin or cape is currently equipped.");
                return;
            }
            int savedIndex = -1;
            for (int index = 0; index < accounts.size(); index++) {
                if (accounts.get(index).id().equals(profile.id())) {
                    savedIndex = index;
                    break;
                }
            }
            if (savedIndex < 0) return;
            PlayerAccount saved = accounts.get(savedIndex);
            if (saved.skinUrl().equals(profile.skinUrl()) && saved.capeUrl().equals(profile.capeUrl())) {
                appendLog("Ely.by skin is up to date.");
                if (account != null && account.id().equals(profile.id()) && avatar != null) loadAvatar(account, avatar);
                return;
            }
            if (accountPersistenceInProgress) {
                appendLog("The Ely.by skin/cape loaded, but another account update is in progress; "
                        + "the profile preview will update next time you sign in.");
                return;
            }
            List<PlayerAccount> updated = new ArrayList<>(accounts);
            updated.set(savedIndex, profile);
            persistAccounts(updated, () -> {
                if (account != null && account.id().equals(profile.id())) {
                    account = profile;
                    if (avatar != null) loadAvatar(profile, avatar);
                }
                updateAccountControls();
                appendLog("Ely.by skin and cape profile loaded.");
            }, "Could not save Ely.by skin and cape data", false);
        }));
    }

    private void selectAccount(PlayerAccount selected) {
        account = selected;
        settings.setLastAccountId(selected.id());
        saveSettings();
        updateAccountControls();
        if (headerAccountLabel != null) {
            headerAccountLabel.setText(selected.name().toUpperCase()
                    + "  ·  " + selected.type().label().toUpperCase());
            headerAccountLabel.setTextFill(Color.web(ACCENT));
        }
        if (avatar != null) loadAvatar(selected, avatar);
        if (status != null) status.setText(selected.name() + " selected. Type: " + selected.type().label() + ".");
        if (selected.type() == PlayerAccount.Type.ELY_BY && !settings.offlineMode()) loadElyByTextures(selected);
    }

    private void updateAccountControls() {
        if (accountPicker != null) {
            accountPicker.getItems().setAll(accounts);
            accountPicker.setValue(account);
        }
        if (accountLabel != null) {
            accountLabel.setText(account == null ? "Choose an account." : account.name()
                    + "  ·  " + account.type().label());
        }
    }

    private void removeSelectedAccount() {
        if (accountPersistenceInProgress || protectedAccountSavePending) {
            showError("Account change in progress",
                    new IOException("Wait for the current account update to finish. The account is already "
                            + "signed in and available for this session."));
            return;
        }
        PlayerAccount selected = accountPicker == null ? null : accountPicker.getValue();
        if (selected == null) {
            showError("No account selected", new IOException("Select the saved account you want to remove."));
            return;
        }
        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.initOwner(stage);
        confirmation.setTitle("Remove account");
        confirmation.setHeaderText("Remove " + selected.name() + "?");
        confirmation.setContentText("The locally saved account token will be deleted.");
        if (confirmation.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK) return;
        List<PlayerAccount> updated = accounts.stream()
                .filter(saved -> !saved.id().equals(selected.id())).toList();
        persistAccounts(updated, () -> {
            if (account != null && account.id().equals(selected.id())) {
                account = accounts.isEmpty() ? null : accounts.getFirst();
            }
            settings.setLastAccountId(account == null ? "" : account.id());
            saveSettings();
            updateAccountControls();
            if (account == null) showLogin();
            else {
                if (headerAccountLabel != null) {
                    headerAccountLabel.setText(account.name().toUpperCase()
                            + "  ·  " + account.type().label().toUpperCase());
                }
                if (avatar != null) loadAvatar(account, avatar);
            }
        }, "Could not remove saved account", selected.type() == PlayerAccount.Type.OFFLINE);
    }

    private PlayerAccount refreshAccount(PlayerAccount selected) throws IOException, InterruptedException {
        return switch (selected.type()) {
            case MICROSOFT -> authService.refresh(selected);
            case ELY_BY -> elyByAuthService.refresh(selected);
            case OFFLINE -> selected;
        };
    }

    private void updateRefreshedAccount(String id, PlayerAccount refreshed) {
        if (protectedAccountSavePending) {
            appendLog("The account remains signed in for this session. Token refresh will not be saved "
                    + "until Windows secure storage responds.");
            return;
        }
        if (accountPersistenceInProgress) {
            if (status != null) status.setText(
                    "Could not save the refreshed sign-in because another account change is in progress.");
            return;
        }
        int savedIndex = -1;
        for (int index = 0; index < accounts.size(); index++) {
            if (accounts.get(index).id().equals(id)) {
                savedIndex = index;
                break;
            }
        }
        if (savedIndex < 0) return;
        List<PlayerAccount> updated = new ArrayList<>(accounts);
        updated.set(savedIndex, refreshed);
        persistAccounts(updated, () -> {
            if (account != null && account.id().equals(id)) {
                account = refreshed;
                if (headerAccountLabel != null) {
                    headerAccountLabel.setText(refreshed.name().toUpperCase()
                            + "  ·  " + refreshed.type().label().toUpperCase());
                }
                if (avatar != null) loadAvatar(refreshed, avatar);
                if (accountLabel != null) accountLabel.setText(refreshed.name()
                        + "  ·  " + refreshed.type().label());
            }
            updateAccountControls();
        }, "Could not securely save refreshed sign-in", false);
    }

    private void persistAccounts(List<PlayerAccount> updated, Runnable onSaved, String failureTitle,
                                 boolean offlineOnly) {
        if (protectedAccountSavePending && !offlineOnly) {
            appendLog("Account storage is still waiting for Windows secure storage; no second write was started.");
            return;
        }
        accountPersistenceInProgress = true;
        if (status != null) {
            status.setText(offlineOnly ? "Saving offline account locally..." : "Saving account securely...");
        }
        appendLog(offlineOnly ? "Saving offline account locally..." : "Saving account securely...");
        executor.execute(() -> {
            try {
                if (offlineOnly) accountStore.saveOfflineAccounts(updated);
                else accountStore.saveProtectedAccounts(updated,
                        message -> Platform.runLater(() -> {
                            if (status != null) status.setText(message);
                            appendLog(message);
                        }));
                Platform.runLater(() -> {
                    accountPersistenceInProgress = false;
                    accounts.clear();
                    accounts.addAll(updated);
                    appendLog("Account data saved.");
                    if (status != null) status.setText("Account saved. Opening launcher...");
                    try {
                        onSaved.run();
                    } catch (RuntimeException e) {
                        if (status != null) status.setText("Account saved, but the launcher could not finish updating.");
                        showError("Account saved, but launcher update failed", e);
                    }
                });
            } catch (IOException | RuntimeException e) {
                Platform.runLater(() -> {
                    accountPersistenceInProgress = false;
                    if (status != null) status.setText("Could not save account.");
                    showError(failureTitle, e);
                });
            }
        });
    }

    private void showSignInProgress(String message) {
        if (status != null) status.setText(message);
        else {
            TextInputDialog progress = new TextInputDialog();
            progress.initOwner(stage);
            progress.setTitle("V-Client account sign-in");
            progress.setHeaderText(message);
            progress.setContentText("Complete the sign-in steps; this window updates after authentication.");
            progress.show();
        }
    }

    private void showSignInError(String title, Throwable error) {
        Throwable cause = unwrap(error);
        if (status != null) status.setText(title + ": " + cause.getMessage());
        showError(title, cause);
    }

    private static Throwable unwrap(Throwable error) {
        Throwable cause = error;
        while (cause.getCause() != null
                && (cause instanceof java.util.concurrent.CompletionException
                || cause instanceof java.util.concurrent.ExecutionException)) {
            cause = cause.getCause();
        }
        return cause;
    }

    private static ListCell<PlayerAccount> accountCell() {
        return new ListCell<>() {
            @Override
            protected void updateItem(PlayerAccount saved, boolean empty) {
                super.updateItem(saved, empty);
                setText(empty || saved == null ? null : saved.name() + "   ·   " + saved.type().label());
                setTextFill(Color.web("#eaf0fb"));
            }
        };
    }

    private void loadPreviews(PlayerAccount selected, ImageView skin, ImageView cape, Label message) {
        loadPreviews(selected, skin, cape, message,
                () -> accountPicker == null ? null : accountPicker.getValue());
    }

    private void loadPreviews(PlayerAccount selected, ImageView skin, ImageView cape, Label message,
                              java.util.function.Supplier<PlayerAccount> currentSelection) {
        if (selected == null) {
            skin.setImage(null);
            cape.setImage(null);
            message.setText("Add or select a saved account.");
            return;
        }
        message.setText(selected.name() + "  ·  " + selected.type().label()
                + (selected.type() == PlayerAccount.Type.OFFLINE ? "  ·  Local offline UUID" : ""));
        skin.setImage(null);
        cape.setImage(null);
        String skinUrl = selected.skinUrl();
        String capeUrl = selected.capeUrl();
        executor.execute(() -> {
            Image skinImage = downloadImage(skinUrl);
            Image capeImage = downloadImage(capeUrl);
            Platform.runLater(() -> {
                PlayerAccount current = currentSelection.get();
                if (current == null || !current.id().equals(selected.id())) return;
                skin.setImage(skinImage);
                cape.setImage(capeImage);
                message.setText((skinImage == null ? "No saved skin image  ·  " : "")
                        + selected.name() + "  ·  " + selected.type().label()
                        + (capeImage == null ? "  ·  No cape equipped" : "  ·  Cape loaded"));
            });
        });
    }

    private void loadAvatar(PlayerAccount selected, ImageView target) {
        if (selected.skinUrl().isBlank()) {
            target.setImage(createIcon());
            return;
        }
        executor.execute(() -> {
            Image source = downloadImage(selected.skinUrl());
            if (source == null) return;
            javafx.scene.image.PixelReader pixels = source.getPixelReader();
            int pixelScale = Math.max(1, (int) source.getWidth() / 64);
            int cropSize = 8 * pixelScale;
            if (pixels == null || source.getHeight() < 16 * pixelScale
                    || source.getWidth() < 16 * pixelScale) return;
            Image head = new WritableImage(pixels, 8 * pixelScale, 8 * pixelScale,
                    cropSize, cropSize);
            Platform.runLater(() -> {
                if (account != null && account.id().equals(selected.id()) && target == avatar) {
                    target.setImage(head);
                }
            });
        });
    }

    private final SkinImageCache skinImageCache = new SkinImageCache(SkinImageCache.defaultDirectory(),
            line -> Platform.runLater(() -> appendLog(line)));

    private Image downloadImage(String address) {
        if (address == null || address.isBlank()) return null;
        try {
            URI uri = URI.create(address);
            if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null) return null;
            byte[] bytes = skinImageCache.load(address, this::fetchImageBytes, !settings.offlineMode());
            return bytes == null ? null : new Image(new ByteArrayInputStream(bytes), 0, 0, true, true);
        } catch (IllegalArgumentException | IOException e) {
            return null;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return null;
        }
    }

    private byte[] fetchImageBytes(String address) throws IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder(URI.create(address)).timeout(Duration.ofSeconds(20))
                .header("Accept", "image/png")
                .GET().build();
        HttpResponse<byte[]> response = IMAGE_HTTP.send(request, HttpResponse.BodyHandlers.ofByteArray());
        if (response.statusCode() < 200 || response.statusCode() >= 300
                || response.body().length > SkinImageCache.MAX_BYTES) return null;
        String contentType = response.headers().firstValue("Content-Type").orElse("");
        if (!contentType.toLowerCase(java.util.Locale.ROOT).startsWith("image/")) return null;
        return response.body();
    }

    private void saveSettings() {
        try {
            settings.save();
            if (status != null) status.setText("Settings saved.");
        } catch (IOException e) {
            if (status != null) status.setText("Could not save settings: " + e.getMessage());
            showError("Could not save settings", e);
        }
    }

    private void appendLogLater(String line) {
        Platform.runLater(() -> appendLog(line));
    }

    private void appendLog(String line) {
        logLines.add(line);
        int length = logLines.stream().mapToInt(String::length).sum();
        while (length > 40_000 && !logLines.isEmpty()) {
            length -= logLines.removeFirst().length();
        }
        if (log != null) {
            log.appendText(line + System.lineSeparator());
            int excess = log.getText().length() - 40_000;
            if (excess > 0) log.deleteText(0, excess);
        }
        if (consoleLog != null) {
            consoleLog.appendText(line + System.lineSeparator());
            int excess = consoleLog.getText().length() - 40_000;
            if (excess > 0) consoleLog.deleteText(0, excess);
        }
    }

    /** A short, friendly error dialog; the technical text is folded under an expandable "Details" section. */
    private void showError(String title, Throwable error) {
        FriendlyError.Message message = FriendlyError.of(error);
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.initOwner(stage);
        alert.setTitle("V-Client");
        alert.setHeaderText(title);
        alert.setContentText(message.title() + ". " + message.message());
        TextArea raw = new TextArea(message.details() + (settings != null && settings.debugMode()
                ? System.lineSeparator() + BackendClient.stackTrace(error) : ""));
        raw.setEditable(false);
        raw.setWrapText(true);
        raw.setPrefRowCount(8);
        raw.setStyle("-fx-font-family: 'Consolas'; -fx-font-size: 12px;");
        alert.getDialogPane().setExpandableContent(raw);
        ButtonType copy = new ButtonType("Copy logs", javafx.scene.control.ButtonBar.ButtonData.LEFT);
        alert.getButtonTypes().add(copy);
        alert.getDialogPane().setPrefWidth(520);
        alert.resultProperty().addListener((observable, was, result) -> {
            if (result == copy) copyLogsToClipboard();
        });
        alert.show();
    }

    /**
     * A failed launch becomes a short banner on the home page. When Minecraft wrote a crash report during this
     * launch, the crash report viewer opens on it.
     */
    private void showLaunchFailure(Throwable error, Path gameDirectory, long launchedAtMillis) {
        lastError = error;
        reportProblem(error);
        CrashReports.Report crash = CrashReports.newestSince(gameDirectory, launchedAtMillis - 2_000);
        if (crash != null) {
            appendLog("Crash detected: " + crash.summary() + " (" + crash.file() + ")");
            showCrashReports(crash);
        }
    }

    private static void appendDiagnosticFile(StringBuilder details, Path file, String label,
                                             int maximumCharacters) {
        if (!Files.isRegularFile(file)) return;
        details.append("\n--- ").append(label).append(": ").append(file).append(" ---\n");
        try {
            details.append(MinecraftLauncher.readTail(file, maximumCharacters))
                    .append(System.lineSeparator());
        } catch (IOException e) {
            details.append("Could not read diagnostic file: ").append(e.getMessage())
                    .append(System.lineSeparator());
        }
    }

    private static ListCell<VersionChoice> versionChoiceCell() {
        return new ListCell<>() {
            {
                selectedProperty().addListener((observable, wasSelected, isSelected) -> updateCellStyle());
                hoverProperty().addListener((observable, wasHovered, isHovered) -> updateCellStyle());
            }

            @Override
            protected void updateItem(VersionChoice choice, boolean empty) {
                super.updateItem(choice, empty);
                setText(empty || choice == null ? null : choice.toString());
                updateCellStyle();
            }

            private void updateCellStyle() {
                String background = isSelected() ? "#1e4260" : isHover() ? "#11263D" : "#0c2036";
                setStyle("-fx-background-color: " + background + "; -fx-padding: 8 10 8 10; -fx-font-size: 14px;");
                setTextFill(Color.web(isSelected() ? "#ffffff" : "#eaf9ff"));
            }
        };
    }

    private static VBox card() {
        VBox box = new VBox(14);
        box.setPadding(new Insets(20));
        box.setStyle("-fx-background-color: rgba(17, 38, 61, 0.84); -fx-background-radius: 12; -fx-border-color: rgba(124, 235, 255, 0.24); -fx-border-radius: 12;");
        return box;
    }

    private static Label label(String text, int size, String color) {
        Label label = new Label(text);
        label.setStyle("-fx-font-size: " + readableSize(size) + "px; -fx-text-fill: " + color + ";");
        return label;
    }

    /** Small text was hard to read on the dark background: everything up to 14 px grows a little. */
    private static int readableSize(int size) {
        return size <= 11 ? size + 2 : size <= 14 ? size + 1 : size;
    }

    private static Button button(String text, String color, int size) {
        Button button = new Button(text);
        String foreground = color.equalsIgnoreCase(ACCENT) ? "#071321" : "#eaf9ff";
        button.setStyle("-fx-background-color: " + color + "; -fx-text-fill: " + foreground + "; -fx-font-size: " + readableSize(size)
                + "px; -fx-font-weight: bold; -fx-background-radius: 9; -fx-padding: 12 18 12 18; -fx-cursor: hand;");
        return button;
    }

    private static String fieldStyle() {
        return "-fx-background-color: rgba(7, 19, 33, 0.88); -fx-text-fill: #e6e1f4; -fx-border-color: #2a4d6e; -fx-background-radius: 8; -fx-border-radius: 8; -fx-padding: 12;";
    }

    private static Region dot(String color) {
        Region dot = new Region();
        dot.setMinSize(8, 8);
        dot.setMaxSize(8, 8);
        dot.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 50%;");
        return dot;
    }

    /** The home banner artwork: a polar night, aurora, towering glaciers and a large ice crystal. */
    private static void drawHeroArt(Canvas canvas) {
        double width = canvas.getWidth();
        double height = canvas.getHeight();
        GraphicsContext g = canvas.getGraphicsContext2D();
        g.setFill(new javafx.scene.paint.LinearGradient(0, 0, 0, height, false, javafx.scene.paint.CycleMethod.NO_CYCLE,
                new javafx.scene.paint.Stop(0, Color.web("#050f1c")), new javafx.scene.paint.Stop(0.6, Color.web("#0b2540")),
                new javafx.scene.paint.Stop(1, Color.web("#12395a"))));
        g.fillRect(0, 0, width, height);
        int[][] ribbons = {{0, 207, 255}, {92, 255, 200}, {124, 235, 255}};
        for (int ribbon = 0; ribbon < ribbons.length; ribbon++) {
            int[] c = ribbons[ribbon];
            for (double x = 0; x < width; x += 5) {
                double top = height * (0.08 + ribbon * 0.07) + Math.sin(x * 0.007 + ribbon * 1.8) * 30 + Math.sin(x * 0.019 + ribbon) * 10;
                double strength = 0.5 + 0.5 * Math.sin(x * 0.003 + ribbon * 2.1);
                g.setFill(new javafx.scene.paint.LinearGradient(0, top, 0, top + height * 0.5, false,
                        javafx.scene.paint.CycleMethod.NO_CYCLE,
                        new javafx.scene.paint.Stop(0, Color.rgb(c[0], c[1], c[2], 0)),
                        new javafx.scene.paint.Stop(0.25, Color.rgb(c[0], c[1], c[2], 0.20 * (0.4 + strength))),
                        new javafx.scene.paint.Stop(1, Color.rgb(c[0], c[1], c[2], 0))));
                g.fillRect(x, top, 5.5, height * 0.5);
            }
        }
        // Glacier ridges with lit faces.
        g.setFill(Color.rgb(16, 52, 84, 0.95));
        g.fillPolygon(new double[]{0, 0, width * 0.12, width * 0.22, width * 0.34, width * 0.46, width * 0.6, width * 0.74,
                        width * 0.86, width * 0.94, width, width},
                new double[]{height, height * 0.72, height * 0.55, height * 0.70, height * 0.50, height * 0.72,
                        height * 0.62, height * 0.78, height * 0.56, height * 0.70, height * 0.64, height}, 12);
        g.setFill(Color.rgb(190, 240, 255, 0.13));
        g.fillPolygon(new double[]{width * 0.12, width * 0.22, width * 0.16}, new double[]{height * 0.55, height * 0.70, height * 0.72}, 3);
        g.fillPolygon(new double[]{width * 0.34, width * 0.46, width * 0.38}, new double[]{height * 0.50, height * 0.72, height * 0.74}, 3);
        g.setFill(Color.rgb(8, 30, 52, 0.96));
        g.fillPolygon(new double[]{0, width * 0.15, width * 0.3, width * 0.5, width * 0.7, width * 0.88, width, width},
                new double[]{height, height * 0.86, height * 0.80, height * 0.88, height * 0.78, height * 0.86, height * 0.82, height}, 8);
        // A large ice crystal on the right, a smaller one on the left.
        crystal(g, width * 0.82, height * 0.40, Math.min(width, height * 2.6) * 0.11);
        crystal(g, width * 0.13, height * 0.30, Math.min(width, height * 2.6) * 0.06);
        // Snow in the air.
        java.util.Random random = new java.util.Random(11);
        for (int index = 0; index < 120; index++) {
            g.setFill(Color.rgb(226, 247, 255, 0.25 + random.nextDouble() * 0.5));
            double size = 1 + random.nextDouble() * 2.6;
            g.fillOval(random.nextDouble() * width, random.nextDouble() * height, size, size);
        }
        // Darken the centre so the LAUNCH button stays readable.
        g.setFill(new javafx.scene.paint.RadialGradient(0, 0, width / 2, height / 2, width * 0.28, false,
                javafx.scene.paint.CycleMethod.NO_CYCLE, new javafx.scene.paint.Stop(0, Color.rgb(5, 15, 28, 0.55)),
                new javafx.scene.paint.Stop(1, Color.rgb(5, 15, 28, 0))));
        g.fillRect(0, 0, width, height);
    }

    private static void crystal(GraphicsContext g, double cx, double cy, double size) {
        g.setStroke(Color.web("#B8F4FF", 0.9));
        g.setFill(Color.rgb(124, 235, 255, 0.10));
        g.setLineWidth(Math.max(2, size * 0.07));
        g.setLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
        g.fillOval(cx - size, cy - size, size * 2, size * 2);
        for (int index = 0; index < 6; index++) {
            double angle = Math.toRadians(index * 60 - 90);
            double dx = Math.cos(angle);
            double dy = Math.sin(angle);
            g.strokeLine(cx, cy, cx + dx * size, cy + dy * size);
            double bx = cx + dx * size * 0.62;
            double by = cy + dy * size * 0.62;
            for (int side = -1; side <= 1; side += 2) {
                double branch = angle + side * Math.toRadians(50);
                g.strokeLine(bx, by, bx + Math.cos(branch) * size * 0.32, by + Math.sin(branch) * size * 0.32);
            }
        }
        g.setFill(Color.web("#00CFFF"));
        g.fillOval(cx - size * 0.06, cy - size * 0.06, size * 0.12, size * 0.12);
    }

    /** The VSMP mark: a six-armed snowflake crystal on a frosted tile. */
    private static Canvas logo(double size) {
        Canvas canvas = new Canvas(size, size);
        GraphicsContext graphics = canvas.getGraphicsContext2D();
        graphics.setFill(Color.web("#0c2036"));
        graphics.fillRoundRect(0, 0, size, size, size * 0.27, size * 0.27);
        graphics.setStroke(Color.web(ACCENT, 0.55));
        graphics.setLineWidth(Math.max(1, size * 0.03));
        graphics.strokeRoundRect(size * 0.015, size * 0.015, size * 0.97, size * 0.97, size * 0.27, size * 0.27);
        double centre = size / 2;
        double arm = size * 0.34;
        graphics.setStroke(Color.web("#B8F4FF"));
        graphics.setLineWidth(Math.max(1.4, size * 0.06));
        graphics.setLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
        for (int index = 0; index < 6; index++) {
            double angle = Math.toRadians(index * 60 - 90);
            double dx = Math.cos(angle);
            double dy = Math.sin(angle);
            graphics.strokeLine(centre, centre, centre + dx * arm, centre + dy * arm);
            double bx = centre + dx * arm * 0.62;
            double by = centre + dy * arm * 0.62;
            for (int side = -1; side <= 1; side += 2) {
                double branch = angle + side * Math.toRadians(50);
                graphics.strokeLine(bx, by, bx + Math.cos(branch) * arm * 0.3, by + Math.sin(branch) * arm * 0.3);
            }
        }
        graphics.setFill(Color.web(ACCENT));
        graphics.fillOval(centre - size * 0.045, centre - size * 0.045, size * 0.09, size * 0.09);
        return canvas;
    }

    private static javafx.scene.image.Image createIcon() {
        Canvas canvas = logo(64);
        return canvas.snapshot(null, null);
    }

    private record Snowflake(double x, double y, double size, double phase, double speed, double sway) {}

    private static List<Snowflake> createSnowflakes() {
        Random random = new Random(731921);
        List<Snowflake> flakes = new ArrayList<>(170);
        for (int index = 0; index < 170; index++) {
            double depth = random.nextDouble();
            flakes.add(new Snowflake(random.nextDouble(), random.nextDouble(), 1.2 + depth * 3.2,
                    random.nextDouble() * Math.PI * 2, 0.012 + depth * 0.035, 0.4 + random.nextDouble() * 1.1));
        }
        return List.copyOf(flakes);
    }

    /** The launcher backdrop: a dark polar sky with a drifting aurora, falling snow and glacier ridges. */
    private void drawNightSky(Canvas canvas, double time) {
        double width = canvas.getWidth();
        double height = canvas.getHeight();
        if (width <= 0 || height <= 0) return;
        GraphicsContext graphics = canvas.getGraphicsContext2D();
        graphics.setFill(Color.web(BACKGROUND));
        graphics.fillRect(0, 0, width, height);

        // Aurora Borealis: three slow ribbons built from soft vertical bands that fade downward.
        int[][] ribbons = {{0, 207, 255}, {92, 255, 200}, {124, 235, 255}};
        for (int ribbon = 0; ribbon < ribbons.length; ribbon++) {
            int[] colour = ribbons[ribbon];
            double base = height * (0.10 + ribbon * 0.085);
            for (double x = 0; x < width; x += 6) {
                double wave = Math.sin(x * 0.0042 + time * 0.35 + ribbon * 1.7) * 38
                        + Math.sin(x * 0.011 - time * 0.22 + ribbon) * 14;
                double strength = 0.5 + 0.5 * Math.sin(x * 0.0021 + time * 0.18 + ribbon * 2.3);
                double top = base + wave;
                double bandHeight = height * 0.24;
                double peak = Math.min(0.22, 0.10 * (0.45 + strength));
                // One smooth vertical gradient per strip: clear at the top, brightest near the top third, fading out.
                graphics.setFill(new javafx.scene.paint.LinearGradient(0, top, 0, top + bandHeight, false,
                        javafx.scene.paint.CycleMethod.NO_CYCLE,
                        new javafx.scene.paint.Stop(0, Color.rgb(colour[0], colour[1], colour[2], 0)),
                        new javafx.scene.paint.Stop(0.28, Color.rgb(colour[0], colour[1], colour[2], peak)),
                        new javafx.scene.paint.Stop(1, Color.rgb(colour[0], colour[1], colour[2], 0))));
                graphics.fillRect(x, top, 6.5, bandHeight);
            }
        }

        // A cold glow low on the horizon, in the theme's accent.
        int[] glow = Theme.glow();
        for (int layer = 10; layer >= 1; layer--) {
            graphics.setFill(Color.rgb(glow[0], glow[1], glow[2], 0.006 + (10 - layer) * 0.0016));
            double radius = width * (0.18 + layer * 0.045);
            graphics.fillOval(width * 0.5 - radius, height * 1.02 - radius * 0.55, radius * 2, radius * 1.1);
        }

        // Glacier ridges.
        graphics.setFill(Color.rgb(14, 40, 66, 0.80));
        graphics.fillPolygon(new double[]{0, 0, width * 0.10, width * 0.19, width * 0.30, width * 0.43,
                        width * 0.56, width * 0.69, width * 0.82, width * 0.92, width, width},
                new double[]{height, height * 0.80, height * 0.70, height * 0.79, height * 0.66, height * 0.80,
                        height * 0.72, height * 0.83, height * 0.68, height * 0.78, height * 0.74, height}, 12);
        graphics.setFill(Color.rgb(190, 240, 255, 0.10));
        graphics.fillPolygon(new double[]{width * 0.27, width * 0.30, width * 0.33, width * 0.30},
                new double[]{height * 0.70, height * 0.66, height * 0.71, height * 0.73}, 4);
        graphics.setFill(Color.rgb(8, 26, 46, 0.88));
        graphics.fillPolygon(new double[]{0, width * 0.14, width * 0.27, width * 0.41, width * 0.54,
                        width * 0.68, width * 0.80, width * 0.93, width, width},
                new double[]{height, height * 0.91, height * 0.86, height * 0.93, height * 0.84,
                        height * 0.92, height * 0.87, height * 0.93, height * 0.90, height}, 10);

        // Snowfall: nearer flakes are bigger and fall faster; everything leans with a gentle wind.
        for (Snowflake flake : snowflakes) {
            double fall = (flake.y() + time * flake.speed()) % 1.0;
            double drift = Math.sin(time * 0.6 * flake.sway() + flake.phase()) * 0.012 + time * 0.0035;
            double x = ((flake.x() + drift) % 1.0 + 1.0) % 1.0 * width;
            double y = fall * height;
            double twinkle = 0.55 + 0.45 * Math.sin(time * 1.4 + flake.phase());
            graphics.setFill(Color.rgb(226, 247, 255, 0.35 + 0.5 * twinkle * Math.min(1, flake.size() / 3.0)));
            graphics.fillOval(x, y, flake.size(), flake.size());
        }
    }

    @Override
    public void stop() {
        if (backgroundAnimation != null) backgroundAnimation.stop();
        VpnManager.disconnect();
        executor.shutdownNow();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
