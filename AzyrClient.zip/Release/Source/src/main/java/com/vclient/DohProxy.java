package com.vclient;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * A loopback HTTP proxy for the built-in browser. Host names are looked up through DNS-over-HTTPS servers that are
 * themselves reached by host name (normal SNI and certificate checks, never an IP address in the URL), so a
 * network's DNS filter or hijack cannot redirect the browser. HTTPS pages are tunnelled with CONNECT, so TLS still runs end to
 * end between the page and the site. If the DoH lookup fails the system resolver is used as a fallback.
 */
final class DohProxy {
    private record Answer(InetAddress address, long expiresAt) {}

    private static final ObjectMapper JSON = new ObjectMapper();
    private static final Map<String, Answer> CACHE = new ConcurrentHashMap<>();
    private static DohProxy instance;

    private final ServerSocket server;
    private final ExecutorService pool = Executors.newCachedThreadPool(runnable -> {
        Thread thread = new Thread(runnable, "doh-proxy");
        thread.setDaemon(true);
        return thread;
    });
    /** Created on first use: the JVM-wide resolver may call in while the JVM is still setting up networking. */
    private static final class Doh {
        static final HttpClient CLIENT = PlatformTls.httpClientBuilder(Duration.ofSeconds(5)).build();
    }

    private DohProxy() throws IOException {
        server = new ServerSocket(0, 50, InetAddress.getLoopbackAddress());
        Thread acceptor = new Thread(this::acceptLoop, "doh-proxy-accept");
        acceptor.setDaemon(true);
        acceptor.start();
    }

    /** Starts the proxy on first use and returns it; later calls reuse the same one. */
    static synchronized DohProxy shared() throws IOException {
        if (instance == null) instance = new DohProxy();
        return instance;
    }

    int port() {
        return server.getLocalPort();
    }

    private void acceptLoop() {
        while (!server.isClosed()) {
            try {
                Socket client = server.accept();
                pool.execute(() -> handle(client));
            } catch (IOException e) {
                return;
            }
        }
    }

    private void handle(Socket socket) {
        try (socket) {
            socket.setSoTimeout(30_000);
            InputStream in = socket.getInputStream();
            OutputStream out = socket.getOutputStream();
            String requestLine = readLine(in);
            if (requestLine == null || requestLine.isEmpty()) return;
            String[] parts = requestLine.split(" ", 3);
            if (parts.length < 3) return;
            StringBuilder headers = new StringBuilder();
            String line;
            while ((line = readLine(in)) != null && !line.isEmpty()) headers.append(line).append("\r\n");

            if (parts[0].equalsIgnoreCase("CONNECT")) {
                String target = parts[1];
                int colon = target.lastIndexOf(':');
                String host = colon < 0 ? target : target.substring(0, colon);
                int port = colon < 0 ? 443 : Integer.parseInt(target.substring(colon + 1));
                try (Socket remote = connect(host, port)) {
                    // A tunnel can sit idle for minutes (Discord's live connection, kept-alive HTTP/2): an idle
                    // timeout here cut those connections every 30 seconds and left the app stuck on its loading screen.
                    socket.setSoTimeout(0);
                    remote.setSoTimeout(0);
                    socket.setKeepAlive(true);
                    remote.setKeepAlive(true);
                    out.write("HTTP/1.1 200 Connection Established\r\n\r\n".getBytes(StandardCharsets.US_ASCII));
                    out.flush();
                    pipe(socket, remote);
                }
            } else {
                URI uri = URI.create(parts[1]);
                if (uri.getHost() == null) return;
                int port = uri.getPort() < 0 ? 80 : uri.getPort();
                String path = (uri.getRawPath() == null || uri.getRawPath().isEmpty() ? "/" : uri.getRawPath())
                        + (uri.getRawQuery() == null ? "" : "?" + uri.getRawQuery());
                try (Socket remote = connect(uri.getHost(), port)) {
                    String head = parts[0] + " " + path + " " + parts[2] + "\r\n"
                            + headers.toString().replaceAll("(?im)^proxy-connection:.*\r\n", "")
                            .replaceAll("(?im)^connection:.*\r\n", "") + "Connection: close\r\n\r\n";
                    remote.getOutputStream().write(head.getBytes(StandardCharsets.ISO_8859_1));
                    remote.getOutputStream().flush();
                    pipe(socket, remote);
                }
            }
        } catch (IOException | RuntimeException ignored) {
            // a dropped connection just ends that request
        }
    }

    private Socket connect(String host, int port) throws IOException {
        Integer vpn = VpnManager.socksPort();
        if (vpn != null) return connectThroughVpn(vpn, host, port);
        Socket remote = new Socket();
        try {
            remote.connect(new InetSocketAddress(resolve(host), port), 10_000);
        } catch (IOException e) {
            remote.close();
            throw e;
        }
        remote.setSoTimeout(60_000);
        return remote;
    }

    /**
     * With the VPN on, the site is reached through the tunnel's SOCKS5 port by name, so neither the connection nor
     * the DNS lookup leaves this PC outside the tunnel. A failure is reported, never retried outside the VPN.
     */
    static Socket connectThroughVpn(int socksPort, String host, int port) throws IOException {
        Socket socket = new Socket();
        try {
            socket.connect(new InetSocketAddress(InetAddress.getLoopbackAddress(), socksPort), 5_000);
            socket.setSoTimeout(20_000);
            OutputStream out = socket.getOutputStream();
            InputStream in = socket.getInputStream();
            out.write(new byte[]{5, 1, 0});
            out.flush();
            if (in.readNBytes(2).length != 2) throw new IOException("The VPN did not answer.");
            byte[] name = host.getBytes(StandardCharsets.US_ASCII);
            byte[] request = new byte[7 + name.length];
            request[0] = 5;
            request[1] = 1;
            request[3] = 3;
            request[4] = (byte) name.length;
            System.arraycopy(name, 0, request, 5, name.length);
            request[5 + name.length] = (byte) (port >> 8);
            request[6 + name.length] = (byte) port;
            out.write(request);
            out.flush();
            byte[] head = in.readNBytes(4);
            if (head.length != 4 || head[1] != 0) throw new IOException("The VPN could not reach " + host + ".");
            int skip = switch (head[3]) {
                case 1 -> 6;
                case 4 -> 18;
                default -> 1 + in.read() + 2;
            };
            in.readNBytes(head[3] == 3 ? skip - 1 : skip);
            socket.setSoTimeout(60_000);
            return socket;
        } catch (IOException e) {
            socket.close();
            throw e;
        }
    }

    /** Looks {@code host} up over DNS-over-HTTPS; falls back to the system resolver when that fails. */
    InetAddress resolve(String host) throws IOException {
        if (host.matches("[0-9.]+") || host.contains(":")) return InetAddress.getByName(host);
        Answer cached = CACHE.get(host);
        if (cached != null && cached.expiresAt() > System.currentTimeMillis()) return cached.address();
        InetAddress address = lookup(host);
        if (address != null) return address;
        // Secure DNS did not answer: use the system resolver, but never connect to a DNS filter's block page.
        address = InetAddress.getByName(host);
        if (DnsBlock.isSinkhole(address)) {
            throw new IOException(host + " is blocked by this network's DNS filter, and no secure DNS server could be reached.");
        }
        return address;
    }

    /**
     * DoH servers, reached by IP so they need no DNS. Many networks block 1.1.1.1 or the DoH host names but let one of
     * these through, so each is tried in turn and the one that last worked goes first.
     */
    private static final String[] DOH_SERVERS = {
            "https://cloudflare-dns.com/dns-query", "https://dns.google/resolve",
            "https://dns.quad9.net:5053/dns-query"};
    /** The DoH servers' own names are never looked up over DoH (that would recurse); the system resolver answers them. */
    private static final java.util.Set<String> DOH_HOSTS = java.util.Set.of(
            "cloudflare-dns.com", "dns.google", "dns.quad9.net");
    private static volatile int preferredServer;

    /**
     * Bootstrap addresses for the DoH servers only. A DNS filter often blocks these names too (it answers with its own
     * block page), and without an address no secure lookup could ever start. The addresses keep the host name, so the
     * TLS connection still sends the name as SNI and verifies the certificate against it; nothing else is overridden.
     */
    static java.util.List<InetAddress> bootstrap(String host) {
        int[][] ips = switch (host.toLowerCase(java.util.Locale.ROOT)) {
            case "cloudflare-dns.com" -> new int[][]{{1, 1, 1, 1}, {1, 0, 0, 1}};
            case "dns.google" -> new int[][]{{8, 8, 8, 8}, {8, 8, 4, 4}};
            case "dns.quad9.net" -> new int[][]{{9, 9, 9, 9}, {149, 112, 112, 112}};
            default -> new int[0][];
        };
        java.util.List<InetAddress> result = new java.util.ArrayList<>();
        for (int[] ip : ips) {
            try {
                result.add(InetAddress.getByAddress(host, new byte[]{(byte) ip[0], (byte) ip[1], (byte) ip[2], (byte) ip[3]}));
            } catch (java.net.UnknownHostException ignored) {
                // a 4-byte address is always valid
            }
        }
        return result;
    }

    static boolean isDohHost(String host) {
        return host != null && DOH_HOSTS.contains(host.toLowerCase(java.util.Locale.ROOT));
    }

    /**
     * An address that keeps its host name. {@code InetAddress.getByName(ip)} would create a nameless address, and TLS
     * would then verify the certificate against the bare IP ("No subject alternative names matching IP address").
     */
    static InetAddress named(String host, String ip) throws java.net.UnknownHostException {
        return InetAddress.getByAddress(host, InetAddress.getByName(ip).getAddress());
    }

    static InetAddress lookup(String host) {
        if (host == null || host.isBlank() || isDohHost(host) || host.matches("[0-9.]+") || host.contains(":")) return null;
        String name = URLEncoder.encode(host, StandardCharsets.UTF_8);
        for (int i = 0; i < DOH_SERVERS.length; i++) {
            int index = (preferredServer + i) % DOH_SERVERS.length;
            try {
                HttpRequest request = HttpRequest.newBuilder(URI.create(DOH_SERVERS[index] + "?type=A&name=" + name))
                        .timeout(Duration.ofSeconds(3)).header("Accept", "application/dns-json").GET().build();
                HttpResponse<String> response = Doh.CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
                if (response.statusCode() != 200) continue;
                preferredServer = index;
                for (JsonNode answer : JSON.readTree(response.body()).path("Answer")) {
                    if (answer.path("type").asInt() != 1) continue;
                    InetAddress address = named(host, answer.path("data").asText());
                    long ttl = Math.max(30, Math.min(answer.path("TTL").asLong(60), 600));
                    CACHE.put(host, new Answer(address, System.currentTimeMillis() + ttl * 1000));
                    return address;
                }
                return null; // the server answered: this name has no IPv4 address
            } catch (IOException | RuntimeException e) {
                // try the next server
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return null;
            }
        }
        return null;
    }

    /** Copies bytes both ways until either side closes. */
    private void pipe(Socket a, Socket b) throws IOException {
        Thread upstream = new Thread(() -> copy(a, b), "doh-proxy-up");
        upstream.setDaemon(true);
        upstream.start();
        copy(b, a);
        try {
            upstream.join(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private static void copy(Socket from, Socket to) {
        byte[] buffer = new byte[16 * 1024];
        try {
            InputStream in = from.getInputStream();
            OutputStream out = to.getOutputStream();
            int read;
            while ((read = in.read(buffer)) >= 0) {
                out.write(buffer, 0, read);
                out.flush();
            }
        } catch (IOException ignored) {
            // the other direction ending closes this one
        } finally {
            try {
                to.shutdownOutput();
            } catch (IOException ignored) {
                // already closed
            }
        }
    }

    private static String readLine(InputStream in) throws IOException {
        StringBuilder line = new StringBuilder();
        int c;
        while ((c = in.read()) >= 0) {
            if (c == '\n') break;
            if (c != '\r') line.append((char) c);
        }
        return c < 0 && line.length() == 0 ? null : line.toString();
    }
}
